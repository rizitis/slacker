# Rebuild the slacker glibc-2.33 TEST binary (for the Slackware 15.0 VM)

This folder is a **ready-to-build snapshot** of slacker 0.7.2 (single-crate).
Hand it to a fresh AI session and it can rebuild the binary without re-deriving
anything.

## What this is / why
slacker is normally built on slackware-current. A -current build links against
glibc ≥ 2.34, but **Slackware 15.0 ships glibc 2.33**, so a -current binary will
NOT run on the 15.0 VM. The trick: build a normal **gnu** binary but link it for
**old glibc (2.33)** using **zig as the linker** (`cargo-zigbuild`). rustls means
no libssl dependency either. The result runs on 15.0.

This is a **TEST-ONLY** binary (rustc 1.75, old glibc). It is NOT the distributed
package — the real package is the normal gnu `_FRG` build on each system.

## Files here
- `src/*.rs` — the full source tree (17 modules), current as of this snapshot.
- `Cargo.toml.glibc33` — the **LOCAL** manifest: MSRV lowered to 1.75 + deps pinned
  so it builds on Ubuntu's rustc 1.75, rustls backend. **Use this for the build.**
- `Cargo.toml.real` — r-tz's REAL manifest (open deps, MSRV 1.85.1, lto/strip,
  native-tls or rustls per the real tree). **Reference only.**

> NEVER ship `Cargo.toml.glibc33` as the project's Cargo.toml. It exists only to
> make this old-glibc test binary build on rustc 1.75. The real one is
> `Cargo.toml.real`.

## Build steps (Ubuntu 24 sandbox, container resets each session)
```sh
# 1. lay out the tree
mkdir -p /tmp/work && cd /tmp/work
cp -r <this-folder>/src ./src
cp <this-folder>/Cargo.toml.glibc33 ./Cargo.toml
cp <this-folder>/Cargo.toml.real ./Cargo.toml.real   # reference, never delivered

# 2. toolchain (rustc/cargo 1.75 on Ubuntu 24; gcc already present)
apt-get install -y rustc cargo libssl-dev pkg-config
export CARGO_HOME=/tmp/cargo-home

# 3. zig as the cross-linker for old glibc
pip3 install --break-system-packages ziglang
cargo install cargo-zigbuild --version 0.20.1 --locked   # 0.20.1 supports rustc 1.74+

# 4. build, targeting glibc 2.33
rm -f Cargo.lock
PATH=/tmp/cargo-home/bin:$PATH cargo zigbuild --release --target x86_64-unknown-linux-gnu.2.33

# 5. binary + verify it needs no newer than GLIBC_2.33
BIN=target/x86_64-unknown-linux-gnu/release/slacker
readelf -V "$BIN" | grep -oE 'GLIBC_[0-9]+\.[0-9]+' | sort -V -u | tail -1   # -> GLIBC_2.33
```
`cargo build` / `cargo test` (native 1.75) should give **0 warnings, 140 tests
pass + 1 ignored**. The 1 ignored is `download::tests::tls_handshake_works`
(fails ONLY in this sandbox because the egress proxy MITMs TLS with a private CA
not in webpki-roots — rustls is fine on real public mirrors).

## Package it for the VM (build tag `Nvm`, no makepkg)
Needs r-tz's config files (mirrors, repos, slacker.conf, blacklist, doinst.sh,
README.md, and a hand-written slack-desc — these live in the chat uploads).
Layout of the `.txz`:
```
usr/local/sbin/slacker
etc/slacker/{slacker.conf,mirrors,repos,blacklist}.new   # mirrors.new: pre-activate ONE current mirror line so upgrade-dist resolves target=current
etc/slacker/templates/
install/doinst.sh        # from uploads
install/slack-desc       # hand-written
usr/doc/slacker-0.7.2/{README.md,examples/}              # examples/ = the 4 config files
# NO man page (r-tz: "man δεν θελουμε")
```
```sh
tar --owner=root --group=root --numeric-owner -cJf slacker-0.7.2-x86_64-Nvm.txz .
```
r-tz `upgradepkg`s successive `Nvm` builds in the VM.

## glibc fact (so you don't redo the static dance)
glibc is BACKWARD-compatible only: an old-glibc binary runs on newer glibc. So the
real stable→next-stable dist-upgrade needs NO static/zig trick — only the
artificial "run a -current binary on 15.0" does.
