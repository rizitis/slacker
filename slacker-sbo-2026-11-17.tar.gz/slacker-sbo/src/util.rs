// Running external programs: as root for local work, as GIT_USER for
// anything that talks to the network.

use anyhow::{bail, Context, Result};
use std::ffi::CStr;
use std::os::unix::process::CommandExt;
use std::path::{Path, PathBuf};
use std::process::Command;

pub const SAFE_PATH: &str = "/usr/local/sbin:/usr/local/bin:/sbin:/usr/sbin:/bin:/usr/bin";

#[derive(Debug, Clone)]
pub struct User {
    pub name: String,
    pub uid: u32,
    pub gid: u32,
    pub home: PathBuf,
}

pub fn user(name: &str) -> Result<User> {
    let c = std::ffi::CString::new(name)?;
    let mut buf = vec![0 as libc::c_char; 16384];
    // SAFETY: getpwnam_r writes into our buffers; result is checked for NULL.
    unsafe {
        let mut pw: libc::passwd = std::mem::zeroed();
        let mut res: *mut libc::passwd = std::ptr::null_mut();
        let r = libc::getpwnam_r(c.as_ptr(), &mut pw, buf.as_mut_ptr(), buf.len(), &mut res);
        if r != 0 || res.is_null() {
            bail!("user {name} does not exist");
        }
        Ok(User {
            name: name.to_string(),
            uid: pw.pw_uid,
            gid: pw.pw_gid,
            home: PathBuf::from(CStr::from_ptr(pw.pw_dir).to_string_lossy().to_string()),
        })
    }
}

/// A command for GIT_USER: its own uid, gid and groups, a clean environment.
pub fn as_user(u: &User, prog: &str) -> Command {
    let mut c = Command::new(prog);
    let (name, uid, gid) = (std::ffi::CString::new(u.name.clone()).unwrap(), u.uid, u.gid);
    c.env_clear().env("PATH", SAFE_PATH).env("HOME", &u.home).env("USER", &u.name).env("LOGNAME", &u.name).env("LANG", "C");
    for k in ["TERM", "http_proxy", "https_proxy", "HTTP_PROXY", "HTTPS_PROXY", "no_proxy", "NO_PROXY"] {
        if let Ok(v) = std::env::var(k) {
            c.env(k, v);
        }
    }
    // SAFETY: between fork and exec: groups, then gid, then uid (std's own
    // uid()/gid() would run before pre_exec and leave no right to set groups).
    unsafe {
        c.pre_exec(move || {
            if libc::initgroups(name.as_ptr(), gid) != 0 || libc::setresgid(gid, gid, gid) != 0 || libc::setresuid(uid, uid, uid) != 0 {
                return Err(std::io::Error::last_os_error());
            }
            Ok(())
        });
    }
    c
}

/// A command run as root with a known PATH.
pub fn as_root(prog: &str) -> Command {
    let mut c = Command::new(prog);
    c.env_clear().env("PATH", SAFE_PATH).env("LANG", "C");
    if let Ok(v) = std::env::var("TERM") {
        c.env("TERM", v);
    }
    c
}

pub fn run(mut c: Command, what: &str) -> Result<()> {
    let st = c.status().with_context(|| format!("running {what}"))?;
    if !st.success() {
        bail!("{what} failed ({st})");
    }
    Ok(())
}

pub fn output(mut c: Command, what: &str) -> Result<String> {
    let out = c.output().with_context(|| format!("running {what}"))?;
    if !out.status.success() {
        bail!("{what} failed ({}): {}", out.status, String::from_utf8_lossy(&out.stderr).trim());
    }
    Ok(String::from_utf8_lossy(&out.stdout).to_string())
}

pub fn chown(p: &Path, uid: u32, gid: u32) -> Result<()> {
    std::os::unix::fs::lchown(p, Some(uid), Some(gid)).with_context(|| format!("chown {}", p.display()))
}

/// Creates a directory (and parents) owned by root with the given mode.
pub fn mkdir_root(p: &Path, mode: u32) -> Result<()> {
    use std::os::unix::fs::PermissionsExt;
    std::fs::create_dir_all(p).with_context(|| format!("creating {}", p.display()))?;
    std::fs::set_permissions(p, std::fs::Permissions::from_mode(mode))?;
    chown(p, 0, 0)
}

pub fn is_mountpoint(p: &Path) -> bool {
    let Ok(text) = std::fs::read_to_string("/proc/self/mountinfo") else { return false };
    let want = p.to_string_lossy();
    text.lines().any(|l| l.split_whitespace().nth(4) == Some(&*want))
}

/// Removes a tree without following symlinks out of it.
pub fn remove_tree(p: &Path) -> Result<()> {
    match std::fs::symlink_metadata(p) {
        Err(_) => Ok(()),
        Ok(m) if m.is_dir() => std::fs::remove_dir_all(p).with_context(|| format!("removing {}", p.display())),
        Ok(_) => std::fs::remove_file(p).with_context(|| format!("removing {}", p.display())),
    }
}

pub fn md5_file(p: &Path) -> Result<String> {
    use md5::{Digest, Md5};
    use std::io::Read;
    let mut f = std::fs::File::open(p).with_context(|| format!("opening {}", p.display()))?;
    let mut h = Md5::new();
    let mut buf = vec![0u8; 1 << 20];
    loop {
        let n = f.read(&mut buf)?;
        if n == 0 {
            break;
        }
        h.update(&buf[..n]);
    }
    Ok(h.finalize().iter().map(|b| format!("{b:02x}")).collect())
}
