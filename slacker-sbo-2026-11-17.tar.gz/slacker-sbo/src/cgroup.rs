// Memory and pids limits for one build, and killing whatever is left at the
// end. Works on cgroup v1, v2 and mixed systems: each controller is used
// where the system already has it. Nothing on the system is reconfigured;
// the only thing created is the build's own cgroup, removed afterwards.

use anyhow::{bail, Context, Result};
use std::path::{Path, PathBuf};
use std::time::{Duration, Instant};

use crate::conf::{Conf, MemLimit};

const PREFIX: &str = "slacker-sbo-";

#[derive(Default)]
struct Mounts {
    v2: Option<PathBuf>,
    v1: Vec<(String, PathBuf)>,
}

fn mounts() -> Mounts {
    let mut m = Mounts::default();
    let Ok(text) = std::fs::read_to_string("/proc/self/mountinfo") else { return m };
    for line in text.lines() {
        let Some((left, right)) = line.split_once(" - ") else { continue };
        let mut r = right.split_whitespace();
        let fstype = r.next().unwrap_or("");
        let _src = r.next();
        let opts = r.next().unwrap_or("");
        let Some(mnt) = left.split_whitespace().nth(4) else { continue };
        match fstype {
            "cgroup2" if m.v2.is_none() => m.v2 = Some(PathBuf::from(mnt)),
            "cgroup" => {
                for c in ["memory", "pids", "freezer"] {
                    if opts.split(',').any(|o| o == c) && !m.v1.iter().any(|(n, _)| n == c) {
                        m.v1.push((c.to_string(), PathBuf::from(mnt)));
                    }
                }
            }
            _ => {}
        }
    }
    m
}

fn mem_total() -> Result<u64> {
    let text = std::fs::read_to_string("/proc/meminfo")?;
    for l in text.lines() {
        if let Some(v) = l.strip_prefix("MemTotal:") {
            let kb: u64 = v.trim().trim_end_matches("kB").trim().parse()?;
            return Ok(kb * 1024);
        }
    }
    bail!("MemTotal not found in /proc/meminfo")
}

fn mem_bytes(conf: &Conf) -> Result<u64> {
    Ok(match conf.build_mem {
        MemLimit::Bytes(b) => b,
        MemLimit::Percent(p) => mem_total()? / 100 * p,
    })
}

fn write(p: &Path, v: &str) -> Result<()> {
    std::fs::write(p, v).with_context(|| format!("writing {v:?} to {}", p.display()))
}

fn missing(conf: &Conf, what: &str) -> Result<()> {
    if conf.cgroup_missing_stop {
        bail!("cgroup controller {what} is not available; set CGROUP_MISSING=\"warn\" to build without this limit");
    }
    eprintln!("warning: cgroup controller {what} is not available, building without that limit");
    Ok(())
}

/// The build's cgroup: a directory in the v2 hierarchy (if there is one)
/// and one per v1 controller used.
pub struct Cgroup {
    v2: Option<PathBuf>,
    v2_mem: bool,
    v2_pids: bool,
    v1: Vec<(String, PathBuf)>,
}

impl Cgroup {
    pub fn create(conf: &Conf, name: &str) -> Result<Cgroup> {
        let m = mounts();
        let dirname = format!("{PREFIX}{name}");
        // Controllers the v2 root already hands to its children. Not changed by us.
        let v2_enabled: Vec<String> = m
            .v2
            .as_ref()
            .and_then(|r| std::fs::read_to_string(r.join("cgroup.subtree_control")).ok())
            .map(|t| t.split_whitespace().map(str::to_string).collect())
            .unwrap_or_default();
        let in_v1 = |c: &str| m.v1.iter().find(|(n, _)| n == c).map(|(_, p)| p.clone());

        let mut cg = Cgroup { v2: None, v2_mem: false, v2_pids: false, v1: Vec::new() };
        for c in ["memory", "pids"] {
            if let Some(root) = in_v1(c) {
                cg.v1.push((c.to_string(), root.join(&dirname)));
            } else if v2_enabled.iter().any(|x| x == c) {
                if c == "memory" {
                    cg.v2_mem = true;
                } else {
                    cg.v2_pids = true;
                }
            } else {
                missing(conf, c)?;
            }
        }
        // v2 can freeze and kill by itself; v1 needs the freezer for a clean kill.
        if let Some(root) = &m.v2 {
            cg.v2 = Some(root.join(&dirname));
        }
        if let Some(root) = in_v1("freezer") {
            cg.v1.push(("freezer".into(), root.join(&dirname)));
        }

        // A leftover from an interrupted run with the same name goes first.
        cg.destroy_dirs()?;
        let mem = mem_bytes(conf)?.to_string();
        let pids = conf.build_pids.to_string();
        if let Some(d) = &cg.v2 {
            std::fs::create_dir(d).with_context(|| format!("creating {}", d.display()))?;
            if cg.v2_mem {
                write(&d.join("memory.max"), &mem)?;
                // No swap: a build over its limit is killed instead of pushing the host into swap.
                if d.join("memory.swap.max").exists() {
                    write(&d.join("memory.swap.max"), "0")?;
                }
                if d.join("memory.oom.group").exists() {
                    write(&d.join("memory.oom.group"), "1")?;
                }
            }
            if cg.v2_pids {
                write(&d.join("pids.max"), &pids)?;
            }
        }
        for (c, d) in &cg.v1 {
            std::fs::create_dir(d).with_context(|| format!("creating {}", d.display()))?;
            match c.as_str() {
                "memory" => {
                    write(&d.join("memory.limit_in_bytes"), &mem)?;
                    let memsw = d.join("memory.memsw.limit_in_bytes");
                    if memsw.exists() {
                        write(&memsw, &mem)?;
                    }
                }
                "pids" => write(&d.join("pids.max"), &pids)?,
                _ => {}
            }
        }
        Ok(cg)
    }

    fn all_dirs(&self) -> Vec<&PathBuf> {
        self.v2.iter().chain(self.v1.iter().map(|(_, d)| d)).collect()
    }

    pub fn add(&self, pid: libc::pid_t) -> Result<()> {
        for d in self.all_dirs() {
            write(&d.join("cgroup.procs"), &pid.to_string())?;
        }
        Ok(())
    }

    /// Did the kernel kill something here for running out of memory?
    pub fn oom_killed(&self) -> bool {
        let count = |p: PathBuf| {
            std::fs::read_to_string(p)
                .map(|t| t.lines().any(|l| l.strip_prefix("oom_kill ").is_some_and(|n| n.trim() != "0")))
                .unwrap_or(false)
        };
        let v2 = self.v2_mem && self.v2.as_ref().is_some_and(|d| count(d.join("memory.events")));
        let v1 = self.v1.iter().any(|(c, d)| c == "memory" && count(d.join("memory.oom_control")));
        v2 || v1
    }

    pub fn limits_text(&self) -> String {
        let mut parts = Vec::new();
        if self.v2_mem || self.v1.iter().any(|(c, _)| c == "memory") {
            parts.push("memory");
        }
        if self.v2_pids || self.v1.iter().any(|(c, _)| c == "pids") {
            parts.push("pids");
        }
        if parts.is_empty() { "no cgroup limits".into() } else { format!("cgroup limits: {}", parts.join(", ")) }
    }

    /// Kills everything still in the cgroup and removes its directories.
    pub fn destroy(self) -> Result<()> {
        self.destroy_dirs()
    }

    fn destroy_dirs(&self) -> Result<()> {
        self.kill_all()?;
        for d in self.all_dirs() {
            if d.exists() {
                std::fs::remove_dir(d).with_context(|| format!("removing {}", d.display()))?;
            }
        }
        Ok(())
    }

    /// Kills every process of the build, keeping the cgroup.
    pub fn kill_all(&self) -> Result<()> {
        if let Some(d) = self.v2.as_ref().filter(|d| d.exists()) {
            let kill = d.join("cgroup.kill");
            if kill.exists() {
                let _ = std::fs::write(&kill, "1");
            } else {
                let _ = std::fs::write(d.join("cgroup.freeze"), "1");
                kill_pids(&d.join("cgroup.procs"));
                let _ = std::fs::write(d.join("cgroup.freeze"), "0");
            }
            wait_empty(&d.join("cgroup.procs"))?;
        }
        let freezer = self.v1.iter().find(|(c, d)| c == "freezer" && d.exists()).map(|(_, d)| d.clone());
        if let Some(f) = &freezer {
            let _ = std::fs::write(f.join("freezer.state"), "FROZEN");
        }
        for (_, d) in self.v1.iter().filter(|(_, d)| d.exists()) {
            kill_pids(&d.join("cgroup.procs"));
        }
        if let Some(f) = &freezer {
            let _ = std::fs::write(f.join("freezer.state"), "THAWED");
        }
        for (_, d) in self.v1.iter().filter(|(_, d)| d.exists()) {
            wait_empty(&d.join("cgroup.procs"))?;
        }
        Ok(())
    }
}

fn kill_pids(procs: &Path) {
    if let Ok(t) = std::fs::read_to_string(procs) {
        for pid in t.lines().filter_map(|l| l.trim().parse::<libc::pid_t>().ok()) {
            // SAFETY: plain kill(2).
            unsafe { libc::kill(pid, libc::SIGKILL) };
        }
    }
}

fn wait_empty(procs: &Path) -> Result<()> {
    let start = Instant::now();
    loop {
        match std::fs::read_to_string(procs) {
            Ok(t) if !t.trim().is_empty() => {
                if start.elapsed() > Duration::from_secs(10) {
                    bail!("processes still alive in {} after 10 s", procs.display());
                }
                kill_pids(procs);
                std::thread::sleep(Duration::from_millis(50));
            }
            _ => return Ok(()),
        }
    }
}
