// SBo .info files and dependency resolution.

use anyhow::{bail, Context, Result};
use std::collections::{HashMap, HashSet};
use std::path::{Path, PathBuf};

use crate::conf::Arch;

#[derive(Debug, Clone, Default)]
pub struct Info {
    pub prgnam: String,
    pub version: String,
    pub download: Vec<String>,
    pub md5sum: Vec<String>,
    pub download_x86_64: Vec<String>,
    pub md5sum_x86_64: Vec<String>,
    pub requires: Vec<String>,
}

/// Sources for one architecture, or None when the package is UNSUPPORTED there.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Sources {
    pub urls: Vec<String>,
    pub md5: Vec<String>,
}

impl Info {
    pub fn parse(text: &str) -> Result<Info> {
        // Join backslash continuations, then read KEY="value" pairs.
        let joined = text.replace("\\\r\n", " ").replace("\\\n", " ");
        let mut map: HashMap<String, String> = HashMap::new();
        for (i, line) in joined.lines().enumerate() {
            let line = line.trim();
            if line.is_empty() || line.starts_with('#') {
                continue;
            }
            let Some((k, v)) = line.split_once('=') else {
                bail!("line {}: expected KEY=\"value\"", i + 1);
            };
            let v = v.trim();
            let v = v.strip_prefix('"').and_then(|v| v.strip_suffix('"')).unwrap_or(v);
            map.insert(k.trim().to_string(), v.to_string());
        }
        let list = |k: &str| -> Vec<String> { map.get(k).map(|v| v.split_whitespace().map(str::to_string).collect()).unwrap_or_default() };
        let one = |k: &str| -> String { map.get(k).cloned().unwrap_or_default() };
        let info = Info {
            prgnam: one("PRGNAM"),
            version: one("VERSION"),
            download: list("DOWNLOAD"),
            md5sum: list("MD5SUM"),
            download_x86_64: list("DOWNLOAD_x86_64"),
            md5sum_x86_64: list("MD5SUM_x86_64"),
            requires: list("REQUIRES"),
        };
        if info.prgnam.is_empty() || info.version.is_empty() {
            bail!("PRGNAM or VERSION missing");
        }
        Ok(info)
    }

    pub fn load(path: &Path) -> Result<Info> {
        let text = std::fs::read_to_string(path).with_context(|| format!("reading {}", path.display()))?;
        Info::parse(&text).with_context(|| path.display().to_string())
    }

    /// SBo rules: DOWNLOAD="UNSUPPORTED" means no i586; DOWNLOAD_x86_64="UNSUPPORTED"
    /// means no x86_64; an empty DOWNLOAD_x86_64 means x86_64 uses DOWNLOAD.
    pub fn sources(&self, arch: Arch) -> Result<Option<Sources>> {
        let unsupported = |v: &[String]| v.len() == 1 && v[0] == "UNSUPPORTED";
        let (urls, md5) = match arch {
            Arch::I586 => {
                if unsupported(&self.download) {
                    return Ok(None);
                }
                (&self.download, &self.md5sum)
            }
            Arch::X86_64 => {
                if unsupported(&self.download_x86_64) {
                    return Ok(None);
                }
                if self.download_x86_64.is_empty() {
                    if unsupported(&self.download) {
                        bail!("{}: DOWNLOAD is UNSUPPORTED and DOWNLOAD_x86_64 is empty", self.prgnam);
                    }
                    (&self.download, &self.md5sum)
                } else {
                    (&self.download_x86_64, &self.md5sum_x86_64)
                }
            }
        };
        if urls.len() != md5.len() {
            bail!("{}: {} download(s) but {} md5sum(s) for {}", self.prgnam, urls.len(), md5.len(), arch.name());
        }
        for m in md5 {
            if m.len() != 32 || !m.bytes().all(|b| b.is_ascii_hexdigit()) {
                bail!("{}: {m:?} is not an md5sum", self.prgnam);
            }
        }
        Ok(Some(Sources { urls: urls.clone(), md5: md5.iter().map(|m| m.to_ascii_lowercase()).collect() }))
    }

    pub fn wants_readme(&self) -> bool {
        self.requires.iter().any(|r| r == "%README%")
    }

    pub fn real_requires(&self) -> impl Iterator<Item = &String> {
        self.requires.iter().filter(|r| r.as_str() != "%README%")
    }
}

/// Package name -> its directory (category/name) in an SBo tree.
pub struct Tree {
    pub root: PathBuf,
    index: HashMap<String, PathBuf>,
}

impl Tree {
    pub fn scan(root: &Path) -> Result<Tree> {
        let mut index = HashMap::new();
        for cat in std::fs::read_dir(root).with_context(|| format!("reading {}", root.display()))? {
            let cat = cat?;
            let name = cat.file_name();
            let name = name.to_string_lossy();
            if name.starts_with('.') || !cat.file_type()?.is_dir() {
                continue;
            }
            for pkg in std::fs::read_dir(cat.path())? {
                let pkg = pkg?;
                if !pkg.file_type()?.is_dir() {
                    continue;
                }
                let pname = pkg.file_name().to_string_lossy().to_string();
                if pkg.path().join(format!("{pname}.info")).is_file() {
                    index.insert(pname, pkg.path());
                }
            }
        }
        if index.is_empty() {
            bail!("{} holds no SlackBuilds", root.display());
        }
        Ok(Tree { root: root.to_path_buf(), index })
    }

    pub fn dir(&self, name: &str) -> Option<&PathBuf> {
        self.index.get(name)
    }

    pub fn info(&self, name: &str) -> Result<Info> {
        let dir = self.dir(name).with_context(|| format!("{name} is not in {}", self.root.display()))?;
        Info::load(&dir.join(format!("{name}.info")))
    }

    /// category/name, as SBo commit messages use it.
    pub fn category_path(&self, name: &str) -> Option<String> {
        let dir = self.dir(name)?;
        let rel = dir.strip_prefix(&self.root).ok()?;
        Some(rel.to_string_lossy().to_string())
    }
}

/// Build order for `target`: its dependencies first, `target` last.
/// `pick` says which tree each package comes from (SBo or a dev branch).
pub fn resolve<'a>(target: &str, pick: &dyn Fn(&str) -> &'a Tree) -> Result<Vec<String>> {
    fn visit<'a>(
        name: &str,
        pick: &dyn Fn(&str) -> &'a Tree,
        stack: &mut Vec<String>,
        done: &mut HashSet<String>,
        order: &mut Vec<String>,
    ) -> Result<()> {
        if done.contains(name) {
            return Ok(());
        }
        if let Some(pos) = stack.iter().position(|s| s == name) {
            let mut cycle = stack[pos..].to_vec();
            cycle.push(name.to_string());
            bail!("dependency cycle: {}", cycle.join(" -> "));
        }
        let tree = pick(name);
        if tree.dir(name).is_none() {
            match stack.last() {
                Some(parent) => bail!("{name} (needed by {parent}) is not in SBo; a new SlackBuild goes through the SBo submission form"),
                None => bail!("{name} is not in {}", tree.root.display()),
            }
        }
        let info = tree.info(name)?;
        stack.push(name.to_string());
        for dep in info.real_requires() {
            visit(dep, pick, stack, done, order)?;
        }
        stack.pop();
        done.insert(name.to_string());
        order.push(name.to_string());
        Ok(())
    }
    let mut order = Vec::new();
    visit(target, pick, &mut Vec::new(), &mut HashSet::new(), &mut order)?;
    Ok(order)
}

#[cfg(test)]
mod tests {
    use super::*;

    const VLC: &str = r#"PRGNAM="vlc"
VERSION="3.0.21"
HOMEPAGE="https://www.videolan.org"
DOWNLOAD="https://example.org/vlc-3.0.21.tar.xz \
          https://example.org/extra.tar.gz"
MD5SUM="0123456789abcdef0123456789abcdef \
        fedcba9876543210FEDCBA9876543210"
DOWNLOAD_x86_64=""
MD5SUM_x86_64=""
REQUIRES="libplacebo %README%"
MAINTAINER="x"
EMAIL="x@y"
"#;

    #[test]
    fn parse_and_sources() {
        let i = Info::parse(VLC).unwrap();
        assert_eq!(i.prgnam, "vlc");
        assert_eq!(i.download.len(), 2);
        assert!(i.wants_readme());
        assert_eq!(i.real_requires().collect::<Vec<_>>(), vec!["libplacebo"]);
        let s = i.sources(Arch::X86_64).unwrap().unwrap();
        assert_eq!(s.urls, i.download);
        assert_eq!(s.md5[1], "fedcba9876543210fedcba9876543210");
        assert!(i.sources(Arch::I586).unwrap().is_some());
    }

    #[test]
    fn unsupported() {
        let t = VLC.replace(
            "DOWNLOAD_x86_64=\"\"\nMD5SUM_x86_64=\"\"",
            "DOWNLOAD_x86_64=\"UNSUPPORTED\"\nMD5SUM_x86_64=\"\"",
        );
        let i = Info::parse(&t).unwrap();
        assert!(i.sources(Arch::X86_64).unwrap().is_none());
        let t = r#"PRGNAM="bin"
VERSION="1"
DOWNLOAD="UNSUPPORTED"
MD5SUM=""
DOWNLOAD_x86_64="https://e/x.tgz"
MD5SUM_x86_64="0123456789abcdef0123456789abcdef"
"#;
        let i = Info::parse(t).unwrap();
        assert!(i.sources(Arch::I586).unwrap().is_none());
        assert_eq!(i.sources(Arch::X86_64).unwrap().unwrap().urls, vec!["https://e/x.tgz"]);
    }

    fn mk(root: &Path, cat: &str, name: &str, req: &str) {
        let d = root.join(cat).join(name);
        std::fs::create_dir_all(&d).unwrap();
        std::fs::write(d.join(format!("{name}.info")), format!("PRGNAM=\"{name}\"\nVERSION=\"1\"\nDOWNLOAD=\"\"\nMD5SUM=\"\"\nREQUIRES=\"{req}\"\n")).unwrap();
    }

    #[test]
    fn order_cycle_missing() {
        let t = std::env::temp_dir().join(format!("sbo-tree-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&t);
        mk(&t, "multimedia", "vlc", "libplacebo libb %README%");
        mk(&t, "libraries", "libplacebo", "libb");
        mk(&t, "libraries", "libb", "");
        mk(&t, "misc", "a", "b");
        mk(&t, "misc", "b", "a");
        mk(&t, "misc", "c", "nothere");
        let tree = Tree::scan(&t).unwrap();
        let order = resolve("vlc", &|_| &tree).unwrap();
        assert_eq!(order, vec!["libb", "libplacebo", "vlc"]);
        assert_eq!(tree.category_path("vlc").unwrap(), "multimedia/vlc");
        assert!(resolve("a", &|_| &tree).unwrap_err().to_string().contains("cycle"));
        assert!(resolve("c", &|_| &tree).unwrap_err().to_string().contains("submission form"));
        let _ = std::fs::remove_dir_all(&t);
    }
}
