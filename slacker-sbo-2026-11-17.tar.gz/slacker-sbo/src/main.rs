// slacker-sbo: clean SBo builds in a sandbox, and the SBo pull request flow.

mod cgroup;
mod conf;
mod info;
mod sandbox;
mod slackware;
mod util;
mod workspace;

use anyhow::{bail, Result};
use conf::Arch;

const USAGE: &str = "\
usage: slacker-sbo <command> [options] [package]

  update-sbo                 git: upstream SBo and your fork, then a full clean
  update-slackware           Slackware 15.0 packages (GPG, md5), base trees, then a full clean
  clean                      remove sandboxes and the dependency cache
  build [opts] <pkg>         clean build from SBo (x86_64 and i586)
  dev <pkg>                  open branch <pkg> in your fork, in its own worktree
  shell [opts] <pkg>         sandbox with the dependencies of <pkg>, root shell inside
  lint [--dev] <pkg>         sbolint and sbopkglint, inside the sandbox
  commit <pkg>               check permissions, propose the message, commit after you approve
  pr <pkg>                   push and open the pull request
  done <pkg>                 delete branch <pkg> here and in your fork

build and shell options:
  --dev                      use your development branch of <pkg>
  --use-dev <dep>            take dependency <dep> from its own development branch (repeatable)
  --arch x86_64|i586         only this architecture

Variables for the SlackBuild go first: sudo NAME=VALUE slacker-sbo build <pkg>
Configuration: /etc/slacker/slacker-sbo.conf";

#[derive(Debug, Default, PartialEq)]
pub struct Opts {
    pub dev: bool,
    pub use_dev: Vec<String>,
    pub arch: Option<Arch>,
    pub pkg: Option<String>,
}

#[derive(Debug, PartialEq)]
pub enum Cmd {
    UpdateSbo,
    UpdateSlackware,
    Clean,
    Build(Opts),
    Dev(String),
    Shell(Opts),
    Lint(Opts),
    Commit(String),
    Pr(String),
    Done(String),
    Help,
    Version,
}

fn valid_pkg(p: &str) -> bool {
    !p.is_empty() && !p.starts_with('-') && !p.starts_with('.') && p.bytes().all(|b| b.is_ascii_alphanumeric() || b"+-._".contains(&b))
}

pub fn parse_args(args: &[String]) -> Result<Cmd> {
    let Some(cmd) = args.first() else { return Ok(Cmd::Help) };
    let rest = &args[1..];
    let one_pkg = |what: &str| -> Result<String> {
        match rest {
            [p] if valid_pkg(p) => Ok(p.clone()),
            [p] => bail!("{what}: {p:?} is not a package name"),
            _ => bail!("{what} takes exactly one package name"),
        }
    };
    let none = |what: &str| -> Result<()> {
        if !rest.is_empty() {
            bail!("{what} takes no arguments");
        }
        Ok(())
    };
    let opts = |what: &str, allow_dev_deps: bool| -> Result<Opts> {
        let mut o = Opts::default();
        let mut i = 0;
        while i < rest.len() {
            let a = rest[i].as_str();
            match a {
                "--dev" => o.dev = true,
                "--use-dev" if allow_dev_deps => {
                    i += 1;
                    let d = rest.get(i).filter(|d| valid_pkg(d)).ok_or_else(|| anyhow::anyhow!("--use-dev needs a package name"))?;
                    if !o.use_dev.contains(d) {
                        o.use_dev.push(d.clone());
                    }
                }
                "--arch" if allow_dev_deps => {
                    i += 1;
                    let v = rest.get(i).map(String::as_str).unwrap_or("");
                    o.arch = Some(Arch::parse(v).ok_or_else(|| anyhow::anyhow!("--arch: {v:?} is not x86_64 or i586"))?);
                }
                _ if a.starts_with('-') => bail!("{what}: unknown option {a}"),
                _ if o.pkg.is_none() && valid_pkg(a) => o.pkg = Some(a.to_string()),
                _ if o.pkg.is_none() => bail!("{what}: {a:?} is not a package name"),
                _ => bail!("{what} takes one package name"),
            }
            i += 1;
        }
        if o.pkg.is_none() {
            bail!("{what} needs a package name");
        }
        if let Some(p) = &o.pkg
            && o.use_dev.contains(p)
        {
            bail!("--use-dev {p}: use --dev for the package itself");
        }
        Ok(o)
    };
    Ok(match cmd.as_str() {
        "update-sbo" => {
            none(cmd)?;
            Cmd::UpdateSbo
        }
        "update-slackware" => {
            none(cmd)?;
            Cmd::UpdateSlackware
        }
        "clean" => {
            none(cmd)?;
            Cmd::Clean
        }
        "build" => Cmd::Build(opts(cmd, true)?),
        "shell" => Cmd::Shell(opts(cmd, true)?),
        "lint" => Cmd::Lint(opts(cmd, false)?),
        "dev" => Cmd::Dev(one_pkg(cmd)?),
        "commit" => Cmd::Commit(one_pkg(cmd)?),
        "pr" => Cmd::Pr(one_pkg(cmd)?),
        "done" => Cmd::Done(one_pkg(cmd)?),
        "help" | "-h" | "--help" => Cmd::Help,
        "--version" => Cmd::Version,
        other => bail!("unknown command {other:?}; see slacker-sbo help"),
    })
}

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let code = match run(&args) {
        Ok(c) => c,
        Err(e) => {
            eprintln!("slacker-sbo: {e:#}");
            1
        }
    };
    std::process::exit(code);
}

fn run(args: &[String]) -> Result<i32> {
    let cmd = parse_args(args)?;
    match cmd {
        Cmd::Help => {
            println!("{USAGE}");
            return Ok(0);
        }
        Cmd::Version => {
            println!("slacker-sbo {}", env!("CARGO_PKG_VERSION"));
            return Ok(0);
        }
        _ => {}
    }
    // SAFETY: geteuid has no preconditions.
    if unsafe { libc::geteuid() } != 0 {
        bail!("needs root: sudo slacker-sbo {}", args.join(" "));
    }
    let conf = conf::Conf::load()?;
    let ws = workspace::Workspace::open(conf)?;
    match cmd {
        Cmd::UpdateSlackware => {
            slackware::update(&ws)?;
            full_clean(&ws)?;
        }
        Cmd::Clean => ws.clean()?,
        other => bail!("{other:?}: not implemented yet"),
    }
    Ok(0)
}

/// After update-sbo and update-slackware: nothing built before stays.
fn full_clean(ws: &workspace::Workspace) -> Result<()> {
    println!("==> clean: sandboxes, dependency cache, source tarballs");
    ws.clean()?;
    util::remove_tree(&ws.conf.src_dir)?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn a(s: &str) -> Vec<String> {
        s.split_whitespace().map(str::to_string).collect()
    }

    #[test]
    fn commands() {
        assert_eq!(parse_args(&a("update-sbo")).unwrap(), Cmd::UpdateSbo);
        assert!(parse_args(&a("update-sbo x")).is_err());
        assert_eq!(parse_args(&a("dev vlc")).unwrap(), Cmd::Dev("vlc".into()));
        assert!(parse_args(&a("dev ../x")).is_err());
        let Cmd::Build(o) = parse_args(&a("build --dev vlc --use-dev libplacebo --arch i586")).unwrap() else { panic!() };
        assert!(o.dev);
        assert_eq!(o.use_dev, vec!["libplacebo"]);
        assert_eq!(o.arch, Some(Arch::I586));
        assert_eq!(o.pkg.as_deref(), Some("vlc"));
        assert!(parse_args(&a("build")).is_err());
        assert!(parse_args(&a("build vlc mpv")).is_err());
        assert!(parse_args(&a("build vlc --use-dev vlc")).is_err());
        assert!(parse_args(&a("build vlc --arch arm")).is_err());
        assert!(parse_args(&a("lint vlc --use-dev x")).is_err());
        assert!(parse_args(&a("frobnicate")).is_err());
    }
}
