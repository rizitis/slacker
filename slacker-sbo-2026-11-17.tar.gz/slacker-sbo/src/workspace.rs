// WORK_DIR: the lock, hooks/ (kept), and the work area mounted at mnt/
// (a loop image or a tmpfs) that holds the sandboxes and the dependency cache.

use anyhow::{bail, Context, Result};
use std::fs::File;
use std::os::unix::io::AsRawFd;
use std::path::PathBuf;

use crate::conf::{Arch, Conf, WorkFs};
use crate::util;

pub struct Workspace {
    pub conf: Conf,
    _lock: File,
}

impl Workspace {
    /// Takes the lock: only one slacker-sbo at a time.
    pub fn open(conf: Conf) -> Result<Workspace> {
        util::mkdir_root(&conf.work_dir, 0o700)?;
        util::mkdir_root(&conf.hooks_dir(), 0o700)?;
        let path = conf.work_dir.join("lock");
        let f = File::options().create(true).truncate(false).write(true).open(&path).with_context(|| format!("opening {}", path.display()))?;
        // SAFETY: flock on a file we hold open.
        if unsafe { libc::flock(f.as_raw_fd(), libc::LOCK_EX | libc::LOCK_NB) } != 0 {
            bail!("another slacker-sbo is running (lock {})", path.display());
        }
        Ok(Workspace { conf, _lock: f })
    }

    pub fn mnt(&self) -> PathBuf {
        self.conf.work_dir.join("mnt")
    }

    fn image(&self) -> PathBuf {
        self.conf.work_dir.join("work.img")
    }

    pub fn sandboxes(&self) -> PathBuf {
        self.mnt().join("sandboxes")
    }

    pub fn cache(&self, arch: Arch) -> PathBuf {
        self.mnt().join("cache").join(arch.name())
    }

    /// Scratch space for the tool itself (keyrings, temporary files), root only.
    pub fn tmp(&self) -> PathBuf {
        self.mnt().join("tmp")
    }

    /// Mounts the work area if it is not mounted yet. It stays mounted on the
    /// host (nosuid,nodev) so a built package can be copied out by hand.
    pub fn mount(&self) -> Result<()> {
        let mnt = self.mnt();
        if util::is_mountpoint(&mnt) {
            if self.conf.work_fs == WorkFs::Loop {
                let size = std::fs::metadata(self.image()).map(|m| m.len()).unwrap_or(0);
                if size != self.conf.work_size {
                    eprintln!("note: WORK_SIZE changed; the new size applies after slacker-sbo clean");
                }
            }
        } else {
            util::mkdir_root(&mnt, 0o700)?;
            match self.conf.work_fs {
                WorkFs::Loop => {
                    let img = self.image();
                    if !img.exists() {
                        let f = File::create(&img).with_context(|| format!("creating {}", img.display()))?;
                        f.set_len(self.conf.work_size)?;
                        drop(f);
                        let mut c = util::as_root("mkfs.ext4");
                        c.args(["-q", "-F", "-m", "0", "-L", "slacker-sbo"]).arg(&img);
                        util::run(c, "mkfs.ext4")?;
                    }
                    let mut c = util::as_root("mount");
                    c.args(["-o", "loop,nosuid,nodev"]).arg(&img).arg(&mnt);
                    util::run(c, "mounting the work image")?;
                }
                WorkFs::Tmpfs => {
                    let mut c = util::as_root("mount");
                    c.args(["-t", "tmpfs", "-o", &format!("size={},mode=700,nosuid,nodev", self.conf.work_size), "slacker-sbo"]).arg(&mnt);
                    util::run(c, "mounting the work tmpfs")?;
                }
            }
        }
        util::mkdir_root(&mnt, 0o700)?;
        for d in [self.sandboxes(), self.tmp(), self.cache(Arch::X86_64), self.cache(Arch::I586)] {
            util::mkdir_root(&d, 0o700)?;
        }
        Ok(())
    }

    /// Sandboxes and the dependency cache go: the work area is unmounted and
    /// its image deleted. hooks/ stays.
    pub fn clean(&self) -> Result<()> {
        let mnt = self.mnt();
        if util::is_mountpoint(&mnt) {
            let mut c = util::as_root("umount");
            c.arg(&mnt);
            util::run(c, "unmounting the work area (is a shell still open in it?)")?;
        }
        util::remove_tree(&self.image())?;
        util::remove_tree(&mnt)?;
        Ok(())
    }
}
