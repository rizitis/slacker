// update-slackware: Slackware 15.0 packages from the mirror (as GIT_USER),
// checked with GPG and md5, then installed into a fresh base tree inside a
// sandbox where the host is read-only. The old tree stays until the new one
// is complete.

use anyhow::{bail, Context, Result};
use std::collections::HashMap;
use std::path::{Path, PathBuf};

use crate::cgroup::Cgroup;
use crate::conf::{Arch, Conf, TreeSource};
use crate::sandbox::{self, Root, Spec};
use crate::util;
use crate::workspace::Workspace;

/// What rc.M of 15.0 updates at boot, with its own conditions and in its
/// order, run once in the new tree so it looks like a system booted once.
pub const FIRST_BOOT: &str = r#"
[ -x /sbin/ldconfig ] && /sbin/ldconfig
[ -x /usr/bin/fc-cache ] && /usr/bin/fc-cache -f
if find /usr/share/icons -maxdepth 2 2> /dev/null | grep -q icon-theme.cache ; then
  for theme_dir in /usr/share/icons/* ; do
    if [ -r ${theme_dir}/icon-theme.cache ]; then
      /usr/bin/gtk-update-icon-cache -t -f ${theme_dir} 1> /dev/null 2> /dev/null
    fi
  done
  rm -f /usr/share/icons/icon-theme.cache
fi
if [ -x /usr/bin/update-mime-database -a -d /usr/share/mime ]; then
  /usr/bin/update-mime-database /usr/share/mime 1> /dev/null 2> /dev/null
fi
[ -x /usr/bin/update-gtk-immodules ] && /usr/bin/update-gtk-immodules > /dev/null 2>&1
[ -x /usr/bin/update-gdk-pixbuf-loaders ] && HOME=/root /usr/bin/update-gdk-pixbuf-loaders > /dev/null 2>&1
[ -x /usr/bin/update-pango-querymodules ] && /usr/bin/update-pango-querymodules > /dev/null 2>&1
[ -x /usr/bin/glib-compile-schemas ] && /usr/bin/glib-compile-schemas /usr/share/glib-2.0/schemas >/dev/null 2>&1
exit 0
"#;

/// Slackware Linux Project <security@slackware.com>
const SLACKWARE_KEY: &str = "EC5649DA401E22ABFA6736EF6A4463C040102233";

pub struct Tree {
    pub arch: Arch,
    /// slackware64 or slackware
    pub pkgdir: &'static str,
    /// Where the packages are on this machine: the local tree, or the rsync copy.
    pub dir: PathBuf,
    /// For messages: the TREE_* value.
    pub label: String,
}

pub fn tree(conf: &Conf, arch: Arch) -> Option<Tree> {
    let src = conf.trees.iter().find(|(a, _)| *a == arch).map(|(_, s)| s)?;
    let pkgdir = match arch {
        Arch::X86_64 => "slackware64",
        Arch::I586 => "slackware",
    };
    let (dir, label) = match src {
        TreeSource::Local(p) => (p.clone(), p.display().to_string()),
        TreeSource::Rsync(u) => (conf.mirror_dir.join(arch.name()), u.clone()),
    };
    Some(Tree { arch, pkgdir, dir, label })
}

fn is_pkg(p: &str) -> bool {
    [".txz", ".tgz", ".tbz", ".tlz"].iter().any(|e| p.ends_with(e))
}

pub fn update(ws: &Workspace) -> Result<()> {
    let conf = &ws.conf;
    let user = util::user(&conf.git_user)?;
    ws.mount()?;
    let trees: Vec<Tree> = conf.arch.iter().filter_map(|&a| tree(conf, a)).collect();
    for t in &trees {
        if let Some((_, TreeSource::Rsync(url))) = conf.trees.iter().find(|(a, _)| *a == t.arch) {
            if !conf.mirror_dir.exists() {
                std::fs::create_dir_all(&conf.mirror_dir)?;
                util::chown(&conf.mirror_dir, user.uid, user.gid)?;
            }
            println!("==> {}: syncing from {url}", t.arch.name());
            sync(&user, url, t)?;
        } else {
            println!("==> {}: local tree {}", t.arch.name(), t.label);
        }
        check_layout(t)?;
    }
    for t in &trees {
        if conf.mirror_gpg {
            println!("==> {}: checking the GPG signature of CHECKSUMS.md5", t.arch.name());
            check_gpg(ws, &t.dir)?;
        } else {
            println!("==> {}: MIRROR_GPG=\"no\", GPG check skipped", t.arch.name());
        }
        println!("==> {}: checking md5 of every package", t.arch.name());
        let (base, patches) = check_md5(t)?;
        println!("    {} packages, {} patches", base.len(), patches.len());
        install(ws, t, &base, &patches)?;
    }
    Ok(())
}

/// What a 15.0 tree must have, whatever its directory is called.
fn check_layout(t: &Tree) -> Result<()> {
    let mut need = vec![t.pkgdir.to_string(), "patches/packages".into(), "CHECKSUMS.md5".into()];
    let mut missing = Vec::new();
    for f in ["CHECKSUMS.md5.asc", "GPG-KEY"] {
        need.push(f.into());
    }
    for n in &need {
        if !t.dir.join(n).exists() {
            missing.push(n.clone());
        }
    }
    if !missing.is_empty() {
        bail!("{}: not a Slackware 15.0 {} tree, missing: {}", t.label, t.arch.name(), missing.join(", "));
    }
    Ok(())
}

fn sync(user: &util::User, url: &str, t: &Tree) -> Result<()> {
    let dst = &t.dir;
    for d in [dst.clone(), dst.join(t.pkgdir), dst.join("patches"), dst.join("patches/packages")] {
        if !d.exists() {
            std::fs::create_dir(&d).with_context(|| format!("creating {}", d.display()))?;
            util::chown(&d, user.uid, user.gid)?;
        }
    }
    let src = url.to_string();
    let rsync = |args: &[String]| -> Result<()> {
        let mut c = util::as_user(user, "rsync");
        c.args(["-rlt", "--delete", "--info=progress2"]).args(args);
        util::run(c, "rsync")
    };
    rsync(&[format!("{src}/{}/", t.pkgdir), format!("{}/", dst.join(t.pkgdir).display())])?;
    rsync(&[format!("{src}/patches/packages/"), format!("{}/", dst.join("patches/packages").display())])?;
    let mut files: Vec<String> = ["CHECKSUMS.md5", "CHECKSUMS.md5.asc", "GPG-KEY", "ChangeLog.txt"].iter().map(|f| format!("{src}/{f}")).collect();
    files.push(format!("{}/", dst.display()));
    let mut c = util::as_user(user, "rsync");
    c.args(["-lt"]).args(&files);
    util::run(c, "rsync")
}

/// The signature must be valid and made by the Slackware key, checked by its
/// full fingerprint, not by whatever GPG-KEY the mirror ships.
fn check_gpg(ws: &Workspace, dir: &Path) -> Result<()> {
    let home = ws.tmp().join("gnupg");
    util::remove_tree(&home)?;
    util::mkdir_root(&home, 0o700)?;
    let mut c = util::as_root("gpg");
    c.arg("--homedir").arg(&home).args(["--batch", "--quiet", "--import"]).arg(dir.join("GPG-KEY"));
    util::output(c, "gpg --import")?;
    let mut c = util::as_root("gpg");
    c.arg("--homedir").arg(&home).args(["--batch", "--status-fd", "1", "--verify"]).arg(dir.join("CHECKSUMS.md5.asc")).arg(dir.join("CHECKSUMS.md5"));
    let out = c.output().context("running gpg --verify")?;
    let status = String::from_utf8_lossy(&out.stdout);
    util::remove_tree(&home)?;
    // VALIDSIG <sig fpr> ... <primary key fpr>
    let ok = out.status.success()
        && status.lines().any(|l| l.starts_with("[GNUPG:] VALIDSIG ") && l.split_whitespace().last() == Some(SLACKWARE_KEY));
    if !ok {
        bail!("{}: CHECKSUMS.md5 is not signed by the Slackware key {SLACKWARE_KEY}", dir.display());
    }
    Ok(())
}

/// Every package listed under the package directory and patches/packages must
/// be present with the right md5, and nothing unlisted may be there.
/// Returns (base packages, patch packages), as paths, in install order.
/// Paths are relative to the tree.
pub fn check_md5(t: &Tree) -> Result<(Vec<PathBuf>, Vec<PathBuf>)> {
    let dir = t.dir.as_path();
    let text = std::fs::read_to_string(dir.join("CHECKSUMS.md5")).context("reading CHECKSUMS.md5")?;
    let mut want: HashMap<String, String> = HashMap::new();
    let prefixes = [format!("./{}/", t.pkgdir), "./patches/packages/".to_string()];
    for l in text.lines() {
        let mut it = l.split_whitespace();
        let (Some(sum), Some(path), None) = (it.next(), it.next(), it.next()) else { continue };
        if sum.len() == 32 && prefixes.iter().any(|p| path.starts_with(p.as_str())) && is_pkg(path) {
            // These names go into a shell script inside the sandbox.
            if path.contains("/../") || !path.bytes().all(|b| b.is_ascii_alphanumeric() || b"./_+-".contains(&b)) {
                bail!("CHECKSUMS.md5: bad path {path}");
            }
            want.insert(path.trim_start_matches("./").to_string(), sum.to_ascii_lowercase());
        }
    }
    if want.is_empty() {
        bail!("CHECKSUMS.md5 lists no packages for {}", t.pkgdir);
    }
    // What is on disk.
    let mut have = Vec::new();
    for top in [t.pkgdir, "patches/packages"] {
        walk(&dir.join(top), &mut |p| {
            let rel = p.strip_prefix(dir).unwrap().to_string_lossy().to_string();
            if is_pkg(&rel) {
                have.push(rel);
            }
        })?;
    }
    for h in &have {
        if !want.contains_key(h) {
            bail!("{h} is in the mirror but not in CHECKSUMS.md5");
        }
    }
    let mut base = Vec::new();
    let mut patches = Vec::new();
    let mut keys: Vec<&String> = want.keys().collect();
    keys.sort();
    for k in keys {
        let p = dir.join(k);
        let m = std::fs::symlink_metadata(&p).with_context(|| format!("{k} is missing from the mirror"))?;
        if !m.is_file() {
            bail!("{k} is not a regular file");
        }
        if util::md5_file(&p)? != want[k] {
            bail!("{k}: md5 does not match CHECKSUMS.md5");
        }
        if k.starts_with("patches/") {
            patches.push(PathBuf::from(k));
        } else {
            base.push(PathBuf::from(k));
        }
    }
    Ok((base, patches))
}

fn walk(dir: &Path, f: &mut dyn FnMut(&Path)) -> Result<()> {
    for e in std::fs::read_dir(dir).with_context(|| format!("reading {}", dir.display()))? {
        let e = e?;
        let ft = e.file_type()?;
        if ft.is_dir() {
            walk(&e.path(), f)?;
        } else {
            f(&e.path());
        }
    }
    Ok(())
}

fn install(ws: &Workspace, t: &Tree, base: &[PathBuf], patches: &[PathBuf]) -> Result<()> {
    let conf = &ws.conf;
    util::mkdir_root(&conf.base_dir, 0o700)?;
    let final_dir = conf.base_tree(t.arch);
    // Next to the tree, not in it: nothing of ours shows inside a build.
    let stamp_file = conf.base_dir.join(format!("{}.checksums", t.arch.name()));
    let stamp = util::md5_file(&t.dir.join("CHECKSUMS.md5"))?;
    if final_dir.is_dir() && std::fs::read_to_string(&stamp_file).ok().as_deref() == Some(stamp.as_str()) {
        println!("==> {}: base tree is up to date", t.arch.name());
        return Ok(());
    }
    let new = conf.base_dir.join(format!("{}.new", t.arch.name()));
    util::remove_tree(&new)?;
    util::remove_tree(&stamp_file)?;
    std::fs::create_dir(&new)?;
    util::chown(&new, conf.subid_base, conf.subid_base)?;

    let pkgtools = base
        .iter()
        .find(|p| p.file_name().is_some_and(|n| n.to_string_lossy().starts_with("pkgtools-")))
        .context("pkgtools is not in the mirror")?;
    // The package lists are too long for one argument: they go into files
    // in the new tree (removed again below), read with xargs.
    let write_list = |name: &str, v: &[PathBuf]| -> Result<()> {
        let text: String = v.iter().map(|p| format!("/mnt/tree/{}\n", p.display())).collect();
        std::fs::write(new.join(name), text).with_context(|| format!("writing {name}"))
    };
    write_list(".slacker-sbo-base.list", base)?;
    write_list(".slacker-sbo-patches.list", patches)?;
    // Base packages with the pkgtools of this release (not the host's: the
    // host may run the development branch), then the patches with upgradepkg
    // inside the new tree. /proc and /dev for the doinst.sh scripts exist
    // only inside this sandbox and end with it.
    let mut script = format!(
        "set -e\n\
         T=/mnt/target\n\
         mkdir /tmp/pkgtools\n\
         tar -xf '/mnt/tree/{}' -C /tmp/pkgtools sbin\n\
         export PATH=/tmp/pkgtools/sbin:$PATH\n\
         mkdir -p $T/proc $T/dev $T/tmp\n\
         mount -t proc proc $T/proc\n\
         mount --rbind /dev $T/dev\n\
         xargs installpkg --terse --root $T < $T/.slacker-sbo-base.list\n",
        pkgtools.display(),
    );
    if !patches.is_empty() {
        script.push_str(
            "mkdir $T/tmp/slacker-sbo-patches\n\
             xargs cp -t $T/tmp/slacker-sbo-patches < $T/.slacker-sbo-patches.list\n\
             chroot $T /bin/sh -c '/sbin/upgradepkg --install-new /tmp/slacker-sbo-patches/*.t?z'\n\
             rm -rf $T/tmp/slacker-sbo-patches\n",
        );
    }
    script.push_str("rm -f $T/.slacker-sbo-base.list $T/.slacker-sbo-patches.list\n");
    script.push_str(&format!("echo '==> first boot caches, as rc.M does them'\nchroot $T /bin/sh -c '{}'\n", FIRST_BOOT.replace('\'', "'\\''")));
    let merged = ws.tmp().join(format!("install-{}", t.arch.name()));
    util::remove_tree(&merged)?;
    std::fs::create_dir(&merged)?;
    println!("==> {}: installing {} packages and {} patches into a new base tree", t.arch.name(), base.len(), patches.len());
    let cg = Cgroup::create(conf, &format!("install-{}", t.arch.name()))?;
    let outcome = sandbox::run(Spec {
        root: Root::HostReadOnly { target: new.clone(), tree: Some(t.dir.clone()), merged: merged.clone() },
        subid_base: conf.subid_base,
        arch: t.arch,
        argv: vec!["/bin/sh".into(), "-c".into(), script],
        env: vec![("PATH".into(), util::SAFE_PATH.into()), ("HOME".into(), "/root".into()), ("LANG".into(), "C".into())],
        cwd: "/".into(),
        cgroup: &cg,
    });
    cg.destroy()?;
    util::remove_tree(&merged)?;
    let outcome = outcome?;
    if !outcome.ok() {
        bail!("installing the {} base tree failed (status {}); the old tree is kept", t.arch.name(), outcome.status);
    }
    let old = conf.base_dir.join(format!("{}.old", t.arch.name()));
    util::remove_tree(&old)?;
    if final_dir.exists() {
        std::fs::rename(&final_dir, &old)?;
    }
    std::fs::rename(&new, &final_dir)?;
    std::fs::write(&stamp_file, &stamp)?;
    util::remove_tree(&old)?;
    println!("==> {}: base tree ready", t.arch.name());
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    // On a machine with a real base tree: SBO_TEST_BASE=/srv/sbo/base/x86_64
    #[test]
    #[ignore]
    fn first_boot_caches_on_a_real_tree() {
        let Ok(base) = std::env::var("SBO_TEST_BASE") else { return };
        let conf = crate::conf::Conf::from_text(
            "MIRROR_DIR=\"/srv/t/m\"\nBASE_DIR=\"/srv/t/b\"\nGIT_USER=\"nobody\"\nGIT_DIR=\"/srv/t/g\"\nFORK_URL=\"x\"\nUPSTREAM_URL=\"y\"\nSRC_DIR=\"/srv/t/s\"\nWORK_DIR=\"/srv/t/w\"\nCGROUP_MISSING=\"warn\"\n",
        )
        .unwrap();
        let merged = PathBuf::from(format!("/tmp/sbo-fb-{}", std::process::id()));
        std::fs::create_dir_all(&merged).unwrap();
        let script = format!(
            "set -e\nT=/mnt/target\nmount -t proc proc $T/proc\nmount --rbind /dev $T/dev\nchroot $T /bin/sh -c '{}'\n",
            FIRST_BOOT.replace('\'', "'\\''")
        );
        let cg = Cgroup::create(&conf, "test-firstboot").unwrap();
        let out = sandbox::run(Spec {
            root: Root::HostReadOnly { target: base.clone().into(), tree: None, merged: merged.clone() },
            subid_base: 100000,
            arch: Arch::X86_64,
            argv: vec!["/bin/sh".into(), "-c".into(), script],
            env: vec![("PATH".into(), util::SAFE_PATH.into())],
            cwd: "/".into(),
            cgroup: &cg,
        })
        .unwrap();
        cg.destroy().unwrap();
        let _ = std::fs::remove_dir(&merged);
        assert!(out.ok(), "status {}", out.status);
        let b = Path::new(&base);
        assert!(std::fs::read_dir(b.join("var/cache/fontconfig")).unwrap().count() > 0, "no font cache");
        assert!(b.join("usr/share/glib-2.0/schemas/gschemas.compiled").is_file());
        assert!(b.join("usr/share/mime/mime.cache").is_file());
    }
}

