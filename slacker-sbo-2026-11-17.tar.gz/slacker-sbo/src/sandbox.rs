// The sandbox. Root inside is uid SUBID_BASE outside: nothing that runs in
// here is root on the host.
//
//   tool (real root)
//    └─ C1: private mount ns, root fs mounted (as real root), then a new
//       user ns; the tool writes its uid/gid map and puts it in the cgroup
//        └─ C2: pid 1 of new pid/mount/net/ipc/uts/cgroup namespaces,
//           mounts /proc /dev/pts /dev/shm, pivot_root, reaps orphans
//            └─ C3: the command

use anyhow::{bail, Context, Result};
use std::ffi::CString;
use std::os::unix::process::CommandExt;
use std::path::{Path, PathBuf};

use crate::cgroup::Cgroup;
use crate::conf::Arch;

const HOSTNAME: &str = "slacker-sbo";
const SETUP_FAILED: i32 = 125;
// <linux/personality.h>: 32-bit uname -m (i686) for i586 builds.
const PER_LINUX32: libc::c_ulong = 0x0008;

pub enum Root {
    /// Base tree (read-only) under an overlay whose upper layer keeps the changes.
    Overlay { lower: PathBuf, upper: PathBuf, work: PathBuf, merged: PathBuf },
    /// The host / read-only, with `target` writable at /mnt/target and
    /// `tree` (a Slackware tree) read-only at /mnt/tree.
    /// Used only to install Slackware packages into an empty base tree.
    HostReadOnly { target: PathBuf, tree: Option<PathBuf>, merged: PathBuf },
}

pub struct Spec<'a> {
    pub root: Root,
    pub subid_base: u32,
    pub arch: Arch,
    pub argv: Vec<String>,
    pub env: Vec<(String, String)>,
    pub cwd: String,
    pub cgroup: &'a Cgroup,
}

fn cstr(s: &str) -> CString {
    CString::new(s).expect("no NUL in paths")
}

fn cpath(p: &Path) -> CString {
    cstr(&p.to_string_lossy())
}

fn errno() -> std::io::Error {
    std::io::Error::last_os_error()
}

fn mount(src: &str, dst: &Path, fstype: &str, flags: libc::c_ulong, data: Option<&str>) -> Result<()> {
    let (s, d, t) = (cstr(src), cpath(dst), cstr(fstype));
    let data = data.map(cstr);
    // SAFETY: valid NUL-terminated strings for the duration of the call.
    let r = unsafe {
        libc::mount(
            s.as_ptr(),
            d.as_ptr(),
            if fstype.is_empty() { std::ptr::null() } else { t.as_ptr() },
            flags,
            data.as_ref().map_or(std::ptr::null(), |c| c.as_ptr().cast()),
        )
    };
    if r != 0 {
        bail!("mount {src} on {} ({fstype}): {}", dst.display(), errno());
    }
    Ok(())
}

fn bind(src: &Path, dst: &Path) -> Result<()> {
    mount(&src.to_string_lossy(), dst, "", libc::MS_BIND, None)
}

const OPEN_TREE_CLONE: libc::c_uint = 1;
const OPEN_TREE_CLOEXEC: libc::c_uint = libc::O_CLOEXEC as libc::c_uint;
const MOVE_MOUNT_F_EMPTY_PATH: libc::c_uint = 0x4;
const MOVE_MOUNT_T_EMPTY_PATH: libc::c_uint = 0x40;

#[repr(C)]
struct MountAttr {
    attr_set: u64,
    attr_clr: u64,
    propagation: u64,
    userns_fd: u64,
}

const MOUNT_ATTR_RDONLY: u64 = 0x1;
const MOUNT_ATTR_NOSUID: u64 = 0x2;
const MOUNT_ATTR_NODEV: u64 = 0x4;
const AT_RECURSIVE: libc::c_uint = 0x8000;

/// Makes a whole mount tree read-only, nosuid and nodev (mount_setattr, Linux 5.12).
fn readonly_tree(p: &Path) -> Result<()> {
    let c = cpath(p);
    let attr = MountAttr { attr_set: MOUNT_ATTR_RDONLY | MOUNT_ATTR_NOSUID | MOUNT_ATTR_NODEV, attr_clr: 0, propagation: 0, userns_fd: 0 };
    // SAFETY: mount_setattr with a properly sized struct.
    let r = unsafe {
        libc::syscall(libc::SYS_mount_setattr, libc::AT_FDCWD, c.as_ptr(), AT_RECURSIVE, &attr as *const MountAttr, std::mem::size_of::<MountAttr>())
    };
    if r != 0 {
        bail!("making {} read-only: {}", p.display(), errno());
    }
    Ok(())
}

fn touch(p: &Path) -> Result<()> {
    std::fs::OpenOptions::new().create(true).truncate(false).write(true).open(p).with_context(|| format!("creating {}", p.display()))?;
    Ok(())
}

fn pipe() -> Result<(i32, i32)> {
    let mut fds = [0; 2];
    // SAFETY: pipe2 fills two fds.
    if unsafe { libc::pipe2(fds.as_mut_ptr(), libc::O_CLOEXEC) } != 0 {
        bail!("pipe: {}", errno());
    }
    Ok((fds[0], fds[1]))
}

fn send(fd: i32) -> bool {
    // SAFETY: one byte to a pipe we own.
    unsafe { libc::write(fd, b"x".as_ptr().cast(), 1) == 1 }
}

fn recv(fd: i32) -> bool {
    let mut b = [0u8; 1];
    // SAFETY: one byte from a pipe we own.
    unsafe { libc::read(fd, b.as_mut_ptr().cast(), 1) == 1 }
}

fn die(stage: &str, e: anyhow::Error) -> ! {
    let msg = format!("slacker-sbo: sandbox: {stage}: {e:#}\n");
    // SAFETY: straight to fd 2 (no buffering left over from the parent), then leave
    // the forked child without running the parent's destructors.
    unsafe {
        libc::write(2, msg.as_ptr().cast(), msg.len());
        libc::_exit(SETUP_FAILED)
    }
}

fn wait_status(pid: libc::pid_t) -> i32 {
    let mut st = 0;
    loop {
        // SAFETY: waitpid on our own child.
        let r = unsafe { libc::waitpid(pid, &mut st, 0) };
        if r == pid {
            break;
        }
        if r < 0 && errno().raw_os_error() != Some(libc::EINTR) {
            return SETUP_FAILED;
        }
    }
    decode(st)
}

fn decode(st: i32) -> i32 {
    if libc::WIFEXITED(st) {
        libc::WEXITSTATUS(st)
    } else if libc::WIFSIGNALED(st) {
        128 + libc::WTERMSIG(st)
    } else {
        SETUP_FAILED
    }
}

pub struct Outcome {
    pub status: i32,
    /// The build reached BUILD_MEM and was stopped as a whole.
    pub out_of_memory: bool,
}

impl Outcome {
    pub fn ok(&self) -> bool {
        self.status == 0 && !self.out_of_memory
    }
}

/// Runs the command in a fresh sandbox.
pub fn run(spec: Spec) -> Result<Outcome> {
    let (c2p_r, c2p_w) = pipe()?;
    let (p2c_r, p2c_w) = pipe()?;
    // The terminal's Ctrl-C reaches the command; the tool stays to clean up.
    // SAFETY: setting signal dispositions.
    let (old_int, old_quit) = unsafe { (libc::signal(libc::SIGINT, libc::SIG_IGN), libc::signal(libc::SIGQUIT, libc::SIG_IGN)) };
    let parent = std::process::id() as libc::pid_t;

    // SAFETY: the tool is single-threaded here; the child only uses what it needs and exits.
    let pid = unsafe { libc::fork() };
    if pid < 0 {
        bail!("fork: {}", errno());
    }
    if pid == 0 {
        // SAFETY: closing the parent's ends and resetting signals in the child.
        unsafe {
            libc::close(c2p_r);
            libc::close(p2c_w);
            libc::signal(libc::SIGINT, libc::SIG_DFL);
            libc::signal(libc::SIGQUIT, libc::SIG_DFL);
            libc::prctl(libc::PR_SET_PDEATHSIG, libc::SIGKILL);
            if libc::getppid() != parent {
                libc::_exit(SETUP_FAILED);
            }
        }
        child1(&spec, c2p_w, p2c_r);
    }

    // SAFETY: closing the child's ends.
    unsafe {
        libc::close(c2p_w);
        libc::close(p2c_r);
    }
    let result = (|| -> Result<()> {
        if !recv(c2p_r) {
            bail!("sandbox setup failed before the user namespace");
        }
        let map = format!("0 {} 65536\n", spec.subid_base);
        std::fs::write(format!("/proc/{pid}/uid_map"), &map).context("writing uid_map")?;
        std::fs::write(format!("/proc/{pid}/gid_map"), &map).context("writing gid_map")?;
        spec.cgroup.add(pid)?;
        if !send(p2c_w) {
            bail!("sandbox child went away");
        }
        Ok(())
    })();
    // SAFETY: closing our pipe ends.
    unsafe {
        libc::close(c2p_r);
        libc::close(p2c_w);
    }
    if let Err(e) = result {
        // SAFETY: the child is ours.
        unsafe { libc::kill(pid, libc::SIGKILL) };
        wait_status(pid);
        restore(old_int, old_quit);
        return Err(e);
    }
    // Wait, watching for the memory limit: when the kernel kills anything for
    // memory, the whole build goes, so no half-built package can come out.
    let mut out_of_memory = false;
    let status = loop {
        let mut st = 0;
        // SAFETY: non-blocking waitpid on our own child.
        let r = unsafe { libc::waitpid(pid, &mut st, libc::WNOHANG) };
        if r == pid {
            break decode(st);
        }
        if r < 0 && errno().raw_os_error() != Some(libc::EINTR) {
            break SETUP_FAILED;
        }
        if !out_of_memory && spec.cgroup.oom_killed() {
            out_of_memory = true;
            eprintln!("slacker-sbo: the build reached BUILD_MEM and was stopped");
            if let Err(e) = spec.cgroup.kill_all() {
                eprintln!("slacker-sbo: {e:#}");
            }
        }
        std::thread::sleep(std::time::Duration::from_millis(200));
    };
    restore(old_int, old_quit);
    if status == SETUP_FAILED && !out_of_memory {
        bail!("sandbox setup failed (see the message above)");
    }
    Ok(Outcome { status, out_of_memory })
}

fn restore(i: libc::sighandler_t, q: libc::sighandler_t) {
    // SAFETY: restoring the dispositions saved above.
    unsafe {
        libc::signal(libc::SIGINT, i);
        libc::signal(libc::SIGQUIT, q);
    }
}

fn merged_of(root: &Root) -> &Path {
    match root {
        Root::Overlay { merged, .. } | Root::HostReadOnly { merged, .. } => merged,
    }
}

// C1: still real root, in the host's user namespace.
fn child1(spec: &Spec, to_parent: i32, from_parent: i32) -> ! {
    let root_fd = match prepare_root(spec) {
        Ok(fd) => fd,
        Err(e) => die("preparing the root", e),
    };
    // The working directory follows into the copies of later mount
    // namespaces; an fd would keep pointing into this one.
    // SAFETY: fchdir/close on the fd we just opened.
    unsafe {
        if libc::fchdir(root_fd) != 0 {
            die("entering the new root", errno().into());
        }
        libc::close(root_fd);
    }
    // SAFETY: unshare in a single-threaded child.
    if unsafe { libc::unshare(libc::CLONE_NEWUSER) } != 0 {
        die("user namespace", errno().into());
    }
    if !send(to_parent) || !recv(from_parent) {
        die("waiting for the id map", anyhow::anyhow!("parent went away"));
    }
    // SAFETY: becoming root of the new user namespace (mapped to subid_base outside).
    unsafe {
        if libc::setresgid(0, 0, 0) != 0 || libc::setgroups(0, std::ptr::null()) != 0 || libc::setresuid(0, 0, 0) != 0 {
            die("becoming root in the user namespace", errno().into());
        }
        let flags = libc::CLONE_NEWNS | libc::CLONE_NEWPID | libc::CLONE_NEWNET | libc::CLONE_NEWIPC | libc::CLONE_NEWUTS | libc::CLONE_NEWCGROUP;
        if libc::unshare(flags) != 0 {
            die("namespaces", errno().into());
        }
    }
    // SAFETY: fork in a single-threaded child.
    let pid = unsafe { libc::fork() };
    if pid < 0 {
        die("fork", errno().into());
    }
    if pid == 0 {
        // SAFETY: die with C1. (C1 is outside the new pid namespace, so getppid() is 0 here.)
        unsafe { libc::prctl(libc::PR_SET_PDEATHSIG, libc::SIGKILL) };
        child2(spec);
    }
    let st = wait_status(pid);
    // SAFETY: leaving the forked child.
    unsafe { libc::_exit(st) }
}

// Done as real root in C1's own mount namespace: the overlay uses the
// trusted xattrs this way and works on ext4 and tmpfs alike. Nothing here
// is visible on the host. Returns an O_PATH fd of the new root: inside the
// user namespace no host path is resolved again.
fn prepare_root(spec: &Spec) -> Result<i32> {
    // SAFETY: unshare in a single-threaded child.
    if unsafe { libc::unshare(libc::CLONE_NEWNS) } != 0 {
        bail!("mount namespace: {}", errno());
    }
    mount("none", Path::new("/"), "", libc::MS_REC | libc::MS_PRIVATE, None)?;
    let shift = spec.subid_base;
    match &spec.root {
        Root::Overlay { lower, upper, work, merged } => {
            let data = format!("lowerdir={},upperdir={},workdir={}", lower.display(), upper.display(), work.display());
            mount("overlay", merged, "overlay", 0, Some(&data))?;
        }
        Root::HostReadOnly { target, tree, merged } => {
            mount("/", merged, "", libc::MS_BIND | libc::MS_REC, None)?;
            readonly_tree(merged)?;
            // Writable spots on top of the read-only host tree.
            let own = format!("mode=755,uid={shift},gid={shift}");
            mount("tmpfs", &merged.join("mnt"), "tmpfs", libc::MS_NOSUID | libc::MS_NODEV, Some(&own))?;
            let t = merged.join("mnt/target");
            std::fs::create_dir(&t)?;
            bind(target, &t)?;
            // Bound by real root: a tree inside a 0700 home directory works too.
            if let Some(tree) = tree {
                let m = merged.join("mnt/tree");
                std::fs::create_dir(&m)?;
                bind(tree, &m)?;
                mount("none", &m, "", libc::MS_BIND | libc::MS_REMOUNT | libc::MS_RDONLY | libc::MS_NOSUID | libc::MS_NODEV, None)?;
            }
            for d in ["tmp", "var/tmp", "run"] {
                let p = merged.join(d);
                if p.is_dir() {
                    mount("tmpfs", &p, "tmpfs", libc::MS_NOSUID | libc::MS_NODEV, Some(&format!("mode=1777,uid={shift},gid={shift}")))?;
                }
            }
        }
    }
    let merged = merged_of(&spec.root);
    // A minimal /dev: no disks, no host devices beyond these.
    let dev = merged.join("dev");
    if !dev.is_dir() {
        bail!("{} has no /dev", merged.display());
    }
    mount("tmpfs", &dev, "tmpfs", libc::MS_NOSUID | libc::MS_NOEXEC, Some(&format!("mode=755,uid={shift},gid={shift}")))?;
    for d in ["null", "zero", "full", "random", "urandom", "tty"] {
        let p = dev.join(d);
        touch(&p)?;
        bind(&Path::new("/dev").join(d), &p)?;
    }
    for d in ["pts", "shm"] {
        std::fs::create_dir(dev.join(d))?;
    }
    for (l, t) in [("fd", "/proc/self/fd"), ("stdin", "/proc/self/fd/0"), ("stdout", "/proc/self/fd/1"), ("stderr", "/proc/self/fd/2"), ("ptmx", "pts/ptmx")] {
        std::os::unix::fs::symlink(t, dev.join(l))?;
    }
    for p in [dev.clone(), dev.join("pts"), dev.join("shm")] {
        // SAFETY: chown of paths we just created.
        let c = cpath(&p);
        unsafe { libc::lchown(c.as_ptr(), shift, shift) };
    }
    let c = cpath(merged);
    // SAFETY: open(2) with O_PATH; the fd is checked.
    let fd = unsafe { libc::open(c.as_ptr(), libc::O_PATH | libc::O_DIRECTORY | libc::O_CLOEXEC) };
    if fd < 0 {
        bail!("opening {}: {}", merged.display(), errno());
    }
    Ok(fd)
}

// C2: pid 1 of the sandbox, root of the user namespace.
fn child2(spec: &Spec) -> ! {
    if let Err(e) = enter(spec) {
        die("entering the sandbox", e);
    }
    let mut cmd = std::process::Command::new(&spec.argv[0]);
    cmd.args(&spec.argv[1..]).env_clear().envs(spec.env.iter().map(|(k, v)| (k, v))).current_dir(&spec.cwd);
    // SAFETY: only async-signal-safe calls between fork and exec.
    unsafe {
        cmd.pre_exec(|| {
            libc::signal(libc::SIGINT, libc::SIG_DFL);
            libc::signal(libc::SIGQUIT, libc::SIG_DFL);
            Ok(())
        });
    }
    let child = match cmd.spawn() {
        Ok(c) => c,
        Err(e) => die(&format!("running {}", spec.argv[0]), e.into()),
    };
    let main = child.id() as libc::pid_t;
    // As pid 1: reap everything, return the command's status.
    loop {
        let mut st = 0;
        // SAFETY: reaping our children.
        let r = unsafe { libc::waitpid(-1, &mut st, 0) };
        if r == main {
            // SAFETY: leaving; the kernel kills what is left in this pid namespace.
            unsafe { libc::_exit(decode(st)) }
        }
        if r < 0 && errno().raw_os_error() != Some(libc::EINTR) {
            // SAFETY: leaving.
            unsafe { libc::_exit(SETUP_FAILED) }
        }
    }
}

fn enter(spec: &Spec) -> Result<()> {
    let h = HOSTNAME.as_bytes();
    let empty = cstr("");
    let dot = cstr(".");
    // SAFETY: syscalls on fds and relative paths only, in our own namespaces.
    unsafe {
        if libc::sethostname(h.as_ptr().cast(), h.len()) != 0 {
            bail!("sethostname: {}", errno());
        }
        // The new root, as this mount namespace sees it (our working directory).
        let root_fd = libc::open(dot.as_ptr(), libc::O_PATH | libc::O_DIRECTORY | libc::O_CLOEXEC);
        if root_fd < 0 {
            bail!("opening the new root: {}", errno());
        }
        // Mounts copied in from the host's namespace are locked, and pivot_root
        // refuses a locked new root: clone the root tree from inside this
        // namespace and put the clone on top of it.
        let tree = libc::syscall(
            libc::SYS_open_tree,
            root_fd,
            empty.as_ptr(),
            OPEN_TREE_CLONE | OPEN_TREE_CLOEXEC | AT_RECURSIVE | libc::AT_EMPTY_PATH as libc::c_uint,
        ) as i32;
        if tree < 0 {
            bail!("open_tree: {}", errno());
        }
        if libc::syscall(libc::SYS_move_mount, tree, empty.as_ptr(), root_fd, empty.as_ptr(), MOVE_MOUNT_F_EMPTY_PATH | MOVE_MOUNT_T_EMPTY_PATH) != 0 {
            bail!("move_mount: {}", errno());
        }
        if libc::fchdir(tree) != 0 {
            bail!("fchdir: {}", errno());
        }
        libc::close(tree);
        libc::close(root_fd);
    }
    mount("proc", Path::new("proc"), "proc", libc::MS_NOSUID | libc::MS_NODEV | libc::MS_NOEXEC, None)?;
    mount("devpts", Path::new("dev/pts"), "devpts", libc::MS_NOSUID | libc::MS_NOEXEC, Some("newinstance,ptmxmode=0666,mode=620,gid=5"))?;
    mount("tmpfs", Path::new("dev/shm"), "tmpfs", libc::MS_NOSUID | libc::MS_NODEV, Some("mode=1777"))?;
    loopback_up();
    // SAFETY: pivot_root(".", ".") then detach the old root.
    unsafe {
        if libc::syscall(libc::SYS_pivot_root, dot.as_ptr(), dot.as_ptr()) != 0 {
            bail!("pivot_root: {}", errno());
        }
        if libc::umount2(dot.as_ptr(), libc::MNT_DETACH) != 0 {
            bail!("detaching the old root: {}", errno());
        }
        let slash = cstr("/");
        libc::chdir(slash.as_ptr());
        if libc::prctl(libc::PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) != 0 {
            bail!("no_new_privs: {}", errno());
        }
        if spec.arch == Arch::I586 && libc::personality(PER_LINUX32) < 0 {
            bail!("personality(PER_LINUX32): {}", errno());
        }
    }
    Ok(())
}

// lo up, so builds and tests that talk to localhost work. No other network.
fn loopback_up() {
    // SAFETY: SIOCGIFFLAGS/SIOCSIFFLAGS on a scratch socket.
    unsafe {
        let s = libc::socket(libc::AF_INET, libc::SOCK_DGRAM | libc::SOCK_CLOEXEC, 0);
        if s < 0 {
            return;
        }
        let mut ifr: libc::ifreq = std::mem::zeroed();
        for (i, b) in b"lo\0".iter().enumerate() {
            ifr.ifr_name[i] = *b as libc::c_char;
        }
        if libc::ioctl(s, libc::SIOCGIFFLAGS, &mut ifr) == 0 {
            ifr.ifr_ifru.ifru_flags |= libc::IFF_UP as libc::c_short;
            libc::ioctl(s, libc::SIOCSIFFLAGS, &ifr);
        }
        libc::close(s);
    }
}

/// Changes ownership of a fresh tree to the shifted root (uid/gid SUBID_BASE).
pub fn chown_shifted(path: &Path, subid_base: u32) -> Result<()> {
    let c = cpath(path);
    // SAFETY: lchown on a path we own.
    if unsafe { libc::lchown(c.as_ptr(), subid_base, subid_base) } != 0 {
        bail!("chown {}: {}", path.display(), errno());
    }
    if std::fs::symlink_metadata(path)?.is_dir() {
        for e in std::fs::read_dir(path)? {
            chown_shifted(&e?.path(), subid_base)?;
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::conf::Conf;
    use std::os::unix::fs::MetadataExt;

    const SHIFT: u32 = 100000;

    fn conf() -> Conf {
        Conf::from_text(
            "MIRROR_DIR=\"/srv/t/m\"\nBASE_DIR=\"/srv/t/b\"\nGIT_USER=\"nobody\"\nGIT_DIR=\"/srv/t/g\"\nFORK_URL=\"x\"\nUPSTREAM_URL=\"y\"\nSRC_DIR=\"/srv/t/s\"\nWORK_DIR=\"/srv/t/w\"\nCGROUP_MISSING=\"warn\"\nBUILD_MEM=\"512M\"\n",
        )
        .unwrap()
    }

    // A tmpfs for one test (overlay needs an upper layer that is not itself
    // an overlay), unmounted and removed even when the test fails.
    struct Scratch(PathBuf);
    impl std::ops::Deref for Scratch {
        type Target = PathBuf;
        fn deref(&self) -> &PathBuf {
            &self.0
        }
    }
    impl Drop for Scratch {
        fn drop(&mut self) {
            let c = cpath(&self.0);
            unsafe { libc::umount2(c.as_ptr(), libc::MNT_DETACH) };
            let _ = std::fs::remove_dir_all(&self.0);
        }
    }

    fn scratch(name: &str) -> Scratch {
        let d = PathBuf::from(format!("/tmp/sbo-sandbox-test-{name}-{}", std::process::id()));
        std::fs::create_dir_all(&d).unwrap();
        mount("tmpfs", &d, "tmpfs", 0, Some("mode=755")).unwrap();
        Scratch(d)
    }

    fn sh(script: &str) -> Vec<String> {
        vec!["/bin/sh".into(), "-c".into(), script.into()]
    }

    fn env() -> Vec<(String, String)> {
        vec![("PATH".into(), "/usr/sbin:/usr/bin:/sbin:/bin".into()), ("HOME".into(), "/root".into())]
    }

    // A tiny root owned by the shifted ids, like a real base tree.
    fn small_lower(d: &Path) -> PathBuf {
        let lower = d.join("lower");
        for x in ["bin", "usr", "etc", "proc", "dev", "tmp", "root"] {
            std::fs::create_dir_all(lower.join(x)).unwrap();
        }
        let tools = ["sh", "id", "hostname", "grep", "cat", "touch", "uname", "head", "tail", "sleep"];
        let mut files: Vec<String> = Vec::new();
        for t in tools {
            let p = String::from_utf8(std::process::Command::new("sh").args(["-c", &format!("command -v {t}")]).output().unwrap().stdout).unwrap();
            let p = std::fs::canonicalize(p.trim()).unwrap();
            std::fs::copy(&p, lower.join("bin").join(t)).unwrap();
            let ldd = String::from_utf8(std::process::Command::new("ldd").arg(&p).output().unwrap().stdout).unwrap();
            for w in ldd.split_whitespace().filter(|w| w.starts_with('/')) {
                files.push(w.to_string());
            }
        }
        for f in files {
            let real = std::fs::canonicalize(&f).unwrap();
            let dst = lower.join(f.trim_start_matches('/'));
            std::fs::create_dir_all(dst.parent().unwrap()).unwrap();
            if !dst.exists() {
                std::fs::copy(&real, &dst).unwrap();
            }
        }
        chown_shifted(&lower, SHIFT).unwrap();
        lower
    }

    // Needs root: cargo test -- --ignored
    #[test]
    #[ignore]
    fn overlay_sandbox() {
        let d = scratch("ovl");
        for x in ["upper", "work", "merged"] {
            std::fs::create_dir(d.join(x)).unwrap();
        }
        let lower = small_lower(&d);
        let c = conf();
        let cg = Cgroup::create(&c, "test-ovl").unwrap();
        let script = "set -e; \
            [ \"$(id -u)\" = 0 ]; \
            [ \"$(hostname)\" = slacker-sbo ]; \
            grep -q '0 *100000 *65536' /proc/self/uid_map; \
            [ \"$(cat /proc/1/comm)\" != systemd ]; \
            [ ! -e /dev/sda ]; [ -c /dev/null ]; \
            echo hi > /usr/sbo-test-file; \
            ! touch /proc/sys/kernel/hostname 2>/dev/null; \
            [ \"$(grep -c : /proc/net/dev)\" = 1 ]; \
            [ \"$(uname -m)\" = i686 ]; \
            exit 7";
        let st = run(Spec {
            root: Root::Overlay { lower: lower.clone(), upper: d.join("upper"), work: d.join("work"), merged: d.join("merged") },
            subid_base: SHIFT,
            arch: Arch::I586,
            argv: sh(script),
            env: env(),
            cwd: "/".into(),
            cgroup: &cg,
        })
        .unwrap();
        println!("{}", cg.limits_text());
        cg.destroy().unwrap();
        assert_eq!(st.status, 7, "the script failed before its last line");
        let f = d.join("upper/usr/sbo-test-file");
        let m = std::fs::metadata(&f).unwrap();
        assert_eq!((m.uid(), m.gid()), (SHIFT, SHIFT));
        assert!(!Path::new("/usr/sbo-test-file").exists());
        assert!(!lower.join("usr/sbo-test-file").exists());
    }

    #[test]
    #[ignore]
    fn host_readonly_sandbox() {
        let d = scratch("ro");
        let target = d.join("target");
        let merged = d.join("merged");
        std::fs::create_dir(&target).unwrap();
        std::fs::create_dir(&merged).unwrap();
        chown_shifted(&target, SHIFT).unwrap();
        let c = conf();
        let cg = Cgroup::create(&c, "test-ro").unwrap();
        let script = "set -e; \
            ! touch /etc/sbo-should-fail 2>/dev/null; \
            ! touch /usr/sbo-should-fail 2>/dev/null; \
            echo ok > /mnt/target/written; \
            echo t > /tmp/t; \
            exit 3";
        let st = run(Spec {
            root: Root::HostReadOnly { target: target.clone(), tree: None, merged },
            subid_base: SHIFT,
            arch: Arch::X86_64,
            argv: sh(script),
            env: env(),
            cwd: "/".into(),
            cgroup: &cg,
        })
        .unwrap();
        cg.destroy().unwrap();
        assert_eq!(st.status, 3);
        assert!(!Path::new("/etc/sbo-should-fail").exists());
        let m = std::fs::metadata(target.join("written")).unwrap();
        assert_eq!(m.uid(), SHIFT);
    }

    #[test]
    #[ignore]
    fn memory_limit_stops_the_whole_build() {
        let d = scratch("oom");
        for x in ["upper", "work", "merged"] {
            std::fs::create_dir(d.join(x)).unwrap();
        }
        let lower = small_lower(&d);
        let c = conf(); // BUILD_MEM="512M"
        let cg = Cgroup::create(&c, "test-oom").unwrap();
        // tail keeps a line with no newline in memory: 2G of it is over the limit.
        // The background sleep must not outlive the sandbox.
        let st = run(Spec {
            root: Root::Overlay { lower, upper: d.join("upper"), work: d.join("work"), merged: d.join("merged") },
            subid_base: SHIFT,
            arch: Arch::X86_64,
            argv: sh("sleep 600 & head -c 2G /dev/zero | tail > /dev/null; sleep 5; echo should-not-get-here > /tmp/after"),
            env: env(),
            cwd: "/".into(),
            cgroup: &cg,
        })
        .unwrap();
        cg.destroy().unwrap();
        println!("status {}, out_of_memory {}", st.status, st.out_of_memory);
        assert!(st.out_of_memory, "the memory limit did not trigger");
        assert!(!st.ok());
        let left = std::process::Command::new("pgrep").args(["-af", "^sleep 600"]).output().unwrap();
        assert!(left.stdout.is_empty(), "a process outlived the sandbox: {}", String::from_utf8_lossy(&left.stdout));
        assert!(!d.join("upper/tmp/after").exists(), "the build went on after running out of memory");
    }

    // Every cgroup hierarchy: its top-level directories and subtree_control.
    fn cgroup_snapshot() -> Vec<String> {
        let mi = std::fs::read_to_string("/proc/self/mountinfo").unwrap();
        let mut out = Vec::new();
        for l in mi.lines() {
            let Some((left, right)) = l.split_once(" - ") else { continue };
            if !right.starts_with("cgroup") {
                continue;
            }
            let mnt = left.split_whitespace().nth(4).unwrap();
            let mut names: Vec<String> = std::fs::read_dir(mnt).unwrap().filter_map(|e| e.ok()).map(|e| format!("{mnt}/{}", e.file_name().to_string_lossy())).collect();
            names.sort();
            out.extend(names);
            out.push(std::fs::read_to_string(format!("{mnt}/cgroup.subtree_control")).unwrap_or_default());
        }
        out
    }

    #[test]
    #[ignore]
    fn cgroups_leave_the_system_as_it_was() {
        let before = cgroup_snapshot();
        let d = scratch("cg");
        for x in ["upper", "work", "merged"] {
            std::fs::create_dir(d.join(x)).unwrap();
        }
        let lower = small_lower(&d);
        let cg = Cgroup::create(&conf(), "test-cg").unwrap();
        println!("{}", cg.limits_text());
        let st = run(Spec {
            root: Root::Overlay { lower, upper: d.join("upper"), work: d.join("work"), merged: d.join("merged") },
            subid_base: SHIFT,
            arch: Arch::X86_64,
            argv: sh("sleep 600 & exit 4"),
            env: env(),
            cwd: "/".into(),
            cgroup: &cg,
        })
        .unwrap();
        cg.destroy().unwrap();
        assert_eq!(st.status, 4);
        assert_eq!(before, cgroup_snapshot(), "cgroup hierarchies changed");
    }

    // The host's mount table: mount point, propagation fields, type, options.
    fn host_mounts() -> Vec<String> {
        let mi = std::fs::read_to_string("/proc/self/mountinfo").unwrap();
        let mut v: Vec<String> = mi
            .lines()
            .map(|l| {
                let (left, right) = l.split_once(" - ").unwrap();
                let f: Vec<&str> = left.split_whitespace().collect();
                format!("{} {} {} {}", f[4], f[5], f[6..].join(" "), right)
            })
            .collect();
        v.sort();
        v
    }

    #[test]
    #[ignore]
    fn host_mounts_stay_the_same() {
        let d = scratch("mnt");
        for x in ["upper", "work", "merged", "target", "ro"] {
            std::fs::create_dir(d.join(x)).unwrap();
        }
        chown_shifted(&d.join("target"), SHIFT).unwrap();
        let lower = small_lower(&d);
        // A parent directory the shifted root cannot enter, like WORK_DIR (0700).
        use std::os::unix::fs::PermissionsExt;
        std::fs::set_permissions(&*d, std::fs::Permissions::from_mode(0o700)).unwrap();
        let before = host_mounts();
        let cg = Cgroup::create(&conf(), "test-mnt").unwrap();
        let a = run(Spec {
            root: Root::Overlay { lower, upper: d.join("upper"), work: d.join("work"), merged: d.join("merged") },
            subid_base: SHIFT,
            arch: Arch::X86_64,
            argv: sh("exit 0"),
            env: env(),
            cwd: "/".into(),
            cgroup: &cg,
        })
        .unwrap();
        let b = run(Spec {
            root: Root::HostReadOnly { target: d.join("target"), tree: Some(d.join("upper")), merged: d.join("ro") },
            subid_base: SHIFT,
            arch: Arch::X86_64,
            argv: sh("exit 0"),
            env: env(),
            cwd: "/".into(),
            cgroup: &cg,
        })
        .unwrap();
        cg.destroy().unwrap();
        assert!(a.ok() && b.ok());
        assert_eq!(before, host_mounts(), "the sandbox changed the host's mounts");
        assert_eq!(std::fs::read_dir(d.join("merged")).unwrap().count(), 0);
        assert_eq!(std::fs::read_dir(d.join("ro")).unwrap().count(), 0);
    }

    // On a machine with a real base tree: SBO_TEST_BASE=/srv/sbo/base/x86_64
    #[test]
    #[ignore]
    fn real_base_tree_compiles() {
        let Ok(base) = std::env::var("SBO_TEST_BASE") else { return };
        let d = scratch("real");
        for x in ["upper", "work", "merged"] {
            std::fs::create_dir(d.join(x)).unwrap();
        }
        let cg = Cgroup::create(&conf(), "test-real").unwrap();
        let script = r#"set -e; cat /etc/slackware-version; gcc --version | head -1
printf '#include <stdio.h>\nint main(void){puts("hello from the sandbox");return 0;}\n' > /tmp/h.c
gcc -O2 -o /tmp/h /tmp/h.c; /tmp/h
mkdir -p /tmp/pkg/usr/bin; cp /tmp/h /tmp/pkg/usr/bin/; cd /tmp/pkg
/sbin/makepkg -l y -c n /tmp/hello-1-x86_64-1_SBo.tgz >/dev/null
tar tzvf /tmp/hello-1-x86_64-1_SBo.tgz | grep usr/bin/h"#;
        let st = run(Spec {
            root: Root::Overlay { lower: base.into(), upper: d.join("upper"), work: d.join("work"), merged: d.join("merged") },
            subid_base: SHIFT,
            arch: Arch::X86_64,
            argv: vec!["/bin/bash".into(), "-c".into(), script.into()],
            env: env(),
            cwd: "/".into(),
            cgroup: &cg,
        })
        .unwrap();
        cg.destroy().unwrap();
        assert!(st.ok());
        assert!(d.join("upper/tmp/hello-1-x86_64-1_SBo.tgz").is_file());
    }
}
