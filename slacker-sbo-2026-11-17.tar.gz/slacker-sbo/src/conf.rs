// /etc/slacker/slacker-sbo.conf: KEY="VALUE" lines, values always quoted.

use anyhow::{bail, Context, Result};
use std::collections::HashMap;
use std::path::{Path, PathBuf};

pub const CONF_PATH: &str = "/etc/slacker/slacker-sbo.conf";

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum WorkFs {
    Loop,
    Tmpfs,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Editor {
    Simple,
    Vim,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Arch {
    X86_64,
    I586,
}

impl Arch {
    pub fn name(self) -> &'static str {
        match self {
            Arch::X86_64 => "x86_64",
            Arch::I586 => "i586",
        }
    }
    pub fn parse(s: &str) -> Option<Arch> {
        match s {
            "x86_64" => Some(Arch::X86_64),
            "i586" => Some(Arch::I586),
            _ => None,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum MemLimit {
    Percent(u64),
    Bytes(u64),
}

/// Where a Slackware tree comes from.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum TreeSource {
    /// Synced into MIRROR_DIR/<arch>.
    Rsync(String),
    /// Used where it is, read-only.
    Local(PathBuf),
}

#[derive(Debug, Clone)]
pub struct Conf {
    pub trees: Vec<(Arch, TreeSource)>,
    pub mirror_dir: PathBuf,
    pub mirror_gpg: bool,
    pub base_dir: PathBuf,
    pub git_user: String,
    pub git_dir: PathBuf,
    pub fork_url: String,
    pub upstream_url: String,
    pub src_dir: PathBuf,
    pub work_dir: PathBuf,
    pub work_fs: WorkFs,
    pub work_size: u64,
    /// Architectures with a TREE_* set, x86_64 first.
    pub arch: Vec<Arch>,
    pub subid_base: u32,
    pub build_mem: MemLimit,
    pub build_pids: u64,
    pub cgroup_missing_stop: bool,
    pub editor: Editor,
}

const KEYS: &[&str] = &[
    "TREE_X86_64", "TREE_I586", "MIRROR_DIR", "MIRROR_GPG", "BASE_DIR", "GIT_USER", "GIT_DIR",
    "FORK_URL", "UPSTREAM_URL", "SRC_DIR", "WORK_DIR", "WORK_FS", "WORK_SIZE", "SUBID_BASE",
    "BUILD_MEM", "BUILD_PIDS", "CGROUP_MISSING", "EDITOR",
];

// Keys with a default when they are missing from the file.
fn default_of(key: &str) -> Option<&'static str> {
    match key {
        "TREE_X86_64" => Some(""),
        "TREE_I586" => Some(""),
        "MIRROR_GPG" => Some("yes"),
        "WORK_FS" => Some("loop"),
        "WORK_SIZE" => Some("50G"),
        "SUBID_BASE" => Some("100000"),
        "BUILD_MEM" => Some("75%"),
        "BUILD_PIDS" => Some("4096"),
        "CGROUP_MISSING" => Some("stop"),
        "EDITOR" => Some("simple"),
        _ => None,
    }
}

/// Parses the raw file into a key -> value map. Every value must be quoted.
pub fn parse_lines(text: &str) -> Result<HashMap<String, String>> {
    let mut map = HashMap::new();
    for (i, raw) in text.lines().enumerate() {
        let n = i + 1;
        let line = raw.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let Some((key, rest)) = line.split_once('=') else {
            bail!("line {n}: expected KEY=\"VALUE\"");
        };
        let key = key.trim_end();
        if key.is_empty() || !key.bytes().all(|b| b.is_ascii_uppercase() || b.is_ascii_digit() || b == b'_') {
            bail!("line {n}: bad key {key:?}");
        }
        let Some(rest) = rest.strip_prefix('"') else {
            bail!("line {n}: value of {key} must be quoted");
        };
        let Some(end) = rest.find('"') else {
            bail!("line {n}: missing closing quote for {key}");
        };
        let value = &rest[..end];
        let tail = rest[end + 1..].trim_start();
        if !(tail.is_empty() || tail.starts_with('#')) {
            bail!("line {n}: unexpected text after the value of {key}");
        }
        if value.contains('$') || value.contains('`') {
            bail!("line {n}: {key}: no variable or command expansion is done, remove $ and `");
        }
        if !KEYS.contains(&key) {
            bail!("line {n}: unknown key {key}");
        }
        if map.insert(key.to_string(), value.to_string()).is_some() {
            bail!("line {n}: {key} is set twice");
        }
    }
    Ok(map)
}

/// Parses sizes like 50G, 512M, 1T, 4096 (bytes).
pub fn parse_size(s: &str) -> Option<u64> {
    let s = s.trim();
    let (num, mult) = match s.chars().last()? {
        'K' => (&s[..s.len() - 1], 1u64 << 10),
        'M' => (&s[..s.len() - 1], 1 << 20),
        'G' => (&s[..s.len() - 1], 1 << 30),
        'T' => (&s[..s.len() - 1], 1 << 40),
        c if c.is_ascii_digit() => (s, 1),
        _ => return None,
    };
    num.parse::<u64>().ok()?.checked_mul(mult).filter(|&v| v > 0)
}

// Directories the tool may delete or fill must never be system directories.
const FORBIDDEN: &[&str] = &[
    "/", "/bin", "/boot", "/dev", "/etc", "/home", "/lib", "/lib64", "/mnt", "/media", "/opt",
    "/proc", "/root", "/run", "/sbin", "/srv", "/sys", "/tmp", "/usr", "/var",
];

fn check_dir(key: &str, v: &str) -> Result<PathBuf> {
    if v.is_empty() {
        bail!("{key} must be set");
    }
    let p = PathBuf::from(v);
    if !p.is_absolute() {
        bail!("{key}: {v} is not an absolute path");
    }
    if p.components().any(|c| matches!(c, std::path::Component::ParentDir | std::path::Component::CurDir)) {
        bail!("{key}: {v} must not contain . or ..");
    }
    // These paths go into overlay mount options, where , : and spaces have a meaning.
    if v.chars().any(|c| c == ',' || c == ':' || c == '\\' || c == '\'' || c == '"' || c.is_whitespace() || c.is_control()) {
        bail!("{key}: {v} must not contain commas, colons, quotes, backslashes or spaces");
    }
    let norm = v.trim_end_matches('/');
    let norm = if norm.is_empty() { "/" } else { norm };
    if FORBIDDEN.contains(&norm) || norm.starts_with("/etc/") || norm.starts_with("/usr/") || norm.starts_with("/proc/") || norm.starts_with("/sys/") || norm.starts_with("/dev/") || norm.starts_with("/boot/") {
        bail!("{key}: {v} is a system directory, use a directory of its own");
    }
    Ok(PathBuf::from(norm))
}

impl Conf {
    pub fn load() -> Result<Conf> {
        let text = std::fs::read_to_string(CONF_PATH).with_context(|| format!("reading {CONF_PATH}"))?;
        Conf::from_text(&text).with_context(|| CONF_PATH.to_string())
    }

    pub fn from_text(text: &str) -> Result<Conf> {
        let map = parse_lines(text)?;
        let get = |k: &str| -> Result<String> {
            match map.get(k) {
                Some(v) => Ok(v.clone()),
                None => default_of(k).map(str::to_string).with_context(|| format!("{k} is missing")),
            }
        };
        let yes_no = |k: &str| -> Result<bool> {
            match get(k)?.as_str() {
                "yes" => Ok(true),
                "no" => Ok(false),
                v => bail!("{k}: {v:?} is not yes or no"),
            }
        };

        let mirror_dir = check_dir("MIRROR_DIR", &get("MIRROR_DIR")?)?;
        let base_dir = check_dir("BASE_DIR", &get("BASE_DIR")?)?;
        let git_dir = check_dir("GIT_DIR", &get("GIT_DIR")?)?;
        let src_dir = check_dir("SRC_DIR", &get("SRC_DIR")?)?;
        let work_dir = check_dir("WORK_DIR", &get("WORK_DIR")?)?;
        let dirs = [
            ("MIRROR_DIR", &mirror_dir),
            ("BASE_DIR", &base_dir),
            ("GIT_DIR", &git_dir),
            ("SRC_DIR", &src_dir),
            ("WORK_DIR", &work_dir),
        ];
        for (i, (ka, a)) in dirs.iter().enumerate() {
            for (kb, b) in &dirs[i + 1..] {
                if a.starts_with(b) || b.starts_with(a) {
                    bail!("{ka} and {kb} must not be the same directory or inside each other");
                }
            }
        }

        let git_user = get("GIT_USER")?;
        if git_user.is_empty() || git_user == "root" {
            bail!("GIT_USER must be set to a normal user, not root");
        }
        let fork_url = get("FORK_URL")?;
        if fork_url.is_empty() {
            bail!("FORK_URL must be set");
        }
        let upstream_url = get("UPSTREAM_URL")?;
        if upstream_url.is_empty() {
            bail!("UPSTREAM_URL must be set");
        }

        let work_fs = match get("WORK_FS")?.as_str() {
            "loop" => WorkFs::Loop,
            "tmpfs" => WorkFs::Tmpfs,
            v => bail!("WORK_FS: {v:?} is not loop or tmpfs"),
        };
        let ws = get("WORK_SIZE")?;
        let work_size = parse_size(&ws).with_context(|| format!("WORK_SIZE: {ws:?} is not a size like 50G"))?;
        if work_size < 1 << 30 {
            bail!("WORK_SIZE: {ws} is smaller than 1G");
        }

        let mut trees = Vec::new();
        for (key, a) in [("TREE_X86_64", Arch::X86_64), ("TREE_I586", Arch::I586)] {
            let v = get(key)?;
            if v.is_empty() {
                continue;
            }
            let src = if v.starts_with("rsync://") {
                if v.chars().any(|c| c == '\'' || c == '"' || c == '\\' || c.is_whitespace() || c.is_control()) {
                    bail!("{key}: {v} must not contain quotes, backslashes or spaces");
                }
                TreeSource::Rsync(v.trim_end_matches('/').to_string())
            } else {
                let p = check_dir(key, &v)?;
                for (k, d) in &dirs {
                    if p.starts_with(d) || d.starts_with(&p) {
                        bail!("{key} and {k} must not be the same directory or inside each other");
                    }
                }
                TreeSource::Local(p)
            };
            trees.push((a, src));
        }
        if trees.is_empty() {
            bail!("set TREE_X86_64, TREE_I586 or both");
        }
        let arch: Vec<Arch> = trees.iter().map(|(a, _)| *a).collect();

        let sb = get("SUBID_BASE")?;
        let subid_base: u32 = sb.parse().with_context(|| format!("SUBID_BASE: {sb:?} is not a number"))?;
        if subid_base < 65536 || subid_base.checked_add(65536).is_none() {
            bail!("SUBID_BASE: {subid_base} must be at least 65536 and leave room for 65536 ids");
        }

        let bm = get("BUILD_MEM")?;
        let build_mem = if let Some(p) = bm.strip_suffix('%') {
            let p: u64 = p.parse().with_context(|| format!("BUILD_MEM: {bm:?}"))?;
            if p == 0 || p > 100 {
                bail!("BUILD_MEM: {bm} must be between 1% and 100%");
            }
            MemLimit::Percent(p)
        } else {
            MemLimit::Bytes(parse_size(&bm).with_context(|| format!("BUILD_MEM: {bm:?} is not a percent or a size"))?)
        };
        let bp = get("BUILD_PIDS")?;
        let build_pids: u64 = bp.parse().ok().filter(|&n| n >= 64).with_context(|| format!("BUILD_PIDS: {bp:?} must be a number, at least 64"))?;

        let cgroup_missing_stop = match get("CGROUP_MISSING")?.as_str() {
            "stop" => true,
            "warn" => false,
            v => bail!("CGROUP_MISSING: {v:?} is not stop or warn"),
        };
        let editor = match get("EDITOR")?.as_str() {
            "simple" => Editor::Simple,
            "vim" => Editor::Vim,
            v => bail!("EDITOR: {v:?} is not simple or vim"),
        };

        Ok(Conf {
            trees,
            mirror_dir,
            mirror_gpg: yes_no("MIRROR_GPG")?,
            base_dir,
            git_user,
            git_dir,
            fork_url,
            upstream_url,
            src_dir,
            work_dir,
            work_fs,
            work_size,
            arch,
            subid_base,
            build_mem,
            build_pids,
            cgroup_missing_stop,
            editor,
        })
    }

    pub fn hooks_dir(&self) -> PathBuf {
        self.work_dir.join("hooks")
    }

    pub fn base_tree(&self, arch: Arch) -> PathBuf {
        self.base_dir.join(arch.name())
    }
}

pub fn exists(p: &Path) -> bool {
    std::fs::symlink_metadata(p).is_ok()
}

#[cfg(test)]
mod tests {
    use super::*;

    const GOOD: &str = r#"
# comment
TREE_X86_64="rsync://slackware.uk/slackware/slackware64-15.0"   # a tree
TREE_I586="/data/my-32bit-tree"
MIRROR_DIR="/srv/sbo/mirror"
BASE_DIR="/srv/sbo/base"
GIT_USER="omen"
GIT_DIR="/srv/sbo/slackbuilds"
FORK_URL="git@github.com:rizitis/slackbuilds.git"
UPSTREAM_URL="https://github.com/SlackBuildsOrg/slackbuilds.git"
SRC_DIR="/srv/sbo/sources"
WORK_DIR="/srv/sbo/work"
"#;

    #[test]
    fn good_with_defaults() {
        let c = Conf::from_text(GOOD).unwrap();
        assert_eq!(c.work_fs, WorkFs::Loop);
        assert_eq!(c.work_size, 50 << 30);
        assert_eq!(c.arch, vec![Arch::X86_64, Arch::I586]);
        assert_eq!(c.trees[0].1, TreeSource::Rsync("rsync://slackware.uk/slackware/slackware64-15.0".into()));
        assert_eq!(c.trees[1].1, TreeSource::Local("/data/my-32bit-tree".into()));
        assert_eq!(c.subid_base, 100000);
        assert_eq!(c.build_mem, MemLimit::Percent(75));
        assert!(c.mirror_gpg && c.cgroup_missing_stop);
        assert_eq!(c.editor, Editor::Simple);
        assert_eq!(c.hooks_dir(), PathBuf::from("/srv/sbo/work/hooks"));
    }

    #[test]
    fn unquoted_and_unknown_and_twice() {
        assert!(parse_lines("WORK_FS=loop").is_err());
        assert!(parse_lines("FOO=\"x\"").is_err());
        assert!(parse_lines("WORK_FS=\"loop\"\nWORK_FS=\"tmpfs\"").is_err());
        assert!(parse_lines("WORK_FS=\"loop\" junk").is_err());
        assert!(parse_lines("WORK_DIR=\"$HOME/x\"").is_err());
    }

    #[test]
    fn dirs_checked() {
        let bad = GOOD.replace("/srv/sbo/work", "/srv/sbo/mirror/work");
        assert!(Conf::from_text(&bad).is_err());
        let bad = GOOD.replace("/srv/sbo/work", "/usr");
        assert!(Conf::from_text(&bad).is_err());
        let bad = GOOD.replace("/srv/sbo/work", "srv/work");
        assert!(Conf::from_text(&bad).is_err());
        let bad = GOOD.replace("\"omen\"", "\"root\"");
        assert!(Conf::from_text(&bad).is_err());
    }

    #[test]
    fn trees() {
        let only64 = GOOD.replace("TREE_I586=\"/data/my-32bit-tree\"", "TREE_I586=\"\"");
        assert_eq!(Conf::from_text(&only64).unwrap().arch, vec![Arch::X86_64]);
        let none = only64.replace("TREE_X86_64=\"rsync://slackware.uk/slackware/slackware64-15.0\"", "");
        assert!(Conf::from_text(&none).is_err());
        let inside = GOOD.replace("/data/my-32bit-tree", "/srv/sbo/work/tree");
        assert!(Conf::from_text(&inside).is_err());
        let bad = GOOD.replace("/data/my-32bit-tree", "data/x");
        assert!(Conf::from_text(&bad).is_err());
    }

    #[test]
    fn sizes() {
        assert_eq!(parse_size("50G"), Some(50 << 30));
        assert_eq!(parse_size("512M"), Some(512 << 20));
        assert_eq!(parse_size("0G"), None);
        assert_eq!(parse_size("5X"), None);
    }
}
