#!/bin/bash
# status / list-repos / check-updates on a fake system. Private mount ns: fake /etc/os-release and /var/lib (locate db).
SP=/tmp/claude-0/-home-claude/73a54ae3-ae97-507e-9e79-48011fdaa1ed/scratchpad; SETUP=$SP/slacker_step11
BIN=$1; R=/home/claude/sttest
if [ "$2" != inner ]; then rm -rf $R; mkdir -p $R/varlib; exec unshare -m --propagation private sh -c "mount --bind $SP/os-release.current /etc/os-release && mount --bind $R/varlib /var/lib && exec $0 $BIN inner"; fi
T=2026-10-01T10:00:00
pk(){ for p in "$@"; do printf 'PACKAGE NAME:  %s.txz\nPACKAGE LOCATION:  ./x\nPACKAGE SIZE (compressed):  100 K\nPACKAGE SIZE (uncompressed):  300 K\nPACKAGE REQUIRED:  \nPACKAGE DESCRIPTION:\n%s: test\n\n' $p ${p%%-[0-9]*}; done; }
mirror(){ d=$R/m/$1; shift; mkdir -p $d; { echo "PACKAGES.TXT;  Thu Oct  1 10:00:00 UTC 2026"; echo; pk "$@"; } > $d/PACKAGES.TXT; (cd $d && for p in "$@"; do echo "0123456789abcdef0123456789abcdef  ./x/$p.txz"; done > CHECKSUMS.md5); }
mk(){ rm -rf $R/conf $R/cache $R/state $R/adm $R/m $R/bin $R/varlib/*; mkdir -p $R/{conf,cache,state,adm/packages,adm/removed_packages,bin,varlib/mlocate}
  printf "ARCH=x86_64\nCACHE_DIR=$R/cache\nSTATE_DIR=$R/state\nADM_DIR=$R/adm\nVERIFY=md5\nIGNORE_TAGS=_SBo\n" > $R/conf/slacker.conf
  printf "100 slackware file://$R/m/slackware64-current official\n80 alien file://$R/m/alien verify=none\n60 conraid file://$R/m/conraid immutable\n40 sbo file://$R/m/sbo\n35 SBo _SBo\n" > $R/conf/repos
  mirror slackware64-current vim-9.1-x86_64-1 bash-5.3-x86_64-1 glibc-2.42-x86_64-1; printf 'Thu Oct  1 10:00:00 UTC 2026\nchanges\n' > $R/m/slackware64-current/ChangeLog.txt
  mirror alien vlc-3.0-x86_64-1alien ffmpeg-7-x86_64-1alien; mirror conraid mpv-0.40-x86_64-1cf; mirror sbo foo-1-x86_64-1_SBo
  for p in vim-9.1-x86_64-1 bash-5.2-x86_64-1 glibc-2.42-x86_64-1 vlc-3.0-x86_64-1alien mpv-0.40-x86_64-1cf foo-1-x86_64-1_SBo orphan-1-x86_64-1xyz; do touch -d $T $R/adm/packages/$p; done
  touch -d 2026-09-01T10:00:00 "$R/adm/removed_packages/bash-5.1-x86_64-1-upgraded-2026-09-01,10:00:00"
  for t in installpkg upgradepkg removepkg locate; do printf '#!/bin/sh\nexit 0\n' > $R/bin/$t; chmod +x $R/bin/$t; done
  NO_COLOR=1 PATH=$R/bin:$PATH $SETUP --config-dir $R/conf update -y </dev/null >/dev/null 2>&1
  printf 'vlc\n@conraid 100%% mpv\n' > $R/conf/blacklist
  mkdir -p $R/cache/packages/slackware; head -c 2048 /dev/zero > $R/cache/packages/slackware/vim-9.1-x86_64-1.txz
  find $R/cache $R/state $R/conf -exec touch -h -d $T {} +
  : > $R/varlib/mlocate/mlocate.db; touch -d "$(date -d '-2 hours' +%FT%H:00:00)" $R/varlib/mlocate/mlocate.db; }
run(){ echo "### slacker $*"; NO_COLOR=1 COLUMNS=100 PATH=${XPATH:-$R/bin:$PATH} timeout 60 $BIN --config-dir $R/conf "$@" </dev/null 2>&1 | sed "s#$R#ROOT#g"; echo "### exit=${PIPESTATUS[0]}"; }
all(){ run status; run list-repos; run check-updates; }
echo "=== κανονικό"; mk; all
echo "=== χωρίς pkgtools"; mk; XPATH=/usr/bin:/bin run status
echo "=== locate db παλιό / λείπει"; mk; touch -d "$(date -d "-40 days" +%FT%H:00:00)" $R/varlib/mlocate/mlocate.db; run status; rm $R/varlib/mlocate/mlocate.db; run status
echo "=== config dir λείπει"; mk; NO_COLOR=1 PATH=$R/bin:$PATH $BIN --config-dir $R/nope status 2>&1 | sed "s#$R#ROOT#g"; echo "### exit=${PIPESTATUS[0]}"
echo "=== άκυρο repos"; mk; echo "90 other file://$R/m/x official" >> $R/conf/repos; all
echo "=== χωρίς metadata"; mk; rm -rf $R/cache/repos/alien $R/cache/repos/sbo; all
echo "=== αλλαγές στους mirrors"; mk; mirror alien vlc-3.1-x86_64-1alien; printf 'Fri Oct  2 10:00:00 UTC 2026\nmore\n' > $R/m/slackware64-current/ChangeLog.txt; rm -rf $R/m/sbo; all
echo "=== world-writable + symlink στο config"; mk; chmod 666 $R/conf/blacklist; ln -s /etc/passwd $R/conf/stray; run status
echo "=== quarantine"; mk; NO_COLOR=1 $SETUP --config-dir $R/conf distrust-repo -y sbo </dev/null >/dev/null 2>&1; find $R/state -exec touch -h -d $T {} +; all
echo "=== stable 15.0 mirror"; mk; sed -i "s#slackware64-current official#slackware64-15.0 official#" $R/conf/repos; mkdir -p $R/m/slackware64-15.0; cp -a $R/m/slackware64-current/. $R/m/slackware64-15.0/; all
echo "=== VERIFY=none, http repo"; mk; sed -i 's/VERIFY=md5/VERIFY=none/' $R/conf/slacker.conf; echo "20 plain http://127.0.0.1:9/x" >> $R/conf/repos; all
echo "=== μεγάλο/παλιό cache"; mk; truncate -s 3G $R/cache/packages/slackware/big-1-x86_64-1.txz; touch -d 2026-01-01T10:00:00 $R/cache/packages/slackware/*.txz; run status
echo "=== μόνο third-party"; mk; printf "80 alien file://$R/m/alien verify=none\n" > $R/conf/repos; all
