#!/bin/bash
BIN=$1; R=/home/claude/fmtest; rm -rf $R; mkdir -p $R/x86 $R/x86_32 $R/arm $R/nocfg
printf 'ARCH=x86_64\nCACHE_DIR=%s/c\nSTATE_DIR=%s/s\n' $R $R > $R/x86/slacker.conf; echo "100 slackware https://mirrors.example.org/slackware/slackware64-current official" > $R/x86/repos; : > $R/x86/mirrors
printf 'ARCH=i586\nCACHE_DIR=%s/c\nSTATE_DIR=%s/s\n' $R $R > $R/x86_32/slacker.conf; : > $R/x86_32/repos
printf 'ARCH=aarch64\nCACHE_DIR=%s/c\nSTATE_DIR=%s/s\n' $R $R > $R/arm/slacker.conf; : > $R/arm/repos
run(){ echo "### slacker $*"; NO_COLOR=1 timeout 90 $BIN "$@" </dev/null 2>&1 | sed "s#$R#ROOT#g"; echo "### exit=${PIPESTATUS[0]}"; }
for d in arm x86 x86_32 nocfg; do run --config-dir $R/$d find-mirror; done
run --config-dir $R/x86 find-mirror --dry-run
