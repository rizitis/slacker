#!/bin/bash
# clean-system / clean-cache on a fake system; removepkg is a fake that only logs its args.
BIN=$1; R=/home/claude/cleantest
pk(){ for p in "$@"; do printf 'PACKAGE NAME:  %s.txz\nPACKAGE LOCATION:  ./x\nPACKAGE REQUIRED:  \nPACKAGE DESCRIPTION:\n%s: test\n\n' $p ${p%%-[0-9]*}; done; }
mk(){ rm -rf $R; mkdir -p $R/{conf,state,pkgdb,bin} $R/cache/repos/{slackware,extra,alien,conraid,sbo}
  printf "ARCH=x86_64\nCACHE_DIR=$R/cache\nSTATE_DIR=$R/state\nPKG_DB_DIR=$R/pkgdb\nVERIFY=none\nIGNORE_TAGS=_SBo\n" > $R/conf/slacker.conf
  printf "100 slackware file://$R/m official verify=none\n90 extra file://$R/e subtree immutable verify=none\n50 alien file://$R/a verify=none\n40 conraid file://$R/c immutable verify=none\n30 sbo file://$R/s verify=none\n" > $R/conf/repos
  { echo "PACKAGES.TXT;"; echo; pk vim-9.1-x86_64-1 bash-5.3-x86_64-1 openssl-3.5-x86_64-1 blk-1-x86_64-1; } > $R/cache/repos/slackware/PACKAGES.TXT
  : > $R/cache/repos/extra/PACKAGES.TXT
  { echo "PACKAGES.TXT;"; echo; pk vlc-3.0-x86_64-1alien ffmpeg-7-x86_64-1alien; } > $R/cache/repos/alien/PACKAGES.TXT
  { echo "PACKAGES.TXT;"; echo; pk mpv-0.40-x86_64-1cf; } > $R/cache/repos/conraid/PACKAGES.TXT
  { echo "PACKAGES.TXT;"; echo; pk foo-1-x86_64-1_SBo; } > $R/cache/repos/sbo/PACKAGES.TXT
  for p in vim-9.1-x86_64-1 bash-5.3-x86_64-1 openssl-3.5-x86_64-1_slack15.0 gone-1-x86_64-1_slack15.0 oldpkg-1-x86_64-1 dead-2-x86_64-2 \
           vlc-3.0-x86_64-1alien ffmpeg-7-x86_64-1alien mpv-0.40-x86_64-1cf mpvold-0.1-x86_64-1cf foo-1-x86_64-1_SBo bar-2-x86_64-1_SBo \
           baz-1-x86_64-1xyz slacker-0.12.4-x86_64-1_FRG blk-0.9-x86_64-1 olderblk-1-x86_64-1; do touch $R/pkgdb/$p; done
  printf 'olderblk\n@alien 100%% vlc\n' > $R/conf/blacklist
  printf '#!/bin/sh\necho "removepkg $*" >> %s/removepkg.log\nexit ${FAKE_RC:-0}\n' $R > $R/bin/removepkg; chmod +x $R/bin/removepkg; }
cache(){ mkdir -p $R/cache/packages/{slackware,alien,empty} $R/cache/packages/alien/sub; head -c 1048576 /dev/zero > $R/cache/packages/slackware/vim-9.1-x86_64-1.txz
  echo sig > $R/cache/packages/slackware/vim-9.1-x86_64-1.txz.asc; head -c 524288 /dev/zero > $R/cache/packages/alien/vlc-3.0-x86_64-1alien.txz
  echo keep > $R/cache/packages/alien/sub/inner.txz; echo precious > $R/precious; ln -s $R/precious $R/cache/packages/alien/link.txz; echo top > $R/cache/packages/toplevel.txz; }
show(){ echo "### removepkg κλήσεις:"; sed "s#$R#ROOT#g" $R/removepkg.log 2>/dev/null || echo "(καμία)"; }
showc(){ echo "### cache τώρα:"; (cd $R/cache && find packages 2>/dev/null | sort); echo "### precious: $(cat $R/precious 2>/dev/null)"; echo "### repos meta: $(ls $R/cache/repos | tr '\n' ' ')"; }
run(){ inp=$1; shift; echo "### slacker $*   [stdin: $(printf %q "$inp")]"; printf "$inp" | NO_COLOR=1 PATH=$R/bin:$PATH timeout 60 $BIN --config-dir $R/conf "$@" 2>&1 | sed "s#$R#ROOT#g"; echo "### exit=${PIPESTATUS[1]}"; }
echo "=== clean-system ==="
mk; run "" clean-system --dry-run; show
mk; run "" clean-system -y; show
mk; run 'K\n\ny\n' clean-system; show
mk; run '\n\ny\n' clean-system; show
mk; run 'R\n\ny\n' clean-system; show
mk; run 'P\ny\n1 2\ny\n' clean-system; show
mk; run 'P\nn\n2-4\ny\n' clean-system; show
mk; run 'K\nn\n' clean-system; show
mk; run 'K\nν\n' clean-system; show
mk; run 'K\n1-99\n' clean-system; show
mk; run 'K\n1 2 3 4 5 6\n' clean-system; show
mk; run 'K\n\nn\n' clean-system; show
mk; run 'K\n\n' clean-system; show
mk; run '' clean-system; show
mk; run 'x\n3,5\ny\n' clean-system; show
mk; FAKE_RC=1; export FAKE_RC; run "" clean-system -y; show; unset FAKE_RC
mk; rm $R/cache/repos/slackware/PACKAGES.TXT; run "" clean-system -y; show
mk; : > $R/cache/repos/conraid/PACKAGES.TXT; run "" clean-system -y; show
mk; printf "50 alien file://$R/a verify=none\n" > $R/conf/repos; run "" clean-system --dry-run; show
mk; rm $R/conf/blacklist; run "" clean-system --dry-run; show
mk; rm $R/pkgdb/{gone,oldpkg,dead,vlc,ffmpeg,mpvold,bar,baz}*; run "" clean-system -y; show
mk; rm $R/pkgdb/{gone,oldpkg,dead,ffmpeg,mpvold,bar,baz}*; run 'R\n\ny\n' clean-system; show
mk; rm $R/pkgdb/{gone,oldpkg,dead,ffmpeg,mpvold,bar,baz}*; run 'K\n' clean-system; show
echo "=== clean-cache ==="
mk; run "" clean-cache; showc
mk; mkdir -p $R/cache/packages; run "" clean-cache; showc
mk; cache; run "" clean-cache --dry-run; showc
mk; cache; run "n\n" clean-cache; showc
mk; cache; run "" clean-cache; showc
mk; cache; run "y\n" clean-cache; showc
mk; cache; run "" clean-cache -y; showc
mk; cache; run "" clean-cache -y alien; showc
mk; cache; run "" clean-cache -y slackware alien; showc
mk; cache; run "" clean-cache -y nosuch; showc
mk; cache; run "" clean-cache -y alienn; showc
mk; cache; run "" clean-cache -y conraid; showc
mk; cache; run "" clean-cache -y empty; showc
