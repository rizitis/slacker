#!/bin/bash
# usage: check_all.sh   (from slacker-cli/) : build, tests, help, every moved group's behaviour
SP=/tmp/claude-0/-home-claude/73a54ae3-ae97-507e-9e79-48011fdaa1ed/scratchpad; BIN=$(pwd)/target/debug/slacker; ok=1
w=$(cargo build 2>&1 | grep -cE '^(warning|error)'); echo "build: $w warnings/errors"; [ "$w" = 0 ] || ok=0
t=$(cargo test 2>&1 | grep 'test result'); echo "tests: $t"; echo "$t" | grep -q '219 passed; 0 failed' || ok=0
A=$SP/help_now; rm -rf $A; mkdir -p $A; COLUMNS=100 NO_COLOR=1 $BIN --help > $A/_top.txt 2>&1
for c in $($BIN --help | sed -n '/^Commands:/,/^$/p' | awk 'NF && $1!="Commands:"{print $1}'); do COLUMNS=100 NO_COLOR=1 $BIN help $c > $A/$c.txt 2>&1; COLUMNS=100 NO_COLOR=1 $BIN $c -h > $A/$c.short.txt 2>&1; done
if diff -r $SP/help_before $A >/dev/null; then echo "help: 79/79 ίδια"; else echo "help: ΔΙΑΦΟΡΑ"; ok=0; fi
for g in tmpl:tmpl_before repo:repo_before bl:bl_fixed2 hist:hist_before query:query_before fm:fm_before rev:rev_before clean:clean_before nc:nc_before upd:upd_before st:st_before dist:dist_before inst:inst_before; do s=${g%%:*}; b=${g#*:}; [ -x $SP/${s}_run.sh ] && [ -f $SP/$b.txt ] || continue
  $SP/${s}_run.sh $BIN > $SP/${s}_now.txt 2>&1; n=$(grep -cE '^### (slacker|\[)' $SP/${s}_now.txt)
  if diff -q $SP/$b.txt $SP/${s}_now.txt >/dev/null; then echo "$s: ίδια ($n εκτελέσεις)"; else echo "$s: ΔΙΑΦΟΡΑ"; diff $SP/$b.txt $SP/${s}_now.txt | head -5; ok=0; fi; done
[ $ok = 1 ] && echo "=== ΟΛΑ ΟΚ ===" || echo "=== ΚΑΤΙ ΔΕΝ ΠΗΓΕ ΚΑΛΑ ==="
