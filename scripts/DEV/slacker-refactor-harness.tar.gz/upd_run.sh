#!/bin/bash
# `slacker update` against local file:// mirrors with a real GPG key. Setup steps always use the fixed step-10 binary.
SP=/tmp/claude-0/-home-claude/73a54ae3-ae97-507e-9e79-48011fdaa1ed/scratchpad; G=$SP/gpgsrc; SETUP=$SP/slacker_step10
BIN=$1; R=/home/claude/updtest
pk(){ for p in "$@"; do printf 'PACKAGE NAME:  %s.txz\nPACKAGE LOCATION:  ./x\nPACKAGE REQUIRED:  \nPACKAGE DESCRIPTION:\n%s: test\n\n' $p ${p%%-[0-9]*}; done; }
mirror(){ d=$R/m/$1; shift; mkdir -p $d; { echo "PACKAGES.TXT;"; echo; pk "$@"; } > $d/PACKAGES.TXT; (cd $d && for p in "$@"; do echo "0123456789abcdef0123456789abcdef  ./x/$p.txz"; done > CHECKSUMS.md5); cp $G/GPG-KEY $d/GPG-KEY; }
sign(){ gpg --homedir $G/home --batch --yes --armor --detach-sign -o $R/m/$1/CHECKSUMS.md5.asc $R/m/$1/CHECKSUMS.md5 2>/dev/null; }
mk(){ rm -rf $R; mkdir -p $R/{conf,cache,state,pkgdb,stock}
  printf "ARCH=x86_64\nCACHE_DIR=$R/cache\nSTATE_DIR=$R/state\nPKG_DB_DIR=$R/pkgdb\nVERIFY=md5\n" > $R/conf/slacker.conf
  printf "100 slackware file://$R/m/slackware official verify=gpg\n80 alien file://$R/m/alien verify=none\n70 tampered file://$R/m/tampered verify=gpg\n60 nosig file://$R/m/nosig verify=gpg\n50 evil file://$R/m/evil verify=none\n40 gone file://$R/m/gone verify=none\n30 frozen file://$R/m/frozen verify=none\n" > $R/conf/repos
  mirror slackware vim-9.1-x86_64-1 bash-5.3-x86_64-1; printf 'Thu Oct 29 10:00:00 UTC 2026\na/bash-5.3: Upgraded.\n' > $R/m/slackware/ChangeLog.txt; sign slackware
  mirror alien vlc-3.0-x86_64-1alien; mirror tampered foo-1-x86_64-1t; sign tampered; echo "fedcba9876543210fedcba9876543210  ./x/evil.txz" >> $R/m/tampered/CHECKSUMS.md5
  mirror nosig bar-1-x86_64-1n; mirror evil 'ok-1-x86_64-1e' '../../../etc/evil-1-x86_64-1e'; mirror frozen baz-1-x86_64-1z
  NO_COLOR=1 $SETUP --config-dir $R/conf distrust-repo -y frozen </dev/null >/dev/null 2>&1; }
stock(){ python3 -I -c "import sqlite3,sys; c=sqlite3.connect(sys.argv[1]); c.execute('create table closure(a,b)'); c.commit()" $R/stock/depgraph.db; printf "ChangeLog.txt: $1\n" > $R/stock/README.md
  printf "RESOLVE_STOCK=yes\nSTOCK_DB_URL=file://$R/stock\n" >> $R/conf/slacker.conf; }
st(){ echo "### state:"; (cd $R/state && find . -type f ! -path './gpg/*' | sort | while read f; do echo "  $f: $(head -c 120 $f | tr '\n' '|')"; done); echo "### cache:"; (cd $R/cache && find . -type f | sort | tr '\n' ' '); echo; }
run(){ inp=$1; shift; echo "### slacker $*   [stdin: $(printf %q "$inp")]"; printf "$inp" | NO_COLOR=1 timeout 60 $BIN --config-dir $R/conf "$@" 2>&1 | sed "s#$R#ROOT#g"; echo "### exit=${PIPESTATUS[1]}"; }
mk; run "" update -y; st
run "" update -y; st
mkdir -p $R/m/gone && mirror gone qux-1-x86_64-1g; run "" update -y; st
mirror alien vlc-3.1-x86_64-1alien; run "n\n" update; st
run "zz\n" update; run "9\n" update; st
run "1\n" update; st
mirror alien vlc-3.2-x86_64-1alien; mirror gone qux-2-x86_64-1g; run "2\n" update; st; run "a\n" update; st
mirror alien vlc-3.3-x86_64-1alien; run "" update; st
printf 'Fri Oct 30 10:00:00 UTC 2026\nmore\n' > $R/m/slackware/ChangeLog.txt; run "\n" update; st
run "" update gpg; st
mk; run "" update gpg; st
mk; rm $R/m/slackware/ChangeLog.txt; run "" update -y; st
echo "=== stock-db"
mk; printf "RESOLVE_STOCK=yes\n" >> $R/conf/slacker.conf; run "" update -y; run "" update -y; st
mk; printf "RESOLVE_STOCK=yes\nSTOCK_DB_URL=file://$R/nowhere\n" >> $R/conf/slacker.conf; run "" update -y; st
mk; printf "RESOLVE_STOCK=yes\nSTOCK_DB_URL=file://$R/stock\n" >> $R/conf/slacker.conf; echo garbage > $R/stock/depgraph.db; run "" update -y; st
mk; stock 'Thu Oct 29 10:00:00 UTC 2026'; run "" update -y; run "" update -y; st
mk; stock 'Wed Oct 28 10:00:00 UTC 2026'; run "" update -y; st
mk; stock 'x'; rm $R/stock/README.md; run "" update -y; st
echo "=== όλα up-to-date"
mk; printf "100 slackware file://$R/m/slackware official verify=gpg\n80 alien file://$R/m/alien verify=none\n" > $R/conf/repos; run "" update -y; run "" update; st
stock 'Thu Oct 29 10:00:00 UTC 2026'; run "" update; st
