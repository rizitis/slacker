#!/bin/bash
# new-config on a private copy of /etc and /usr/share/vim (bind-mounted in a private mount ns; the real ones are never touched).
SP=/tmp/claude-0/-home-claude/73a54ae3-ae97-507e-9e79-48011fdaa1ed/scratchpad
BIN=$1; R=/home/claude/nctest
if [ "$2" != inner ]; then rm -rf $R; mkdir -p $R/vim $R/bin; cp -a /etc $R/etc; cp -a /etc $R/etc_pristine
  exec unshare -m --propagation private sh -c "mount --bind $R/etc /etc && mount --bind $R/vim /usr/share/vim && exec $0 $BIN inner"; fi
T='2026-01-01 00:00'
put(){ mkdir -p "$(dirname $1)"; printf "$2" > "$1"; touch -d "$T" "$1"; }
mk(){ rm -rf /etc/foo.conf* /etc/bar.conf* /etc/orphan.conf* /etc/sub /etc/passwd.new /etc/passwd.orig /etc/passwd.bak /etc/rc.d /usr/share/vim/* $R/merge.log
  cp -a $R/etc_pristine/passwd /etc/passwd
  put /etc/foo.conf 'a=1\nb=2\n'; put /etc/foo.conf.new 'a=1\nb=3\nc=4\n'
  put /etc/bar.conf 'same\n'; put /etc/bar.conf.new 'same\n'
  put /etc/orphan.conf.new 'lonely\n'
  put /etc/sub/baz.conf 'x\n'; put /etc/sub/baz.conf.new 'y\n'
  put /etc/passwd.new 'root:x:0:0::/root:/bin/sh\n'
  put /etc/rc.d/rc.local '#!/bin/sh\nmine\n'; put /etc/rc.d/rc.local.new '#!/bin/sh\n'
  put /usr/share/vim/vimrc 'set nu\n'; put /usr/share/vim/vimrc.new 'set nonu\n'
  printf '#!/bin/sh\necho "merge $*" >> %s/merge.log\necho merged >> "$1"\nexit ${MRC:-0}\n' $R > $R/bin/fakemerge; chmod +x $R/bin/fakemerge; }
st(){ echo "### κατάσταση:"; for f in $(cd / && find etc/foo.conf* etc/bar.conf* etc/orphan.conf* etc/sub etc/passwd etc/passwd.new etc/passwd.orig etc/passwd.bak etc/rc.d usr/share/vim -type f 2>/dev/null | sort); do
    [ "$f" = etc/passwd ] && { cmp -s /etc/passwd $R/etc_pristine/passwd && echo "  /etc/passwd: αμετάβλητο" || echo "  /etc/passwd: ΑΛΛΑΞΕ"; continue; }
    echo "  /$f: $(tr '\n' '|' < /$f)"; done; echo "### merge: $(cat $R/merge.log 2>/dev/null | tr '\n' ';')"; }
run(){ inp=$1; shift; echo "### slacker $*   [stdin: $(printf %q "$inp")] ${XDIST:+[dist_mode]} ${SLACKER_MERGE:+[merge=$(basename $SLACKER_MERGE) rc=${MRC:-0}]}"; printf "$inp" | NO_COLOR=1 timeout 60 $BIN "$@" 2>&1 | sed "s#$R#ROOT#g"; echo "### exit=${PIPESTATUS[1]}"; }
export SLACKER_MERGE=$R/bin/fakemerge
mk; rm /etc/*.conf.new /etc/sub/*.new /etc/passwd.new /etc/rc.d/*.new /usr/share/vim/*.new; run "" new-config; st
mk; rm /etc/foo.conf.new /etc/sub/*.new /etc/passwd.new /etc/rc.d/*.new /usr/share/vim/*.new; run "" new-config; st
mk; run "" new-config --dry-run; st
mk; run "" new-config -y; st
mk; run 'k\n' new-config; st
mk; run 'K\n' new-config; st
mk; run 'o\ny\n' new-config; st
mk; run 'o\nn\n' new-config; st
mk; run 'r\ny\n' new-config; st
mk; run 'r\n\n' new-config; st
mk; run 'x\na\nk\n' new-config; st
mk; run '' new-config; st
mk; run 'p\nd\nk\no\nk\nm\ny\no\nr\n' new-config; st
mk; run '\nzz\nk\no\nk\nm\nn\nr\no\n' new-config; st
mk; MRC=1 run 'p\nm\nk\nk\nk\nk\n' new-config; st
mk; SLACKER_MERGE=/nonexistent/tool run 'p\nm\nk\nk\nk\nk\n' new-config; st
mk; run 'p\n' new-config; st
if [ -n "$DISTHOOK" ]; then export XDIST=1
mk; run 'a\ny\n' new-config; st
mk; run 'A\nn\n' new-config; st
mk; run 'k\n' new-config; st
mk; run "" new-config -y; st
mk; run "" new-config --dry-run; st
unset XDIST; fi
echo "### υπόλοιπο /etc σε σχέση με το αρχικό:"; mk >/dev/null; rm -rf /etc/foo.conf* /etc/bar.conf* /etc/orphan.conf* /etc/sub /etc/passwd.new /etc/rc.d /usr/share/vim/*; diff -r --no-dereference $R/etc_pristine /etc >/dev/null 2>&1 && echo "  ίδιο" || diff -rq --no-dereference $R/etc_pristine /etc 2>&1 | head
