#!/bin/bash
# install/upgrade/reinstall/remove/download/upgrade-all/install-new on a fake -current system.
# Private mount+net namespace: copy of /etc (os-release = -current), empty /usr/share/vim, no network.
# Fake installpkg/upgradepkg/removepkg keep a fake package DB and log each call. Real GPG on the official tree.
SP=/tmp/claude-0/-home-claude/73a54ae3-ae97-507e-9e79-48011fdaa1ed/scratchpad; G=$SP/gpgsrc; SETUP=$SP/slacker_step13
BIN=$1; R=/home/claude/insttest
if [ "$2" != inner ]; then rm -rf $R; mkdir -p $R/vim; cp -a /etc $R/etc; cp -a /etc $R/etc_pristine
  python3 -I $SP/inst_fixture.py $R $G || exit 1
  exec unshare -m -n --propagation private sh -c "mount --bind $R/etc /etc && mount --bind $R/vim /usr/share/vim && exec $0 $BIN inner"; fi
T=2026-10-01T10:00:00
rm -f /etc/os-release; printf 'NAME=Slackware\nVERSION="15.0+"\nID=slackware\nVERSION_ID=15.0\nVERSION_CODENAME=current\n' > /etc/os-release
P=$R/pristine; mkdir -p $P/bin
for t in installpkg upgradepkg removepkg; do cat > $P/bin/$t <<EOF
#!/bin/sh
echo "\$(basename \$0) \$*" >> $R/pkgtools.log
f=""; for a in "\$@"; do case \$a in --*) ;; *) f=\$a;; esac; done
b=\$(basename "\$f"); b=\${b%.t?z}; n=\$(echo \$b | sed -E 's/-[^-]+-[^-]+-[^-]+\$//')
case " \$FAIL " in *" \$n "*) exit 1;; esac
if [ \$(basename \$0) = removepkg ]; then rm -f $R/pkgdb/\$f; exit 0; fi
for e in $R/pkgdb/*; do [ -e "\$e" ] || continue; en=\$(basename "\$e" | sed -E 's/-[^-]+-[^-]+-[^-]+\$//'); [ "\$en" = "\$n" ] && rm -f "\$e"; done
printf 'PACKAGE NAME:     %s\nFILE LIST:\nusr/bin/%s\n' \$b \$n > $R/pkgdb/\$b; touch -d $T $R/pkgdb/\$b
[ "\$n" = withconf ] && echo new > /etc/withconf.conf.new
exit 0
EOF
chmod +x $P/bin/$t; done
rm -rf $R/cache $R/state $R/conf $R/pkgdb $R/m; cp -a $P/m $R/m; cp -a $P/conf $R/conf; cp -a $P/cache $R/cache; cp -a $P/state $R/state; cp -a $P/pkgdb $R/pkgdb
NO_COLOR=1 PATH=$P/bin:$PATH $SETUP --config-dir $R/conf update -y </dev/null >/dev/null 2>&1
find $R/cache $R/state -exec touch -h -d $T {} +; rm -rf $P/cache $P/state; cp -a $R/cache $P/cache; cp -a $R/state $P/state
mk(){ rm -rf $R/cache $R/state $R/conf $R/pkgdb $R/dl $R/pkgtools.log /etc/withconf.conf.new /etc/old.conf.new
  cp -a $P/conf $R/conf; cp -a $P/cache $R/cache; cp -a $P/state $R/state; cp -a $P/pkgdb $R/pkgdb; }
st(){ echo "### pkgtools:"; sed "s#$R#ROOT#g" $R/pkgtools.log 2>/dev/null || echo "(καμία κλήση)"; echo "### pkgdb: $(ls $R/pkgdb | tr '\n' ' ')"
  echo "### quarantine: $(ls $R/state/quarantine 2>/dev/null | tr '\n' ' ')"; echo "### blacklist: $(tr '\n' '|' < $R/conf/blacklist)"
  echo "### /etc .new: $(ls /etc/*.new 2>/dev/null | tr '\n' ' ')"; [ -d $R/dl ] && echo "### dl: $(cd $R/dl && ls | tr '\n' ' ')"
  echo "### cache: $(cd $R/cache && find packages -type f 2>/dev/null | sort | tr '\n' ' ')"; }
run(){ inp=$1; shift; echo "### slacker $*   [stdin: $(printf %q "$inp")]${FAIL:+ [FAIL=$FAIL]}"
  printf "$inp" | NO_COLOR=1 COLUMNS=100 PATH=$P/bin:$PATH timeout 120 $BIN --config-dir $R/conf "$@" 2>&1 | sed "s#$R#ROOT#g"; echo "### exit=${PIPESTATUS[1]}"; }
one(){ mk; run "$@"; st; }
echo "=== install"
one "" install libfoo -y
one "" install app -y
one "s\n\ny\n" install app
one "r\ny\n" install app
one "a\ny\n" install app
one "b\n" install app
one "x\ns\nn\n" install app
one "" install app --no-deps -y
one "" install app --dry-run
one "" install htop -y
one "" install alien:htop -y
one "" install mpd -y
one "n\n" install mpd
one "y\n" install mpd
one "" install gimp -y
one "" install withconf -y
mk; echo old > /etc/old.conf.new; run "" install withconf -y; st; rm -f /etc/old.conf.new
one "" install vim -y
one "" install bash -y
one "" install nosuch -y
one "" install vim nosuch -y
one "" install vimm -y
one "" install @conraid -y
one "" install @alien -y
one "1 3\ny\n" install @alien
one "n\n" install @alien
one "zz\n" install @alien
one "\nn\n" install @alien
one "" install oldtool -y
one "y\n" install oldtool
one "n\n" install oldtool
one "" install 'new*' -y
echo "=== upgrade"
one "" upgrade vim -y
one "y\n" upgrade vim
one "n\n" upgrade vim
one "" upgrade vim --dry-run
one "" upgrade vlc -y
one "k\ny\n" upgrade vlc
one "r\ny\n" upgrade vlc
one "a\ny\n" upgrade vlc
one "q\n" upgrade vlc
one "zz\nk\nn\n" upgrade vlc
one "" upgrade @conraid -y
one "" upgrade kernel-generic -y
one "" upgrade perl -y
one "" upgrade openssl -y
one "y\n" upgrade openssl
one "" upgrade bash -y
one "" upgrade nosuch -y
one "" upgrade libfoo -y
one "" upgrade slacker -y
mk; FAIL=vim run "" upgrade vim -y; st
echo "=== reinstall"
one "" reinstall ffmpeg -y
one "n\n" reinstall ffmpeg
one "" reinstall bash -y
one "" reinstall vim -y
one "" reinstall nosuch -y
one "" reinstall ffmpeg --dry-run
echo "=== remove"
one "" remove mpd-lite -y
one "y\n" remove mpd-lite
one "n\n" remove mpd-lite
one "1\ny\n" remove mp
one "\ny\n" remove mp
one "n\n" remove mp
one "zz\n" remove mp
one "" remove @conraid -y
one "" remove @_cf -y
one "" remove @alien -y
one "" remove bash -y
one "" remove vimm -y
one "" remove vim nosuch -y
one "" remove mp --dry-run
one "" remove @nosuchrepo -y
echo "=== download"
one "" download vim -y
one "" download vim htop -y -o $R/dl
one "" download htop
one "1\n" download htop
one "n\n" download htop
one "" download vim --dry-run
one "" download nosuch -y
echo "=== upgrade-all"
one "" upgrade-all -y
one "" upgrade-all --dry-run
one "1 2\ny\n" upgrade-all
one "\nn\n" upgrade-all
one "n\n" upgrade-all
mk; FAIL=perl run "" upgrade-all -y; st
echo "=== install-new"
one "" install-new -y
one "" install-new --dry-run
one "1\ny\n" install-new
one "" install-new alien -y
one "" install-new aliien -y
one "" install-new conraid -y
echo "=== DoS (βαθιά αλυσίδα και κύκλος)"
one "" install d0001 -y
one "" install d0001 libfoo -y
one "" install d0001 --dry-run
one "" install deeproot -y
one "" upgrade deeproot -y
one "" install la -y
one "" install lb --dry-run
mk; run "" install d0001 -y; run "" install d0002 -y; run "" upgrade-all -y; st
echo "=== foundational σε γραφικό session"
python3 -I -c "
import socket,time
s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM); s.bind('\\0/tmp/.X11-unix/X0'); s.listen(1); open('$R/x.ready','w').close(); time.sleep(60)" & XP=$!
for i in $(seq 50); do [ -e $R/x.ready ] && break; sleep 0.1; done
one "" upgrade openssl -y
one "n\n" upgrade openssl
one "" upgrade-all --dry-run
kill $XP; wait $XP 2>/dev/null; rm -f $R/x.ready
echo "### υπόλοιπο /etc:"; rm -f /etc/os-release; cp -a $R/etc_pristine/os-release /etc/; diff -rq --no-dereference $R/etc_pristine /etc && echo "  ίδιο"
