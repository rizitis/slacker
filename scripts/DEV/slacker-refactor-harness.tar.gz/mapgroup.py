# usage: python3 -I mapgroup.py main.rs cmd_a cmd_b ...   -> exclusive items of that group (current line numbers) + test usage
import re,sys
src,roots=sys.argv[1],sys.argv[2:]; L=open(src).read().split('\n')
def strip(code):
    out=[];i=0;n=len(code)
    while i<n:
        if code.startswith('//',i):
            j=code.find('\n',i); i=n if j<0 else j; continue
        m=re.match(r'r(#*)"',code[i:i+6])
        if m and (i==0 or not (code[i-1].isalnum() or code[i-1]=='_')):
            h=m.group(1); end=code.find('"'+h,i+len(m.group(0))); i=n if end<0 else end+1+len(h); out.append('""'); continue
        c=code[i]
        if c=='"':
            j=i+1
            while j<n and code[j]!='"': j+= 2 if code[j]=='\\' else 1
            i=j+1; out.append('""'); continue
        m=re.match(r"'(\\.|[^\\'])'",code[i:i+4])
        if c=="'" and m: i+=len(m.group(0)); continue
        out.append(c); i+=1
    return ''.join(out)
items={}; i=0; test_start=len(L)
while i<len(L):
    l=L[i]
    if l.startswith('#[cfg(test)]'): test_start=i; break
    m=re.match(r'^(?:pub(?:\(crate\))? )?(fn|struct|enum|const|static|type|impl(?:<[^>]*>)?) ?([A-Za-z_][A-Za-z0-9_]*)?',l)
    if m and m.group(1):
        kind=m.group(1); name=m.group(2) or ''
        if kind.startswith('impl'): 
            mm=re.match(r'^impl(?:<[^>]*>)?\s+(?:[A-Za-z_:<>, ]+\s+for\s+)?([A-Za-z_][A-Za-z0-9_]*)',l); name='impl '+(mm.group(1) if mm else '?')+f'@{i+1}'
        j=i
        if l.rstrip().endswith(';'): pass
        else:
            while j<len(L) and not L[j].startswith('}'): j+=1
        # include preceding doc comments / attributes
        s=i
        while s>0 and (L[s-1].startswith('///') or L[s-1].startswith('#[')): s-=1
        items[name]=(s+1,j+1,kind); i=j+1; continue
    i+=1
names={n for n in items if not n.startswith('impl ')}
tok=re.compile(r'\b[A-Za-z_][A-Za-z0-9_]*\b')
edges={n:(set(tok.findall(strip('\n'.join(L[a-1:b]))))&names)-{n,'run','main'} for n,(a,b,k) in items.items()}
# impl blocks belong to their type
for n in list(items):
    if n.startswith('impl '):
        t=n.split()[1].split('@')[0]
        if t in edges: edges[t]|=edges[n]|{n}
cmds={n for n in names if n.startswith('cmd_')}
def reach(rs):
    seen=set(rs); st=list(rs)
    while st:
        for m in edges.get(st.pop(),()):
            if m in cmds or m in seen: continue
            seen.add(m); st.append(m)
    return seen
mine=reach(roots)
others=set()
for c in cmds-set(roots): others|=reach([c])
others|=reach([n for n in ('main','run') if n in items])
excl=sorted([n for n in mine if n not in others], key=lambda n: items[n][0])
tests='\n'.join(L[test_start:])
for n in excl:
    a,b,k=items[n]; tu=len(re.findall(r'\b'+re.escape(n.split('@')[0].replace('impl ',''))+r'\b',strip(tests)))
    print(f"{a:6d}-{b:<6d} {b-a+1:4d} {k:6s} {n}{'   <-- tests: '+str(tu) if tu else ''}")
print("ΣΥΝΟΛΟ:",sum(items[n][1]-items[n][0]+1 for n in excl),"γραμμές; tests ξεκινούν:",test_start+1)
shared_used=sorted((mine-set(excl)))
print("κοινά που χρησιμοποιεί (μένουν στο main.rs):",', '.join(shared_used))
