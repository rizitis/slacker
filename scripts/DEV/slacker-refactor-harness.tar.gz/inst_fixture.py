# build the pristine fixture for the install-group tests: mirrors (GPG-signed official tree), config, package DB, fake tools
import os,sys,subprocess,hashlib
R=sys.argv[1]; G=sys.argv[2]
P=R+'/pristine'
def sign(f): subprocess.run(['gpg','--homedir',G+'/home','--batch','--yes','--armor','--detach-sign','-o',f+'.asc',f],stderr=subprocess.DEVNULL,check=True)
def mirror(path,pkgs,gpg=False):
    d=P+'/m/'+path; os.makedirs(d,exist_ok=True)
    txt=['PACKAGES.TXT;  Thu Oct  1 10:00:00 UTC 2026','']; ck=[]
    for p in pkgs:
        full,series=p['p'],p.get('s','x')
        name=full.rsplit('-',3)[0]
        os.makedirs(f'{d}/{series}',exist_ok=True); f=f'{d}/{series}/{full}.txz'
        open(f,'w').write('pkg '+full+'\n')
        if gpg: sign(f)
        txt+= [f'PACKAGE NAME:  {full}.txz',f'PACKAGE LOCATION:  ./{series}','PACKAGE SIZE (compressed):  100 K','PACKAGE SIZE (uncompressed):  300 K',
               'PACKAGE REQUIRED:  '+p.get('req','')]
        if 'conf' in p: txt.append('PACKAGE CONFLICTS:  '+p['conf'])
        if 'sug' in p: txt.append('PACKAGE SUGGESTS:  '+p['sug'])
        txt+=['PACKAGE DESCRIPTION:',f'{name}: {name} test package','']
        ck.append(hashlib.md5(open(f,'rb').read()).hexdigest()+f'  ./{series}/{full}.txz')
    open(d+'/PACKAGES.TXT','w').write('\n'.join(txt)+'\n'); open(d+'/CHECKSUMS.md5','w').write('\n'.join(ck)+'\n')
    if gpg: sign(d+'/CHECKSUMS.md5'); open(d+'/GPG-KEY','w').write(open(G+'/GPG-KEY').read())
    open(d+'/ChangeLog.txt','w').write('Thu Oct  1 10:00:00 UTC 2026\n'+path+'\n')
S=lambda p,**k: dict(p=p,**k)
mirror('slackware64-current',[S('vim-9.1-x86_64-1',s='ap'),S('bash-5.3-x86_64-1',s='a'),S('libfoo-1.0-x86_64-1',s='l'),
  S('app-1.0-x86_64-1',s='xap',req='libfoo,lame'),S('lame-3.100-x86_64-2',s='ap'),S('kernel-generic-6.18.40-x86_64-1',s='a'),
  S('perl-5.42.0-x86_64-1',s='d'),S('openssl-4.0.0-x86_64-1',s='n'),S('mpd-0.24-x86_64-1',s='ap',conf='mpd-lite'),
  S('gimp-3.0-x86_64-1',s='xap',sug='gimp-help'),S('withconf-1.0-x86_64-1',s='n'),S('slacker-0.12.6-x86_64-1',s='ap'),
  S('ffmpeg-7.1-x86_64-1',s='l'),S('vlc-3.0.21-x86_64-1',s='xap'),S('htop-3.4-x86_64-1',s='ap'),S('aaa_glibc-solibs-2.42-x86_64-1',s='a'),
  S('newone-1.0-x86_64-1',s='l'),S('newtwo-2.0-x86_64-1',s='l',req='libfoo')],gpg=True)
mirror('alien',[S('vlc-3.0.22-x86_64-1alien',req='ffmpeg'),S('ffmpeg-7.1-x86_64-1alien'),S('lame-3.100-x86_64-1alien'),S('htop-3.4-x86_64-1alien'),S('alienonly-1-x86_64-1alien')])
mirror('conraid',[S('mpv-0.41-x86_64-1cf')])
mirror('old/slackware64-15.0',[S('oldtool-1.0-x86_64-1_slack15.0')])
mirror('deep',[S('deeproot-2-x86_64-1deep',req='d0001')]+[S(f'd{i:04d}-1-x86_64-1deep',req=(f'd{i+1:04d}' if i<600 else '')) for i in range(1,601)])
mirror('loop',[S('la-1-x86_64-1lp',req='lb'),S('lb-1-x86_64-1lp',req='la')])
os.makedirs(P+'/conf',exist_ok=True); os.makedirs(P+'/pkgdb',exist_ok=True); os.makedirs(P+'/cache',exist_ok=True); os.makedirs(P+'/state',exist_ok=True)
open(P+'/conf/slacker.conf','w').write(f'ARCH=x86_64\nCACHE_DIR={R}/cache\nSTATE_DIR={R}/state\nPKG_DB_DIR={R}/pkgdb\nVERIFY=md5\nMAX_PARALLEL=1\n')
open(P+'/conf/repos','w').write(f'''100 slackware file://{R}/m/slackware64-current official verify=all
50 alien file://{R}/m/alien
40 conraid file://{R}/m/conraid
30 old150 file://{R}/m/old/slackware64-15.0
20 deep file://{R}/m/deep
10 loop file://{R}/m/loop
''')
open(P+'/conf/blacklist','w').write('bash\n@alien 100% vlc\n')
for p in ['vim-9.0-x86_64-1','bash-5.3-x86_64-1','lame-3.100-x86_64-1alien','kernel-generic-6.18.36-x86_64-1','perl-5.40.2-x86_64-1','openssl-3.5.4-x86_64-1',
          'mpd-lite-0.1-x86_64-1','slacker-0.12.5-x86_64-1','ffmpeg-7.1-x86_64-1','vlc-3.0.21-x86_64-1alien','mpv-0.40-x86_64-1cf','deeproot-1-x86_64-1deep','aaa_glibc-solibs-2.42-x86_64-1']:
    open(P+'/pkgdb/'+p,'w').write(f'PACKAGE NAME:     {p}\nFILE LIST:\nusr/bin/{p.split("-")[0]}\n')
