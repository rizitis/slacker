#!/bin/bash
# upgrade-dist 15.0 -> current on a fake system. Private mount+net namespace: copy of /etc (os-release = 15.0),
# empty /usr/share/vim, no network. Fake installpkg/upgradepkg/removepkg keep a fake package DB and log every call;
# fake df/date make disk space and backup names deterministic. Real GPG key + signatures on file:// mirrors.
SP=/tmp/claude-0/-home-claude/73a54ae3-ae97-507e-9e79-48011fdaa1ed/scratchpad; G=$SP/gpgsrc; SETUP=$SP/slacker_step12
BIN=$1; R=/home/claude/disttest
if [ "$2" != inner ]; then rm -rf $R; mkdir -p $R/vim; cp -a /etc $R/etc; cp -a /etc $R/etc_pristine
  exec unshare -m -n --propagation private sh -c "mount --bind $R/etc /etc && mount --bind $R/vim /usr/share/vim && exec $0 $BIN inner"; fi
T=2026-10-01T10:00:00
osrel(){ rm -f /etc/os-release; printf 'NAME=Slackware\nVERSION="%s"\nID=slackware\nVERSION_ID=%s\nVERSION_CODENAME=%s\n' "$1" "$1" "$2" > /etc/os-release; }
# mirror DIR "series/name-ver-arch-build[:uncompressed_k]" ...
mirror(){ d=$R/m/$1; shift; mkdir -p $d; : > $d/CHECKSUMS.md5; { echo "PACKAGES.TXT;  Thu Oct  1 10:00:00 UTC 2026"; echo; } > $d/PACKAGES.TXT
  for e in "$@"; do s=${e%%/*}; p=${e#*/}; IFS=: read p u c <<< "$p"; u=${u:-300}; c=${c:-100}; n=$(echo $p | sed -E 's/-[^-]+-[^-]+-[^-]+$//')
    mkdir -p $d/slackware64/$s; f=$d/slackware64/$s/$p.txz; echo "pkg $p" > $f
    gpg --homedir $G/home --batch --yes --armor --detach-sign -o $f.asc $f 2>/dev/null
    printf 'PACKAGE NAME:  %s.txz\nPACKAGE LOCATION:  ./slackware64/%s\nPACKAGE SIZE (compressed):  %s K\nPACKAGE SIZE (uncompressed):  %s K\nPACKAGE REQUIRED:  \nPACKAGE DESCRIPTION:\n%s: %s\n\n' $p $s $c $u $n $n >> $d/PACKAGES.TXT
    echo "$(md5sum < $f | cut -d' ' -f1)  ./slackware64/$s/$p.txz" >> $d/CHECKSUMS.md5; done
  gpg --homedir $G/home --batch --yes --armor --detach-sign -o $d/CHECKSUMS.md5.asc $d/CHECKSUMS.md5 2>/dev/null
  cp $G/GPG-KEY $d/GPG-KEY; printf 'Thu Oct  1 10:00:00 UTC 2026\n%s\n' "$1" > $d/ChangeLog.txt; }
emptytree(){ d=$R/m/$1; mkdir -p $d; echo "PACKAGES.TXT;" > $d/PACKAGES.TXT; : > $d/CHECKSUMS.md5; gpg --homedir $G/home --batch --yes --armor --detach-sign -o $d/CHECKSUMS.md5.asc $d/CHECKSUMS.md5 2>/dev/null; cp $G/GPG-KEY $d/; }
FILL15=$(for i in $(seq -w 1 30); do printf 'l/fill%s-1.0-x86_64-1 ' $i; done); FILLCUR=$(for i in $(seq -w 1 30); do printf 'l/fill%s-1.1-x86_64-1 ' $i; done)
mk(){ rm -rf $R/conf $R/cache $R/state $R/pkgdb $R/m $R/bin $R/*.log; mkdir -p $R/{conf,cache,state,pkgdb,bin}
  osrel 15.0 stable; rm -f /etc/foo.conf* ; echo old > /etc/foo.conf; echo new > /etc/foo.conf.new
  mirror slackware64-15.0 a/aaa_glibc-solibs-2.33-x86_64-5 a/pkgtools-15.0-noarch-42 a/tar-1.34-x86_64-1 a/xz-5.2.5-x86_64-3 a/gzip-1.11-x86_64-1 a/findutils-4.8.0-x86_64-1 a/mkinitrd-1.4.11-x86_64-28 \
    a/bash-5.1.016-x86_64-1 ap/vim-8.2.4256-x86_64-1 n/gnupg2-2.2.33-x86_64-1 n/gpgme-1.16.0-x86_64-1 n/openssl-1.1.1m-x86_64-1 l/oldlib-1.0-x86_64-1 $FILL15
  mirror slackware64-15.0/patches p/openssl-1.1.1zb-x86_64-1_slack15.0
  mirror slackware64-current a/aaa_glibc-solibs-2.42-x86_64-1 a/pkgtools-15.1-noarch-1 a/tar-1.35-x86_64-1 a/xz-5.8.1-x86_64-1 a/gzip-1.14-x86_64-1 a/findutils-4.10.0-x86_64-1 a/mkinitrd-1.4.11-x86_64-40 \
    a/bash-5.3.003-x86_64-1 ap/vim-9.1.1800-x86_64-1 n/gnupg2-2.4.8-x86_64-1 n/gpgme-2.0.0-x86_64-1 n/openssl-3.5.4-x86_64-1 n/newtool-1.0-x86_64-1:5500000:200000 l/newlib-2.0-x86_64-1 $FILLCUR
  emptytree slackware64-current/patches
  mirror alien x/vlc-3.0.21-x86_64-1alien
  printf '# mirrors\n# file:///nowhere/slackware64-15.0/\nfile://%s/m/slackware64-15.0/\n' $R > $R/conf/mirrors
  printf '100 slackware mirror official\n200 patches mirror/patches subtree immutable\n50 alien file://%s/m/alien\n' $R > $R/conf/repos
  printf "ARCH=x86_64\nCACHE_DIR=$R/cache\nSTATE_DIR=$R/state\nPKG_DB_DIR=$R/pkgdb\nVERIFY=all\nMAX_PARALLEL=1\n" > $R/conf/slacker.conf
  printf 'bash\n@alien 100%% vlc\n' > $R/conf/blacklist
  for p in aaa_glibc-solibs-2.33-x86_64-5 pkgtools-15.0-noarch-42 tar-1.34-x86_64-1 xz-5.2.5-x86_64-3 gzip-1.11-x86_64-1 findutils-4.8.0-x86_64-1 mkinitrd-1.4.11-x86_64-28 bash-5.1.016-x86_64-1 \
      vim-8.2.4256-x86_64-1 gnupg2-2.2.33-x86_64-1 gpgme-1.16.0-x86_64-1 openssl-1.1.1zb-x86_64-1_slack15.0 oldlib-1.0-x86_64-1 vlc-3.0.21-x86_64-1alien slacker-0.12.4-x86_64-1_FRG $(echo $FILL15 | tr ' ' '\n' | sed 's#^l/##'); do touch -d $T $R/pkgdb/$p; done
  for t in installpkg upgradepkg removepkg; do cat > $R/bin/$t <<EOF
#!/bin/sh
echo "\$(basename \$0) \$*" >> $R/pkgtools.log
f=""; for a in "\$@"; do case \$a in --*) ;; *) f=\$a;; esac; done
b=\$(basename "\$f"); b=\${b%.t?z}; n=\$(echo \$b | sed -E 's/-[^-]+-[^-]+-[^-]+\$//')
case " \$FAIL " in *" \$n "*) exit 1;; esac
case " \$NOREC " in *" \$n "*) exit 0;; esac
if [ \$(basename \$0) = removepkg ]; then rm -f $R/pkgdb/\$f; exit 0; fi
for e in $R/pkgdb/*; do [ -e "\$e" ] || continue; en=\$(basename "\$e" | sed -E 's/-[^-]+-[^-]+-[^-]+\$//'); [ "\$en" = "\$n" ] && rm -f "\$e"; done
touch -d $T $R/pkgdb/\$b; exit 0
EOF
  chmod +x $R/bin/$t; done
  printf '#!/bin/sh\nif [ "$1" = "-Pk" ]; then case "$2" in /) a=${FAKE_DF_ROOT:-104857600};; *) a=${FAKE_DF_CACHE:-104857600};; esac; echo "Filesystem 1024-blocks Used Available Capacity Mounted on"; echo "fake 209715200 1000 $a 1%% $2"; exit 0; fi\nexec /bin/df "$@"\n' > $R/bin/df
  printf '#!/bin/sh\n[ "$1" = "+%%Y%%m%%d-%%H%%M%%S" ] && { echo 20261029-120000; exit 0; }\nexec /bin/date "$@"\n' > $R/bin/date; chmod +x $R/bin/df $R/bin/date
  NO_COLOR=1 PATH=$R/bin:$PATH $SETUP --config-dir $R/conf update -y </dev/null >/dev/null 2>&1
  find $R/cache $R/state -exec touch -h -d $T {} +; }
st(){ echo "### pkgtools:"; sed "s#$R#ROOT#g" $R/pkgtools.log 2>/dev/null || echo "(καμία κλήση)"; echo "### pkgdb: $(ls $R/pkgdb | grep -v '^fill' | tr '\n' ' ') +$(ls $R/pkgdb | grep -c '^fill') fill"
  for f in mirrors repos blacklist blacklist.bak distro-upgrade.conf; do [ -e $R/conf/$f ] && { echo "### conf/$f:"; sed "s#$R#ROOT#g" $R/conf/$f; }; done
  echo "### conf extra: $(cd $R/conf && find . -mindepth 1 | sort | grep -v -E '^\./(mirrors|repos|blacklist|blacklist.bak|slacker.conf|distro-upgrade.conf)$' | tr '\n' ' ')"
  for f in $(cd $R/conf && find . -path './dist-backup-*' -type f -o -path './templates/*' -type f | sort); do echo "### conf/$f: $(sed "s#$R#ROOT#g" $R/conf/$f | tr '\n' '|' | cut -c1-400)"; done
  echo "### /etc/foo.conf*: $(ls /etc/foo.conf* | tr '\n' ' ')"; echo "### cache packages: $(cd $R/cache && find packages -type f 2>/dev/null | wc -l)"; }
norm(){ sed -e "s#$R#ROOT#g" -e 's/(oldest [^)]* old)/(oldest N old)/' -e 's/[0-9.]* GiB free/X GiB free/g'; }
run(){ inp=$1; shift; echo "### slacker $*   [stdin: $(printf %q "$inp")] ${FAIL:+[FAIL=$FAIL]}${NOREC:+[NOREC=$NOREC]}${FAKE_DF_ROOT:+[df/=$FAKE_DF_ROOT]}${FAKE_DF_CACHE:+[dfcache=$FAKE_DF_CACHE]}"
  printf "$inp" | NO_COLOR=1 COLUMNS=100 PATH=$R/bin:$PATH timeout 120 $BIN --config-dir $R/conf "$@" 2>&1 | norm; echo "### exit=${PIPESTATUS[1]}"; }
echo "=== 1 dry-run"; mk; run "" upgrade-dist current --dry-run; st
echo "=== 2 άκυροι στόχοι"; mk; run "" upgrade-dist 14.2 -y; run "" upgrade-dist foo -y; run "" upgrade-dist 15.0 -y; st
echo "=== 3 πλήρες -y"; mk; run "" upgrade-dist current -y; st; cp -a $R/pkgdb $R/pkgdb.after3; cp -a $R/conf $R/conf.after3
echo "=== 4 ξανά μετά την επιτυχία"; run "" upgrade-dist current -y; st
echo "=== 3b πλήρες -y με παράλληλα downloads (σειρά ολοκλήρωσης κανονικοποιημένη)"; mk; sed -i 's/^MAX_PARALLEL=1$/MAX_PARALLEL=4/' $R/conf/slacker.conf; run "" upgrade-dist current -y | python3 -I $SP/sortprog.py; st
echo "=== 5 λάθος λέξη επιβεβαίωσης"; mk; run 'curent\n' upgrade-dist current; st
echo "=== 6 σωστή λέξη, όχι στο proceed"; mk; run 'current\nn\n' upgrade-dist current; st
echo "=== 7 διαλογικό πλήρες"; mk; run 'current\n\n\ny\nk\n' upgrade-dist current; st
echo "=== 8 EOF στο stdin"; mk; run '' upgrade-dist current; st
echo "=== 9 πρώιμη πύλη χώρου (/)"; mk; FAKE_DF_ROOT=1048576 run "" upgrade-dist current -y; st
echo "=== 10 πρώιμη πύλη χώρου (cache)"; mk; FAKE_DF_CACHE=1048576 run "" upgrade-dist current -y; st
echo "=== 11 preflight χώρου (/)"; mk; FAKE_DF_ROOT=6000000 run "" upgrade-dist current -y; st
echo "=== 12 preflight χώρου (cache batch)"; mk; FAKE_DF_CACHE=3145728 run "" upgrade-dist current -y; st
echo "=== 13 core λείπει από το mirror"; mk; rm $R/m/slackware64-current/slackware64/a/tar-1.35-x86_64-1.txz; run "" upgrade-dist current -y; st
echo "=== 14 core δεν καταγράφεται"; mk; NOREC=xz run "" upgrade-dist current -y; st
echo "=== 15 αποτυχία core"; mk; FAIL=pkgtools run "" upgrade-dist current -y; st
echo "=== 16 αποτυχία non-core (ημιτελές)"; mk; FAIL="vim fill07" run "" upgrade-dist current -y; st
echo "=== 17 συνέχεια μετά το ημιτελές"; run "" upgrade-dist current -y; st
echo "=== 18 non-core λείπει από το mirror"; mk; rm $R/m/slackware64-current/slackware64/l/fill12-1.1-x86_64-1.txz; run "" upgrade-dist current -y; st
echo "=== 19 symlink στο repos"; mk; mv $R/conf/repos $R/conf/repos.real; ln -s repos.real $R/conf/repos; run "" upgrade-dist current -y; st
echo "=== 20 local mirror σωστό"; mk; echo "DISTRO_UPGRADE_MIRROR=file://$R/m/slackware64-current" > $R/conf/distro-upgrade.conf; run "" upgrade-dist current --dry-run; run "" upgrade-dist current -y; st
echo "=== 21 local mirror λάθος release"; mk; echo "DISTRO_UPGRADE_MIRROR=file://$R/m/slackware64-15.0" > $R/conf/distro-upgrade.conf; run "" upgrade-dist current -y; st
echo "=== 22 local mirror χωρίς PACKAGES.TXT"; mk; echo "DISTRO_UPGRADE_MIRROR=file://$R/m/nowhere-iso" > $R/conf/distro-upgrade.conf; run "" upgrade-dist current -y; st
echo "=== 23 local mirror χωρίς release στο path (ISO)"; mk; mkdir -p $R/iso; cp -a $R/m/slackware64-current/. $R/iso/; echo "DISTRO_UPGRADE_MIRROR=file://$R/iso" > $R/conf/distro-upgrade.conf; run "" upgrade-dist current --dry-run; st
echo "=== 24 ήδη στο development branch"; mk; osrel 15.0 current; run "" upgrade-dist current -y; st
echo "=== 25 15.0 -> 15.1"; mk; run "" upgrade-dist 15.1 --dry-run; st
echo "=== 26 γραφικό session"; mk; python3 -I -c "
import socket,time,os
s=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM); s.bind('\0/tmp/.X11-unix/X0'); s.listen(1); open('$R/x.ready','w').close(); time.sleep(120)" & XP=$!
for i in $(seq 50); do [ -e $R/x.ready ] && break; sleep 0.1; done; run 'nope\n' upgrade-dist current; kill $XP; wait $XP 2>/dev/null; rm -f $R/x.ready; st
echo "=== 27 self-upgrade"; mk; mirror slackware64-current a/aaa_glibc-solibs-2.42-x86_64-1 a/pkgtools-15.1-noarch-1 a/tar-1.35-x86_64-1 a/xz-5.8.1-x86_64-1 a/gzip-1.14-x86_64-1 a/findutils-4.10.0-x86_64-1 a/mkinitrd-1.4.11-x86_64-40 a/bash-5.3.003-x86_64-1 ap/slacker-0.12.5-x86_64-1; run "" upgrade-dist current -y; st
echo "### υπόλοιπο /etc:"; rm -f /etc/foo.conf*; osrel x x; cp -a $R/etc_pristine/os-release /etc/os-release 2>/dev/null; rm -f /etc/os-release; cp -a $R/etc_pristine/os-release /etc/; diff -rq --no-dereference $R/etc_pristine /etc && echo "  ίδιο"
