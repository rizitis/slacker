#!/bin/bash
# runs against a FIXED fixture (/home/claude/histtest) so ctimes are identical for both binaries
BIN=$1; R=/home/claude/histtest
run(){ echo "### slacker $*"; NO_COLOR=1 timeout 60 $BIN --config-dir $R/conf "$@" </dev/null 2>&1 | sed "s#$R#ROOT#g"; echo "### exit=${PIPESTATUS[0]}"; }
run history; run history pkga; run history --last 2; run history --since 2026-04-15
run history --installed; run history --removed; run history --upgraded; run history nosuchpkg
run history --since badDate
run show-changelog; run show-changelog slackware; run show-changelog other; run show-changelog nosuch
