# usage: closure.py main.rs root1 root2 ...  (run from slacker-cli/) : items movable with the roots,
# checking references from main.rs, every other src/*.rs and src/commands/*.rs. Comments and strings are stripped.
import re,sys,glob
def strip(t):
    # single pass tokenizer: drop comments, string/char literal contents; keep newlines and lifetimes
    o=[];i=0;n=len(t)
    while i<n:
        c=t[i]
        if t.startswith('//',i):
            j=t.find('\n',i); i=n if j<0 else j; continue
        if t.startswith('/*',i):
            j=t.find('*/',i+2); i=n if j<0 else j+2; o.append(' '); continue
        m=re.match(r'b?r(#*)"',t[i:])
        if m and (i==0 or not (t[i-1].isalnum() or t[i-1]=='_')):
            end='"'+m.group(1); j=t.find(end,i+m.end()); seg=t[i:j+len(end)]; o.append('""'+'\n'*seg.count('\n')); i=j+len(end); continue
        if c=='"':
            j=i+1
            while j<n and t[j]!='"':
                j+=2 if t[j]=='\\' else 1
            seg=t[i:j+1]; o.append('""'+'\n'*seg.count('\n')); i=j+1; continue
        if c=="'":
            m=re.match(r"'(?:\\(?:x[0-9a-fA-F]{2}|u\{[0-9a-fA-F]+\}|.)|[^'\\\n])'",t[i:])
            if m: o.append("''"); i+=m.end(); continue
        o.append(c); i+=1
    return ''.join(o)
src=open(sys.argv[1]).read(); L=src.split('\n')
tstart=next(i for i,l in enumerate(L) if l.startswith('#[cfg(test)]') and i+1<len(L) and L[i+1].startswith('mod '))
items=[]  # (name,start,end,kind)
i=0
pat=re.compile(r'^(?:pub(?:\(crate\))? )?(?:(fn|const|static|struct|enum|type|trait)\s+([A-Za-z_]\w*)|impl(?:<[^>]*>)?\s+(?:[\w:]+\s+for\s+)?([A-Za-z_]\w*))')
while i<tstart:
    m=pat.match(L[i])
    if m:
        name=m.group(2) or m.group(3); kind=m.group(1) or 'impl'
        s=i
        while s>0 and (L[s-1].startswith('///') or L[s-1].startswith('#[')): s-=1
        # find end: matching braces or ';'
        depth=0; j=i; started=False
        while True:
            t=strip(L[j])
            depth+=t.count('{')-t.count('}')
            if '{' in t: started=True
            if (started and depth==0) or (not started and t.rstrip().endswith(';') and depth==0): break
            j+=1
        items.append((name,s+1,j+1,kind)); i=j+1; continue
    i+=1
names={n for n,_,_,_ in items}
def refs(text): return set(re.findall(r'\b[A-Za-z_]\w*\b',strip(text)))
body={}
for n,s,e,k in items: body.setdefault(n,set()).update(refs('\n'.join(L[s-1:e]))-{n} if k!='impl' else refs('\n'.join(L[s-1:e])))
roots=sys.argv[2:]
S=set(roots); ch=True
while ch:
    ch=False
    for n in list(S):
        for r in body.get(n,()):
            if r in names and r not in S: S.add(r); ch=True
# external referrers
other={}
for f in glob.glob('src/*.rs')+glob.glob('src/commands/*.rs'):
    if f.endswith('/main.rs'): continue
    for r in refs(open(f).read()): other.setdefault(r,set()).add(f)
def outside(n):
    who=[m for m in names-S if n in body.get(m,())]
    return who, sorted(other.get(n,()))
ch=True
while ch:
    ch=False
    for n in sorted(S-set(roots)):
        w,o=outside(n)
        if w or o: S.discard(n); ch=True
# tests that reference
T='\n'.join(L[tstart:])
for n,s,e,k in sorted(items,key=lambda x:x[1]):
    if n in S: print(f"MOVE  {s:5}-{e:<5} {k:6} {n}")
print('--- κρατούνται (χρησιμοποιούνται και αλλού):')
cl=set(roots)
ch=True
while ch:
    ch=False
    for n in list(cl):
        for r in body.get(n,()):
            if r in names and r not in cl: cl.add(r); ch=True
for n,s,e,k in sorted(items,key=lambda x:x[1]):
    if n in cl and n not in S:
        w,o=outside(n); print(f"STAY  {s:5}-{e:<5} {k:6} {n}  <- {sorted(w)[:4]} {o}")
