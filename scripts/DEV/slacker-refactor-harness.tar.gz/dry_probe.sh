#!/bin/bash
BIN=$1; T=$(mktemp -d); mkdir -p $T/{cache/repos/slackware,state,pkgdb}
printf 'ARCH=x86_64\nCACHE_DIR=%s/cache\nSTATE_DIR=%s/state\nPKG_DB_DIR=%s/pkgdb\nVERIFY=none\n' $T $T $T > $T/slacker.conf
echo "10 slackware file://$T/u verify=none" > $T/repos; printf '# header\nkeepme\n' > $T/blacklist
S="$BIN --config-dir $T"
echo "### frozen --dry-run -y";      $S frozen --dry-run -y zzz-test </dev/null 2>&1 | tail -2; grep -qx zzz-test $T/blacklist && echo "BUG: frozen"
echo "### frozen --dry-run (με προειδοποίηση)"; $S frozen --dry-run 'with space' </dev/null 2>&1 | tail -2; grep -q 'with space' $T/blacklist && echo "BUG: frozen(warn)"
$S frozen -y zzz-keep </dev/null >/dev/null 2>&1
echo "### unfrozen --dry-run";        $S unfrozen --dry-run zzz-keep nosuch </dev/null 2>&1 | tail -3; grep -qx zzz-keep $T/blacklist || echo "BUG: unfrozen"
echo "### pin --dry-run -y";          $S pin --dry-run -y slackware:zzz-pin </dev/null 2>&1 | tail -2; grep -q zzz-pin $T/blacklist && echo "BUG: pin"
$S pin -y slackware:zzz-pin2 </dev/null >/dev/null 2>&1
echo "### unpin --dry-run";           $S unpin --dry-run zzz-pin2 </dev/null 2>&1 | tail -2; grep -q zzz-pin2 $T/blacklist || echo "BUG: unpin"
echo "### τελικό blacklist:"; cat $T/blacklist; rm -rf $T
