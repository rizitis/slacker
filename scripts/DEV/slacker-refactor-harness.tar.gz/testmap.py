# usage: testmap.py main.rs root... : for each #[test] fn in main.rs test modules that touches the movable set, show module, lines, and other main.rs items it uses
import sys,re
exec(open('/tmp/claude-0/-home-claude/73a54ae3-ae97-507e-9e79-48011fdaa1ed/scratchpad/closure.py').read().split("# tests that reference")[0])
mods=[]
for i in range(tstart,len(L)):
    m=re.match(r'^mod (\w+) \{',L[i])
    if m: mods.append((i+1,m.group(1)))
def modof(ln): return [n for s,n in mods if s<=ln][-1]
i=tstart
while i<len(L):
    if L[i].strip()=='#[test]' or L[i].strip().startswith('#[test]'):
        s=i
        while s>0 and L[s-1].strip().startswith(('///','#[')) : s-=1
        j=i+1
        while not re.match(r'\s*fn ',L[j]): j+=1
        name=re.match(r'\s*fn (\w+)',L[j]).group(1)
        d=0;k=j;st=False
        while True:
            t=strip(L[k]); d+=t.count('{')-t.count('}')
            if '{' in t: st=True
            if st and d==0: break
            k+=1
        r=refs('\n'.join(L[j:k+1]))
        mv=sorted(r&S); other=sorted((r&names)-S)
        if mv: print(f"{modof(i+1):22} {s+1:5}-{k+1:<5} {name}\n      moved: {mv}\n      other main items: {other}")
        i=k+1; continue
    i+=1
# module-level helpers inside test modules (non-test fns)
