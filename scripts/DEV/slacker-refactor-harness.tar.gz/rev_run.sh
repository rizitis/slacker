#!/bin/bash
# usage: rev_run.sh BIN   (re-execs itself inside a private mount ns with a fake -current os-release)
SP=/tmp/claude-0/-home-claude/73a54ae3-ae97-507e-9e79-48011fdaa1ed/scratchpad
BIN=$1; R=/home/claude/revtest
mk(){ rm -rf $R; mkdir -p $R/{conf,conf_off,conf_stable,cache/repos/slackware,state,adm/packages,adm/removed_packages,cum/slackware64-current/slackware64/ap,cum/slackware64-current/slackware64/a}
  base="ARCH=x86_64\nCACHE_DIR=$R/cache\nSTATE_DIR=$R/state\nADM_DIR=$R/adm\nVERIFY=none\n"
  printf "${base}REVERT=on\nCUMULATIVE_URL=file://$R/cum/slackware64-current\n" > $R/conf/slacker.conf
  printf "${base}REVERT=off\nCUMULATIVE_URL=file://$R/cum/slackware64-current\n" > $R/conf_off/slacker.conf
  printf "${base}REVERT=on\nCUMULATIVE_URL=file://$R/cum/slackware64-15.0\n" > $R/conf_stable/slacker.conf
  for c in conf conf_off conf_stable; do echo "100 slackware file://$R/mirror official verify=none" > $R/$c/repos; done
  : > $R/cache/repos/slackware/PACKAGES.TXT
  { echo "PACKAGES.TXT;  Thu Oct 29 10:00:00 UTC 2026"; echo; printf 'PACKAGE NAME:  vim-9.1-x86_64-1.txz\nPACKAGE LOCATION:  ./slackware64/ap\n\nPACKAGE NAME:  aaa_glibc-solibs-2.42-x86_64-1.txz\nPACKAGE LOCATION:  ./slackware64/a\n\n'; } > $R/cum/slackware64-current/PACKAGES.TXT
  echo dummy > $R/cum/slackware64-current/slackware64/ap/vim-9.0-x86_64-1.txz; echo dummy-sig > $R/cum/slackware64-current/slackware64/ap/vim-9.0-x86_64-1.txz.asc
  touch $R/adm/packages/vim-9.1-x86_64-1 $R/adm/packages/aaa_glibc-solibs-2.42-x86_64-1 $R/adm/packages/oldonly-2-x86_64-1
  cd $R/adm/removed_packages
  touch -d '2026-05-01 10:00' 'vim-9.0-x86_64-1-upgraded-2026-05-01,10:00:00'
  touch -d '2026-03-01 09:00' 'vim-8.9-x86_64-2-upgraded-2026-03-01,09:00:00'
  touch -d '2026-04-01 09:00' 'vlc-3.0-x86_64-1alien-upgraded-2026-04-01,09:00:00'
  touch -d '2026-02-01 09:00' 'aaa_glibc-solibs-2.41-x86_64-1-upgraded-2026-02-01,09:00:00'
  touch -d '2026-01-01 09:00' 'oldonly-1-x86_64-1-upgraded-2026-01-01,09:00:00'; cd - >/dev/null; }
run(){ c=$1; shift; echo "### [$c] slacker $*"; NO_COLOR=1 timeout 60 $BIN --config-dir $R/$c "$@" </dev/null 2>&1 | sed "s#$R#ROOT#g"; echo "### exit=${PIPESTATUS[0]}"; }
if [ "$2" != inner ]; then
  mk; echo "##### έξω από το namespace: πραγματικό os-release (όχι -current)"; run conf revert-pkg vim -y
  exec unshare -m --propagation private sh -c "mount --bind $SP/os-release.current /etc/os-release && exec $0 $BIN inner"
fi
echo "##### μέσα: VERSION_CODENAME=current"
mk
run conf_off revert-pkg vim -y
run conf_stable revert-pkg vim -y
run conf revert-pkg vlc -y
run conf revert-pkg nosuch -y
run conf revert-pkg vim --dry-run
run conf revert-pkg vim --dry-run -y
run conf revert-pkg aaa_glibc-solibs --dry-run -y
run conf revert-pkg oldonly --dry-run -y
run conf revert-pkg vim -y
echo "### μετά το πραγματικό run: cache"; (cd $R/cache && find . -type f | sort); echo "### blacklist:"; cat $R/conf/blacklist 2>/dev/null || echo "(none)"
mv $R/cum/slackware64-current/PACKAGES.TXT $R/cum/slackware64-current/P.bak; run conf revert-pkg vim -y
echo "PACKAGES.TXT;  Thu Oct 29 10:00:00 UTC 2026" > $R/cum/slackware64-current/PACKAGES.TXT; run conf revert-pkg vim -y
echo "<html>404</html>" > $R/cum/slackware64-current/PACKAGES.TXT; run conf revert-pkg vim -y
