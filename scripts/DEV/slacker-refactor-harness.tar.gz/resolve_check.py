# usage: resolve_check.py OLD_main.rs NEW_module.rs ORIG_chunks.txt
import re,sys
old,newm,orig=sys.argv[1:4]
def strip(code):
    out=[];i=0;n=len(code)
    while i<n:
        if code.startswith('//',i):
            j=code.find('\n',i); i=n if j<0 else j; continue
        m=re.match(r'r(#*)"',code[i:i+6])
        if m and (i==0 or not (code[i-1].isalnum() or code[i-1]=='_')):
            h=m.group(1); end=code.find('"'+h,i+len(m.group(0))); i=n if end<0 else end+1+len(h); out.append('""'); continue
        c=code[i]
        if c=='"':
            j=i+1
            while j<n and code[j]!='"': j+= 2 if code[j]=='\\' else 1
            i=j+1; out.append('""'); continue
        m=re.match(r"'(\\.|[^\\'])'",code[i:i+4])
        if c=="'" and m: i+=len(m.group(0)); continue
        out.append(c); i+=1
    return ''.join(out)
def strip_(c): return strip(c)
O=open(old).read(); N=open(newm).read(); C=open(orig).read()
# top-level names of OLD crate root: items + use-imports + mods
S={}
for l in O.split('\n'):
    m=re.match(r'^(?:pub(?:\(crate\))? )?(?:fn|struct|enum|const|static|type|trait) ([A-Za-z_]\w*)',l)
    if m: S[m.group(1)]='item in main.rs'
    m=re.match(r'^mod ([a-z_]\w*);',l)
    if m: S[m.group(1)]='module crate::'+m.group(1)
for u in re.findall(r'^use ([^;]+);',O,re.M):
    u=u.replace('\n',' ')
    if '{' in u:
        pre,rest=u.split('{',1); rest=rest.rsplit('}',1)[0]
        for part in rest.split(','):
            part=part.strip()
            if not part: continue
            nm=part.split(' as ')[-1].split('::')[-1].strip()
            S[nm]='use '+pre+part
    else:
        nm=u.split(' as ')[-1].split('::')[-1].strip(); S[nm]='use '+u
# NEW module imports
U={}
for u in re.findall(r'^use ([^;]+);',N,re.M):
    u=' '.join(u.split())
    if '{' in u:
        pre,rest=u.split('{',1); rest=rest.rsplit('}',1)[0]
        for part in rest.split(','):
            part=part.strip()
            if part: U[part.split(' as ')[-1].split('::')[-1].strip()]='use '+pre+part
    else: U[u.split(' as ')[-1].split('::')[-1].strip()]='use '+u
defined=set(re.findall(r'^(?:pub(?:\(crate\))? )?(?:fn|struct|enum|const|static) ([A-Za-z_]\w*)',C,re.M))
code=strip_(C); T=set(re.findall(r'\b[A-Za-z_]\w*\b',code))
used=sorted(n for n in T&set(S) if n not in defined)
print(f"{'όνομα':28s} {'ΠΡΙΝ (main.rs)':48s} ΜΕΤΑ (νέο αρχείο)")
bad=[]
for n in used:
    before=S[n]; after=U.get(n)
    if after is None:
        # find usage contexts to classify (qualified path / field / method / local)
        ctx=set(re.findall(r'(\S{0,18}\b'+n+r'\b\S{0,3})',code))
        print(f"{n:28s} {before[:48]:48s} ** ΔΕΝ εισάγεται ** χρήσεις: {sorted(ctx)[:6]}"); bad.append(n)
    else:
        same = before.split('::')[-1].strip()==after.split('::')[-1].strip()
        print(f"{n:28s} {before[:48]:48s} {after[:60]}")
print("\nΟΝΟΜΑΤΑ ΓΙΑ ΧΕΙΡΟΚΙΝΗΤΟ ΕΛΕΓΧΟ:",bad if bad else "κανένα")
