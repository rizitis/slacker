# sort runs of parallel-download progress lines ("  ✓ name [i/n]") so completion order does not matter
import sys,re
pat=re.compile(r'^  [✓✗] \S+ \[\d+/\d+\]')
buf=[]
def flush():
    global buf
    for l in sorted(re.sub(r'\[\d+/(\d+)\]',r'[?/\1]',x) for x in buf): sys.stdout.write(l)
    buf=[]
for line in sys.stdin:
    if pat.match(line): buf.append(line)
    else: flush(); sys.stdout.write(line)
flush()
