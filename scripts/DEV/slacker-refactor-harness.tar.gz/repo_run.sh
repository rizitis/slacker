#!/bin/bash
BIN=$1; R=/home/claude/repotest; rm -rf $R; mkdir -p $R/{conf,cache/repos/good,state,pkgdb}
cat > $R/conf/slacker.conf <<EOF
ARCH=x86_64
CACHE_DIR=$R/cache
STATE_DIR=$R/state
PKG_DB_DIR=$R/pkgdb
VERIFY=none
EOF
printf '10 good file://%s/good_url verify=none\n20 other file://%s/other_url verify=none\n' $R $R > $R/conf/repos
run(){ echo "### slacker $*"; NO_COLOR=1 timeout 60 $BIN --config-dir $R/conf "$@" </dev/null 2>&1 | sed "s#$R#ROOT#g"; echo "### exit=${PIPESTATUS[0]}"; }
show(){ echo "### repos file:"; cat $R/conf/repos; echo "### state:"; (cd $R/state && find . -type f | sort | while read f; do echo "$f: $(head -1 $f)"; done); }
run add-repo 50 newrepo https://example.invalid/x --dry-run
run add-repo abc newrepo https://example.invalid/x
run add-repo 10 dup https://example.invalid/y
run add-repo 50 bad ftp://example.invalid/z
run pri-repo 15 good -y; show
run pri-repo 20 good -y
run pri-repo 30 nope -y
run add-tag 30 SBo _SBo -y; show
run add-tag 30 SBo2 _x -y
run del-tag _SBo -y; show
run del-tag _nope -y
run del-repo nope -y
run del-repo other --dry-run
run del-repo other -y; show
run vet-repo good; show
run trust-repo good -y; show
run distrust-repo good -y; show
run vet-repo nope
