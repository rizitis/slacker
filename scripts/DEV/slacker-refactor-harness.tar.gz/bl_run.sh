#!/bin/bash
BIN=$1; R=/home/claude/bltest; rm -rf $R; mkdir -p $R/{conf,cache/repos/good,cache/repos/other,state,pkgdb}
cat > $R/conf/slacker.conf <<EOF
ARCH=x86_64
CACHE_DIR=$R/cache
STATE_DIR=$R/state
PKG_DB_DIR=$R/pkgdb
VERIFY=none
EOF
printf '10 good file://%s/good_url verify=none\n20 other file://%s/other_url verify=none\n' $R $R > $R/conf/repos
for r in good other; do { echo "PACKAGES.TXT;"; echo; for p in pkga pkgb; do printf 'PACKAGE NAME:  %s-1.0-x86_64-1.txz\nPACKAGE LOCATION:  ./kde\nPACKAGE REQUIRED:  \nPACKAGE DESCRIPTION:\n%s: test\n\n' $p $p; done; } > $R/cache/repos/$r/PACKAGES.TXT; done
touch $R/pkgdb/pkga-1.0-x86_64-1
run(){ echo "### slacker $*"; NO_COLOR=1 timeout 60 $BIN --config-dir $R/conf "$@" </dev/null 2>&1 | sed "s#$R#ROOT#g"; echo "### exit=${PIPESTATUS[0]}"; }
bl(){ echo "### blacklist:"; cat $R/conf/blacklist 2>/dev/null || echo "(none)"; }
run frozen
run frozen pkga 'kde/' '@good pkgb' 'foo.*' 'with space' '@nosuch x'; bl
run frozen -y pkga 'kde/' '@good pkgb' 'foo.*' 'with space' '@nosuch x'; bl
run frozen
run frozen -y pkga
run unfrozen pkga; run unfrozen 'kde/'; run unfrozen nope; run unfrozen 'foo'; bl
run unfrozen
run pin
run pin -y other:pkga; bl
run pin -y other:pkga; bl
run pin badspec; run pin nosuch:pkga; run pin -y good:nonexist; bl
run pin
run unpin pkga; run unpin nope; bl
run unpin
run unpin nonexist; bl
run frozen --dry-run -y newone; bl
