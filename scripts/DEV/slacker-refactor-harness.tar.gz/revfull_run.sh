#!/bin/bash
# full dangerous path of revert-pkg: real GPG verify + (fake) upgradepkg + freeze. Runs in a private mount ns with -current os-release.
SP=/tmp/claude-0/-home-claude/73a54ae3-ae97-507e-9e79-48011fdaa1ed/scratchpad; G=$SP/gpgsrc
BIN=$1; R=/home/claude/revfull
if [ "$2" != inner ]; then exec unshare -m --propagation private sh -c "mount --bind $SP/os-release.current /etc/os-release && exec $0 $BIN inner"; fi
mk(){ rm -rf $R; mkdir -p $R/{conf,cache/repos/slackware,state/gpg,adm/packages,adm/removed_packages,mirror,bin,cum/slackware64-current/slackware64/ap,cum/slackware64-current/slackware64/a}
  printf "ARCH=x86_64\nCACHE_DIR=$R/cache\nSTATE_DIR=$R/state\nADM_DIR=$R/adm\nVERIFY=all\nREVERT=on\nCUMULATIVE_URL=file://$R/cum/slackware64-current\n" > $R/conf/slacker.conf
  echo "100 slackware file://$R/mirror official" > $R/conf/repos; : > $R/cache/repos/slackware/PACKAGES.TXT
  cp $G/GPG-KEY $R/mirror/GPG-KEY; chmod 700 $R/state/gpg
  gpg --homedir $R/state/gpg --batch --import $R/mirror/GPG-KEY >/dev/null 2>&1; cp $G/fpr $R/state/gpg/slackware.fpr
  { echo "PACKAGES.TXT;  Thu Oct 29 10:00:00 UTC 2026"; echo; printf 'PACKAGE NAME:  vim-9.1-x86_64-1.txz\nPACKAGE LOCATION:  ./slackware64/ap\n\nPACKAGE NAME:  aaa_glibc-solibs-2.42-x86_64-1.txz\nPACKAGE LOCATION:  ./slackware64/a\n\n'; } > $R/cum/slackware64-current/PACKAGES.TXT
  cp $G/files/vim-9.0-x86_64-1.txz $G/files/vim-9.0-x86_64-1.txz.asc $R/cum/slackware64-current/slackware64/ap/
  cp $G/files/aaa_glibc-solibs-2.41-x86_64-1.txz $G/files/aaa_glibc-solibs-2.41-x86_64-1.txz.asc $R/cum/slackware64-current/slackware64/a/
  touch $R/adm/packages/vim-9.1-x86_64-1 $R/adm/packages/aaa_glibc-solibs-2.42-x86_64-1
  cd $R/adm/removed_packages; touch -d '2026-05-01 10:00' 'vim-9.0-x86_64-1-upgraded-2026-05-01,10:00:00'; touch -d '2026-03-01 09:00' 'vim-8.9-x86_64-2-upgraded-2026-03-01,09:00:00'
  touch -d '2026-02-01 09:00' 'aaa_glibc-solibs-2.41-x86_64-1-upgraded-2026-02-01,09:00:00'; cd - >/dev/null
  printf '#!/bin/sh\necho "upgradepkg $*" >> %s/upgradepkg.log\nexit ${FAKE_UPGRADEPKG_RC:-0}\n' $R > $R/bin/upgradepkg; chmod +x $R/bin/upgradepkg; }
show(){ echo "### upgradepkg κλήσεις:"; sed "s#$R#ROOT#g" $R/upgradepkg.log 2>/dev/null || echo "(καμία)"; echo "### blacklist:"; grep -v '^#' $R/conf/blacklist 2>/dev/null | grep . || echo "(κανένας κανόνας)"; echo "### cache packages:"; (cd $R/cache && find packages -type f 2>/dev/null | sort); }
run(){ inp=$1; shift; echo "### slacker $*   [stdin: $(printf %q "$inp")]"; printf "$inp" | NO_COLOR=1 PATH=$R/bin:$PATH timeout 60 $BIN --config-dir $R/conf "$@" 2>&1 | sed "s#$R#ROOT#g"; echo "### exit=${PIPESTATUS[1]}"; }
echo "=== A: πλήρης επιτυχία με -y (verify -> upgradepkg --reinstall -> freeze)"; mk; run "" revert-pkg vim -y; show
echo "=== B: διαλογικά: επιλογή 1, όχι freeze"; mk; run '1\nn\n' revert-pkg vim; show
echo "=== C: διαλογικά: επιλογή 2 (build που λείπει από το archive -> υπόδειξη release archive)"; mk; run '2\n' revert-pkg vim; show
echo "=== D: άκυρη επιλογή"; mk; run '9\n' revert-pkg vim; show
echo "=== E: foundational με -y (banner + επιβεβαίωση + install + freeze)"; mk; run "" revert-pkg aaa_glibc-solibs -y; show
echo "=== F: foundational διαλογικά, όχι στην προειδοποίηση"; mk; run '1\nn\n' revert-pkg aaa_glibc-solibs; show
echo "=== G: παραποιημένο πακέτο (έγκυρη υπογραφή για ΑΛΛΑ bytes)"; mk; cp $G/files/tampered.asc $R/cum/slackware64-current/slackware64/ap/vim-9.0-x86_64-1.txz.asc; run "" revert-pkg vim -y; show
echo "=== H: λείπει η υπογραφή .asc"; mk; rm $R/cum/slackware64-current/slackware64/ap/vim-9.0-x86_64-1.txz.asc; run "" revert-pkg vim -y; show
echo "=== I: υπογραφή από ΑΛΛΟ κλειδί (pin για άλλο fingerprint)"; mk; echo 1111222233334444555566667777888899990000 > $R/state/gpg/slackware.fpr; run "" revert-pkg vim -y; show
echo "=== J: αποτυχία upgradepkg (exit 1)"; mk; FAKE_UPGRADEPKG_RC=1; export FAKE_UPGRADEPKG_RC; run "" revert-pkg vim -y; show; unset FAKE_UPGRADEPKG_RC
echo "=== K: symlink στη θέση του προορισμού"; mk; mkdir -p $R/cache/packages/slackware; ln -s /etc/passwd $R/cache/packages/slackware/vim-9.0-x86_64-1.txz; run "" revert-pkg vim -y; show; ls -l /etc/passwd | awk '{print "### /etc/passwd μέγεθος:",$5}'
