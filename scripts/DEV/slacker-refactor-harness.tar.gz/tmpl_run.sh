#!/bin/bash
# usage: tmpl_run.sh BIN  -> prints a transcript of all template commands
BIN=$1; R=/home/claude/tmpltest; rm -rf $R; mkdir -p $R/{conf,cache/repos/good,state,pkgdb}
cat > $R/conf/slacker.conf <<EOF
ARCH=x86_64
CACHE_DIR=$R/cache
STATE_DIR=$R/state
PKG_DB_DIR=$R/pkgdb
RESOLVE_DEPS=on
VERIFY=none
EOF
echo "10 good file://$R/good_url verify=none" > $R/conf/repos
{ echo "PACKAGES.TXT;"; echo; for p in pkga pkgb pkgc; do printf 'PACKAGE NAME:  %s-1.0-x86_64-1.txz\nPACKAGE LOCATION:  ./pkg\nPACKAGE REQUIRED:  \nPACKAGE DESCRIPTION:\n%s: test\n\n' $p $p; done; } > $R/cache/repos/good/PACKAGES.TXT
touch $R/pkgdb/pkga-1.0-x86_64-1 $R/pkgdb/pkgb-1.0-x86_64-1 $R/pkgdb/orphan-9-x86_64-1
run(){ echo "### slacker $*"; NO_COLOR=1 $BIN --config-dir $R/conf "$@" 2>&1; echo "### exit=$?"; }
run generate-template t1
echo "### t1.template:"; cat $R/conf/templates/t1.template
printf 'include t1\npkgc\nghost\n' > $R/conf/templates/t2.template
run install-template t1 --dry-run
run install-template t2 --dry-run
run remove-template t1 --dry-run
run remove-template nope --dry-run
run delete-template t2 --dry-run
run delete-template t2
run delete-template t2
ls $R/conf/templates
