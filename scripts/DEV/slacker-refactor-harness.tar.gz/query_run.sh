#!/bin/bash
BIN=$1; R=/home/claude/querytest; rm -rf $R; mkdir -p $R/{conf,cache/repos/slackware,cache/repos/alien,state,adm/packages,adm/removed_packages}
printf 'ARCH=x86_64\nCACHE_DIR=%s/cache\nSTATE_DIR=%s/state\nADM_DIR=%s/adm\nVERIFY=none\n' $R $R $R > $R/conf/slacker.conf
printf '100 slackware file://%s/m official verify=none\n50 alien file://%s/a verify=none\n' $R $R > $R/conf/repos
pk(){ printf 'PACKAGE NAME:  %s.txz\nPACKAGE LOCATION:  ./%s\nPACKAGE SIZE (compressed):  %s K\nPACKAGE SIZE (uncompressed):  %s K\nPACKAGE REQUIRED:  %s\nPACKAGE DESCRIPTION:\n%s: %s (%s)\n%s:\n%s: Longer text.\n\n' "$1" "$2" "$3" "$4" "$5" "${1%%-[0-9]*}" "${1%%-[0-9]*}" "$6" "${1%%-[0-9]*}" "${1%%-[0-9]*}"; }
{ echo "PACKAGES.TXT;"; echo; pk vim-9.1.0-x86_64-1 slackware64/ap 4000 16000 "" "Vi IMproved"; pk flatpak-1.18.0-x86_64-2 slackware64/ap 1500 6000 "bubblewrap" "app sandbox"; pk xf86-input-libinput-1.5.0-x86_64-1 slackware64/x 40 120 "" "libinput driver"; } > $R/cache/repos/slackware/PACKAGES.TXT
{ echo "PACKAGES.TXT;"; echo; pk flatpak-1.18.0-x86_64-1alien x86_64/flatpak 1400 5900 "" "app sandbox (alien)"; pk vlc-3.0.21-x86_64-1alien x86_64/vlc 30000 90000 "" "media player"; } > $R/cache/repos/alien/PACKAGES.TXT
cat > $R/cache/repos/slackware/MANIFEST <<'EOF'
++========================================
||   Package:  ./slackware64/ap/vim-9.1.0-x86_64-1.txz
++========================================
drwxr-xr-x root/root         0 2026-01-01 00:00 usr/
-rwxr-xr-x root/root      1234 2026-01-01 00:00 usr/bin/vim
lrwxrwxrwx root/root         0 2026-01-01 00:00 usr/bin/vi -> vim
||   Package:  ./slackware64/x/xf86-input-libinput-1.5.0-x86_64-1.txz
-rwxr-xr-x root/root       555 2026-01-01 00:00 usr/lib64/xorg/modules/input/libinput_drv.so
EOF
cat > $R/cache/repos/alien/MANIFEST <<'EOF'
||   Package:  ./x86_64/flatpak/flatpak-1.18.0-x86_64-1alien.txz
-rwxr-xr-x root/root      7777 2026-01-01 00:00 usr/bin/flatpak
EOF
touch $R/adm/packages/flatpak-1.18.0-x86_64-1alien $R/adm/packages/vim-9.1.0-x86_64-1 $R/adm/packages/orphanpkg-1-x86_64-1_SBo
run(){ echo "### slacker $*"; NO_COLOR=1 timeout 60 $BIN --config-dir $R/conf "$@" </dev/null 2>&1 | sed "s#$R#ROOT#g"; echo "### exit=${PIPESTATUS[0]}"; }
run search flatpak; run search FLATPAK; run search vim; run search vlc; run search nosuch; run search orphanpkg
run search flat; run search 'fla*'; run search vim vlc nosuch; run search @alien; run search alien:vlc; run search
run file-search bin/vim; run file-search /usr/bin/flatpak; run file-search libinput; run file-search vi; run file-search nosuchfile; run file-search
run info flatpak; run info vim; run info vlc; run info orphanpkg; run info nosuch; run info alien:flatpak
